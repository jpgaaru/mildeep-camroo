// Pre-processing Operations View (Standardized with Purchase Base Design System)
import { Toast } from '../components/toast.js';
import { Modal } from '../components/modal.js';

// =========================================================================
// AQUAPULSE / DEVI FISHERIES BASE DESIGN SYSTEM (STANDARDIZED FROM PURCHASE)
// =========================================================================
const UIBase = {
  renderHeader(title, actionBtnHtml = '') {
    return `
      <div class="flex flex-wrap items-center justify-between gap-3 mb-2 animate-fade-in">
        <div>
          <h1 class="text-xl font-extrabold text-[#172B4D]">${title}</h1>
        </div>
        ${actionBtnHtml ? `<div class="flex items-center gap-2">${actionBtnHtml}</div>` : ''}
      </div>
    `;
  },

  renderFilterCard(opts) {
    const { idPrefix, title = 'Search & Filters', fields = [], searchBtnText = 'Search' } = opts;
    return `
      <div class="dt-top-filter-card bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs mb-3 transition-all duration-200" style="margin-bottom: 12px !important;">
        <div class="flex items-center justify-between pb-2 mb-3 border-b border-[#F1F5F9]">
          <div class="flex items-center gap-2">
            <svg class="w-4 h-4 text-[#006C7A]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/></svg>
            <h3 class="text-xs font-bold text-[#0F172A] uppercase tracking-wider">${title}</h3>
          </div>
        </div>

        <div id="${idPrefix}-filter-body" class="dt-top-filter-body grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 text-xs items-end">
          ${fields.map(f => `
            <div>
              <label class="block text-[11px] font-bold text-[#475569] uppercase tracking-wider mb-1.5">${f.label}</label>
              ${f.html}
            </div>
          `).join('')}

          <div class="flex items-center gap-2 pt-2">
            <button type="button" id="${idPrefix}-search-btn" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-xs hover:shadow cursor-pointer transition-all">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
              <span>${searchBtnText}</span>
            </button>
            <button type="button" id="${idPrefix}-reset-btn" class="px-4 py-2 bg-[#64748B] hover:bg-[#475569] text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1 shadow-xs hover:shadow transition-all cursor-pointer" title="Reset all filters">
              <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>
    `;
  },

  bindFilter(idPrefix, onSearch, onReset) {
    const toggleBtn = document.getElementById(`${idPrefix}-toggle-btn`);
    const filterBody = document.getElementById(`${idPrefix}-filter-body`);
    const toggleIcon = document.getElementById(`${idPrefix}-toggle-icon`);
    const resetBtn = document.getElementById(`${idPrefix}-reset-btn`);
    const searchBtn = document.getElementById(`${idPrefix}-search-btn`);

    if (toggleBtn && filterBody) {
      let isCollapsed = false;
      toggleBtn.onclick = () => {
        isCollapsed = !isCollapsed;
        if (isCollapsed) {
          filterBody.classList.add('hidden');
          if (toggleIcon) toggleIcon.classList.add('-rotate-90');
          toggleBtn.title = 'Show Filter';
        } else {
          filterBody.classList.remove('hidden');
          if (toggleIcon) toggleIcon.classList.remove('-rotate-90');
          toggleBtn.title = 'Hide Filter';
        }
      };
    }

    if (resetBtn && onReset) {
      resetBtn.onclick = onReset;
    }

    if (searchBtn && onSearch) {
      searchBtn.onclick = onSearch;
    }
  },

  renderTotals(title, count, countUnit, metrics) {
    return `
      <div class="bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs mt-4 animate-fade-in">
        <div class="flex items-center justify-between pb-3 mb-3 border-b border-[#EBECF0]">
          <div class="flex items-center gap-2">
            <svg class="w-4 h-4 text-[#006644]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
            <h3 class="text-xs font-bold text-[#172B4D]">${title}</h3>
          </div>
          <span class="text-xs text-[#5E6C84]">Showing totals for <strong class="text-[#172B4D]">${count}</strong> ${countUnit}</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3">
          ${metrics.map(m => `
            <div class="p-3 bg-[#FAFBFC] rounded-lg border border-[#EBECF0]">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84] block mb-1">${m.label}</span>
              <div class="flex items-baseline justify-between">
                <span class="text-lg font-extrabold ${m.color || 'text-[#172B4D]'}">${m.value}</span>
                ${m.badge ? `<span class="text-[10px] ${m.badgeColor || 'text-[#0284C7] bg-[#F0F9FF]'} font-semibold px-1.5 py-0.5 rounded">${m.badge}</span>` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  renderBadge(text, type = 'default') {
    const map = {
      default: 'bg-[#F4F5F7] text-[#172B4D] border-[#DFE1E6]',
      success: 'bg-[#E3FCEF] text-[#006644] border-[#ABF5D1]',
      warning: 'bg-[#FFF0B3] text-[#8F4D00] border-[#FFE380]',
      danger: 'bg-[#FFEBE6] text-[#BF2600] border-[#FFBDAD]',
      info: 'bg-[#F0F9FF] text-[#0284C7] border-[#BAE6FD]'
    };
    const cls = map[type] || map.default;
    return `<span class="font-medium px-2 py-0.5 rounded text-[11px] border ${cls}">${text}</span>`;
  },

  renderActionButtons(opts = {}) {
    const { onView, onEdit, onDownload, onDelete } = opts;
    return `
      <div class="flex items-center gap-1">
        ${onView ? `<button onclick="${onView}" class="p-1 rounded text-[#0284C7] hover:bg-[#F0F9FF]" title="View Details"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg></button>` : ''}
        ${onEdit ? `<button onclick="${onEdit}" class="p-1 rounded text-[#006644] hover:bg-[#E3FCEF]" title="Edit"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg></button>` : ''}
        ${onDownload ? `<button onclick="${onDownload}" class="p-1 rounded text-[#0284C7] hover:bg-[#F0F9FF]" title="Download Document"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg></button>` : ''}
        ${onDelete ? `<button onclick="${onDelete}" class="p-1 rounded text-[#FF5150] hover:bg-[#FEF2F2]" title="Delete"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg></button>` : ''}
      </div>
    `;
  }
};

// =========================================================================
// PRE-PROCESSING MODULE (STANDARDIZED WITH PURCHASE BASE DESIGN SYSTEM)
// =========================================================================
export const PreprocessingView = {
  // Baseline Preprocessing Store Data
  chemicalPosList: [
    { id: "CPO-01", sNo: 1, supplierName: "KPL INTERNATIONAL LTD", poNo: "DFL/KPL/2627/004", poDate: "06-10-2026", chemicals: "ALTESA NEO S100 (NP)", portName: "INPRT - PARADIP GARH", modeOfImport: "HSS", qtyBags: 320, qtyKgs: 6400, totalAmount: 1152000, etdDate: "15-10-2026", etaDate: "28-10-2026", remarks: "Bonded clearance required", status: "Approved" },
    { id: "CPO-02", sNo: 2, supplierName: "ADWIK IMPEX", poNo: "DFL//2627/003", poDate: "25-09-2026", chemicals: "CARNAL 659 S ADVANCED (STPP)", portName: "INKAK1 - KAKINADA", modeOfImport: "HSS", qtyBags: 240, qtyKgs: 4800, totalAmount: 868800, etdDate: "30-09-2026", etaDate: "29-10-2026", remarks: "Sea shipment in transit", status: "In Transit" },
    { id: "CPO-03", sNo: 3, supplierName: "KPL INTERNATIONAL LTD", poNo: "DFL/KPL/2627/003", poDate: "07-09-2026", chemicals: "ALTESA NEO S100 (NP)", portName: "INKAK1 - KAKINADA", modeOfImport: "HSS_BOND", qtyBags: 240, qtyKgs: 4800, totalAmount: 868800, etdDate: "10-09-2026", etaDate: "25-09-2026", remarks: "Cleared at port warehouse", status: "Received" },
    { id: "CPO-04", sNo: 4, supplierName: "PRAYON PHOSPHATES", poNo: "DFL/PP/2627/002", poDate: "18-08-2026", chemicals: "CARFOSEL B 940 (STPP)", portName: "INVTZ1 - VISAKHAPATNAM", modeOfImport: "DIRECT", qtyBags: 400, qtyKgs: 10000, totalAmount: 1650000, etdDate: "25-08-2026", etaDate: "15-09-2026", remarks: "Standard quality approved", status: "Received" },
    { id: "CPO-05", sNo: 5, supplierName: "ICL FOOD SPECIALTIES", poNo: "DFL/ICL/2627/001", poDate: "02-08-2026", chemicals: "BEKAPLUS FS (BLEND)", portName: "INKAK1 - KAKINADA", modeOfImport: "HSS_BOND", qtyBags: 180, qtyKgs: 4500, totalAmount: 945000, etdDate: "08-08-2026", etaDate: "22-08-2026", remarks: "Stored in temp-controlled store", status: "Received" }
  ],

  receivedChemicalsList: [
    { id: "RC-01", sNo: 1, poNo: "DFL/BC/2526/008", chemical: "CARFOSEL B 940 (STPP)", blNo: "DFL/BC/2526/02", containerNo: "DFL/BC/2526/02", receivedBags: 787, receivedQty: 19675, boeNo: "DFL/BC/2526/02", boeDate: "02-08-2025", clearedDate: "02-08-2025", balanceBags: 13, balanceQty: 325, status: "Pending" },
    { id: "RC-02", sNo: 2, poNo: "DFL/KPL/2526/003", chemical: "ALTESA BT2 (NP)", blNo: "2195420", containerNo: "2195420", receivedBags: 1080, receivedQty: 21600, boeNo: "2195420", boeDate: "21-05-2025", clearedDate: "23-05-2025", balanceBags: 800, balanceQty: 20000, status: "Pending" },
    { id: "RC-03", sNo: 3, poNo: "DFL/CFB/2425/003", chemical: "CARNAL 659 S ADVANCED (STPP)", blNo: "250506660011", containerNo: "CARNAL1-9, TGCU2314437", receivedBags: 3200, receivedQty: 80000, boeNo: "2141353", boeDate: "19-05-2025", clearedDate: "27-05-2025", balanceBags: 1600, balanceQty: 40000, status: "Pending" },
    { id: "RC-04", sNo: 4, poNo: "DFL/ICL/2627/001", chemical: "BEKAPLUS FS (BLEND)", blNo: "ICL-984421", containerNo: "MSCU8812903", receivedBags: 180, receivedQty: 4500, boeNo: "BOE-778210", boeDate: "14-08-2026", clearedDate: "20-08-2026", balanceBags: 0, balanceQty: 0, status: "Completed" }
  ],

  chemicalsConsumptionList: [
    { id: "CC-01", sNo: 1, date: "2026-10-14", plant: "DFL UNIT-5 (JPT)", chemical: "CARNAL 659 S ADVANCED (STPP)", openingBags: 1720, openingKgs: 43000, receivedBags: 50, receivedKgs: 1250, consumedBags: 49, consumedKgs: 1225, closingBags: 1721, closingKgs: 43025, batchCode: "VM-JPT-089", supervisor: "K. Venkata Vinay", status: "Verified" },
    { id: "CC-02", sNo: 2, date: "2026-10-14", plant: "DFL UNIT-1 (VSP)", chemical: "ALTESA NEO S100 (NP)", openingBags: 890, openingKgs: 17800, receivedBags: 0, receivedKgs: 0, consumedBags: 30, consumedKgs: 600, closingBags: 860, closingKgs: 17200, batchCode: "VM-VSP-112", supervisor: "T. Venkatesh", status: "Verified" },
    { id: "CC-03", sNo: 3, date: "2026-10-13", plant: "DFL UNIT-2 (KKD)", chemical: "CARFOSEL B 940 (STPP)", openingBags: 640, openingKgs: 16000, receivedBags: 100, receivedKgs: 2500, consumedBags: 62, consumedKgs: 1550, closingBags: 678, closingKgs: 16950, batchCode: "BT-KKD-044", supervisor: "D. Surya Narayana", status: "Verified" }
  ],

  chemicalReceivedReportsList: [
    { id: "CRR-01", sNo: 1, month: "October 2026", plant: "DFL UNIT-1 (VSP)", chemical: "ALTESA NEO S100 (NP)", totalBags: 240, totalKgs: 4800, avgRatePerKg: 181, totalCostInr: 868800, supplier: "KPL INTERNATIONAL LTD" },
    { id: "CRR-02", sNo: 2, month: "October 2026", plant: "DFL UNIT-5 (JPT)", chemical: "CARNAL 659 S ADVANCED (STPP)", totalBags: 320, totalKgs: 8000, avgRatePerKg: 195, totalCostInr: 1560000, supplier: "ADWIK IMPEX" },
    { id: "CRR-03", sNo: 3, month: "September 2026", plant: "DFL UNIT-2 (KKD)", chemical: "CARFOSEL B 940 (STPP)", totalBags: 400, totalKgs: 10000, avgRatePerKg: 165, totalCostInr: 1650000, supplier: "PRAYON PHOSPHATES" }
  ],

  chemicalOpeningBalancesList: [
    { id: "COB-01", sNo: 1, plant: "DFL UNIT-1 (VSP)", chemical: "ALTESA NEO S100 (NP)", uom: "KGS", openingBags: 890, openingKgs: 17800, valuationRate: 181, totalValuation: 3221800, auditDate: "2026-10-01" },
    { id: "COB-02", sNo: 2, plant: "DFL UNIT-2 (KKD)", chemical: "CARFOSEL B 940 (STPP)", uom: "KGS", openingBags: 640, openingKgs: 16000, valuationRate: 165, totalValuation: 2640000, auditDate: "2026-10-01" },
    { id: "COB-03", sNo: 3, plant: "DFL UNIT-5 (JPT)", chemical: "CARNAL 659 S ADVANCED (STPP)", uom: "KGS", openingBags: 1720, openingKgs: 43000, valuationRate: 195, totalValuation: 8385000, auditDate: "2026-10-01" }
  ],

  chemicalBalanceReportsList: [
    { id: "CBR-01", sNo: 1, plant: "DFL UNIT-1 (VSP)", chemical: "ALTESA NEO S100 (NP)", openingStock: 17800, receipts: 4800, consumption: 5400, transferOut: 0, closingStock: 17200, reorderLevel: 5000, stockStatus: "Adequate" },
    { id: "CBR-02", sNo: 2, plant: "DFL UNIT-5 (JPT)", chemical: "CARNAL 659 S ADVANCED (STPP)", openingStock: 43000, receipts: 8000, consumption: 7975, transferOut: 0, closingStock: 43025, reorderLevel: 10000, stockStatus: "Adequate" },
    { id: "CBR-03", sNo: 3, plant: "DFL UNIT-2 (KKD)", chemical: "CARFOSEL B 940 (STPP)", openingStock: 16000, receipts: 2500, consumption: 1550, transferOut: 0, closingStock: 16950, reorderLevel: 4000, stockStatus: "Adequate" }
  ],

  chemicalPaymentsList: [
    { id: "CPAY-01", sNo: 1, voucherNo: "CH-PAY-26-081", supplierName: "KPL INTERNATIONAL LTD", invoiceNo: "INV-KPL-8819", poNo: "DFL/KPL/2627/003", invoiceAmount: 868800, tdsAmount: 868, netPaid: 867932, paymentDate: "2026-10-05", bankAccount: "HDFC Bank - 0021 (Main)", paymentMode: "RTGS", status: "Settled" },
    { id: "CPAY-02", sNo: 2, voucherNo: "CH-PAY-26-082", supplierName: "ADWIK IMPEX", invoiceNo: "INV-ADW-4421", poNo: "DFL//2627/003", invoiceAmount: 868800, tdsAmount: 868, netPaid: 867932, paymentDate: "2026-10-10", bankAccount: "SBI Bank - 9940 (Commercial)", paymentMode: "NEFT", status: "Settled" },
    { id: "CPAY-03", sNo: 3, voucherNo: "CH-PAY-26-083", supplierName: "PRAYON PHOSPHATES", invoiceNo: "INV-PP-1092", poNo: "DFL/PP/2627/002", invoiceAmount: 1650000, tdsAmount: 1650, netPaid: 1648350, paymentDate: "2026-09-28", bankAccount: "Axis Bank - 4410 (Export)", paymentMode: "RTGS", status: "Settled" }
  ],

  rmReceivedList: [
    { id: "RMR-01", sNo: 1, inwardNo: "INW-2026-1089", arrivalDate: "2026-10-14", lotCode: "VM-VSP-AMP-056", plant: "DFL UNIT-1 (VSP)", species: "Vannamei Shrimp", receivedWeight: 4250, crates: 170, tempC: 1.2, grader: "B. Venkatesh", status: "Accepted" },
    { id: "RMR-02", sNo: 2, inwardNo: "INW-2026-1090", arrivalDate: "2026-10-14", lotCode: "BT-KKD-MKP-043", plant: "DFL UNIT-2 (KKD)", species: "Black Tiger Shrimp", receivedWeight: 3180, crates: 128, tempC: 0.9, grader: "K. Ramu", status: "Accepted" },
    { id: "RMR-03", sNo: 3, inwardNo: "INW-2026-1091", arrivalDate: "2026-10-14", lotCode: "VM-PSP-BVR-078", plant: "DFL UNIT-3 (PSP)", species: "Vannamei Shrimp", receivedWeight: 5600, crates: 224, tempC: 1.5, grader: "M. Nagesh", status: "Accepted" }
  ],

  deheadingLogsList: [
    {
      id: "DH-01",
      sNo: 1,
      arrivalDate: "2026-10-23",
      lotCode: "VM-VSP-AMP-056",
      plant: "DFL UNIT-1 (VSP)",
      center: "Own Center",
      station: "Own Center",
      deheadingDate: "2026-10-23",
      date: "2026-10-23",
      shift: "A SHIFT",
      supervisor: "K VENKATA VINAY",
      checkingCount2: 48,
      hlCount: 32,
      honCount: 48,
      honQty: 4250,
      headonWeight: 4250,
      hlQty: 2847.5,
      deheadedWeight: 2847.5,
      countNetYield: 66.8,
      yieldPct: 67.0,
      iceConsumption: 450,
      iceKgs: 450,
      sampleYield: 67.2,
      remarks: "Batch processed within HACCP temp specs",
      status: "Completed"
    },
    {
      id: "DH-02",
      sNo: 2,
      arrivalDate: "2026-10-23",
      lotCode: "BT-KKD-MKP-043",
      plant: "DFL UNIT-2 (KKD)",
      center: "Center 2",
      station: "Center 2",
      deheadingDate: "2026-10-23",
      date: "2026-10-23",
      shift: "B SHIFT",
      supervisor: "T.VENKATESH",
      checkingCount2: 52,
      hlCount: 36,
      honCount: 52,
      honQty: 3180,
      headonWeight: 3180,
      hlQty: 2067.0,
      deheadedWeight: 2067.0,
      countNetYield: 64.9,
      yieldPct: 65.0,
      iceConsumption: 320,
      iceKgs: 320,
      sampleYield: 65.5,
      remarks: "Cold-chain maintained at 1.8C",
      status: "Completed"
    },
    {
      id: "DH-03",
      sNo: 3,
      arrivalDate: "2026-10-22",
      lotCode: "VM-PSP-BVR-078",
      plant: "DFL UNIT-3 (PSP)",
      center: "Outside Center",
      station: "Outside Center",
      deheadingDate: "2026-10-23",
      date: "2026-10-23",
      shift: "A SHIFT",
      supervisor: "D.SURYA NARAYANA",
      checkingCount2: 44,
      hlCount: 28,
      honCount: 44,
      honQty: 5600,
      headonWeight: 5600,
      hlQty: 3808.0,
      deheadedWeight: 3808.0,
      countNetYield: 67.9,
      yieldPct: 68.0,
      iceConsumption: 600,
      iceKgs: 600,
      sampleYield: 68.2,
      remarks: "High grade HLSO yield",
      status: "Completed"
    }
  ],

  gradingLogsList: [
    {
      id: "GR-01",
      sNo: 1,
      transactionDate: "23-03-2025",
      date: "2025-03-23",
      arrivalDate: "2025-03-23",
      lotCode: "SKM/2425/1755",
      plant: "DFL UNIT-6 [JPT-II]",
      center: "",
      station: "Own Center",
      gradingMachine: "Unit -6 Laitram Grading Machine",
      startTime: "",
      endTime: "",
      breakTime: "",
      variety: "VM-HLSO",
      hlCount: "18.00",
      dominantCount: "18.00",
      hlWeight: "1.00",
      gradedWeight: 1.00,
      noOfCrates: 1,
      remarks: "",
      status: "Approved"
    },
    {
      id: "GR-02",
      sNo: 2,
      transactionDate: "23-03-2025",
      date: "2025-03-23",
      arrivalDate: "2025-03-23",
      lotCode: "SKM/2425/1755",
      plant: "DFL UNIT-6 [JPT-II]",
      center: "",
      station: "Own Center",
      gradingMachine: "Unit -6 Laitram Grading Machine",
      startTime: "",
      endTime: "",
      breakTime: "",
      variety: "VM-HLSO",
      hlCount: "23.00",
      dominantCount: "23.00",
      hlWeight: "347.00",
      gradedWeight: 347.00,
      noOfCrates: 13,
      remarks: "",
      status: "Approved"
    },
    {
      id: "GR-03",
      sNo: 3,
      transactionDate: "23-03-2025",
      date: "2025-03-23",
      arrivalDate: "2025-03-23",
      lotCode: "SKM/2425/1755",
      plant: "DFL UNIT-6 [JPT-II]",
      center: "",
      station: "Own Center",
      gradingMachine: "Unit -6 Laitram Grading Machine",
      startTime: "",
      endTime: "",
      breakTime: "",
      variety: "VM-HLSO",
      hlCount: "28.00",
      dominantCount: "28.00",
      hlWeight: "989.00",
      gradedWeight: 989.00,
      noOfCrates: 37,
      remarks: "",
      status: "Approved"
    },
    {
      id: "GR-04",
      sNo: 4,
      transactionDate: "23-03-2025",
      date: "2025-03-23",
      arrivalDate: "2025-03-23",
      lotCode: "SKM/2425/1755",
      plant: "DFL UNIT-6 [JPT-II]",
      center: "",
      station: "Own Center",
      gradingMachine: "Unit -6 Laitram Grading Machine",
      startTime: "",
      endTime: "",
      breakTime: "",
      variety: "VM-HLSO",
      hlCount: "34.00",
      dominantCount: "34.00",
      hlWeight: "694.00",
      gradedWeight: 694.00,
      noOfCrates: 26,
      remarks: "",
      status: "Approved"
    }
  ],

  valueAdditionList: [
    { id: "VA-01", sNo: 1, date: "2026-10-14", plant: "DFL UNIT-1 (VSP)", processType: "P&D (Peeled & Deveined)", batchCode: "VA-VM-098", inputWeight: 1500, outputWeight: 1230, recoveryPct: 82.0, supervisor: "K. Venkata Vinay", status: "Passed QC" },
    { id: "VA-02", sNo: 2, date: "2026-10-14", plant: "DFL UNIT-2 (KKD)", processType: "PTO (Peeled Tail On)", batchCode: "VA-BT-044", inputWeight: 1200, outputWeight: 1044, recoveryPct: 87.0, supervisor: "T. Venkatesh", status: "Passed QC" },
    { id: "VA-03", sNo: 3, date: "2026-10-13", plant: "DFL UNIT-5 (JPT)", processType: "Cooked Tail-On", batchCode: "VA-CK-012", inputWeight: 2000, outputWeight: 1780, recoveryPct: 89.0, supervisor: "D. Surya Narayana", status: "Passed QC" }
  ],

  honTransferList: [
    { id: "HT-01", sNo: 1, transferId: "HT-2026-041", date: "2026-10-14", fromPlant: "DFL UNIT-1 (VSP)", toPlant: "DFL UNIT-3 (PSP)", variety: "Vannamei Shrimp", weightKg: 2400, vehicleNo: "AP31TT4177", driverName: "R. Apparao", status: "In Transit" },
    { id: "HT-02", sNo: 2, transferId: "HT-2026-042", date: "2026-10-13", fromPlant: "DFL UNIT-2 (KKD)", toPlant: "DFL UNIT-5 (JPT)", variety: "Black Tiger Shrimp", weightKg: 1800, vehicleNo: "AP05X9921", driverName: "K. Simhachalam", status: "Delivered" }
  ],

  traceReportsList: [
    { id: "TR-01", sNo: 1, batchCode: "VM-VSP-AMP-056", farmerName: "K. Srinivasa Rao", pondNo: "Pond 4A", harvestDate: "2026-10-14", intakeWeight: 4250, deheadedWeight: 2847.5, gradedWeight: 2840, packedWeight: 2800, totalYieldPct: 65.88, status: "Traceable" },
    { id: "TR-02", sNo: 2, batchCode: "BT-KKD-MKP-043", farmerName: "G. Venkateswarlu", pondNo: "Pond 12", harvestDate: "2026-10-14", intakeWeight: 3180, deheadedWeight: 2067.0, gradedWeight: 2060, packedWeight: 2020, totalYieldPct: 63.52, status: "Traceable" },
    { id: "TR-03", sNo: 3, batchCode: "VM-PSP-BVR-078", farmerName: "M. Satyanarayana", pondNo: "Pond 2B", harvestDate: "2026-10-13", intakeWeight: 5600, deheadedWeight: 3808.0, gradedWeight: 3795, packedWeight: 3740, totalYieldPct: 66.78, status: "Traceable" }
  ],

  render(containerId, subPage = 'overview', activeHash = '#/preprocessing/dashboard/overview') {
    const container = typeof containerId === 'string' ? document.getElementById(containerId) : containerId;
    if (!container) return;

    this.updateHeaderAction(subPage);

    container.innerHTML = `
      <div id="preprocessing-tab-bar-container"></div>
      <div id="preproc-subpage-content" class="w-full"></div>
    `;

    if (typeof TabBar !== 'undefined' && typeof TabBar.render === 'function') {
      TabBar.render('preprocessing-tab-bar-container', activeHash);
    }
    const subContainer = document.getElementById('preproc-subpage-content');
    if (!subContainer) return;

    switch (subPage) {
      // 1. Dashboard
      case 'overview':
      case 'floor-overview':
        this.renderFloorOverview(subContainer);
        break;

      // 2. Floor Operations
      case 'rm-received':
        this.renderRmReceived(subContainer);
        break;
      case 'deheading':
        this.renderDeheading(subContainer);
        break;
      case 'grading':
        this.renderGrading(subContainer);
        break;
      case 'deheading-trackid':
        this.renderDeheadingTrackid(subContainer);
        break;
      case 'grading-trackid':
        this.renderGradingTrackid(subContainer);
        break;
      case 'value-addition':
        this.renderValueAddition(subContainer);
        break;
      case 'hon-qty-transfer':
        this.renderHonQtyTransfer(subContainer);
        break;

      // 3. Chemical Inventory & Usage
      case 'chemical-pos':
        this.renderChemicalPos(subContainer);
        break;
      case 'received-chemicals':
        this.renderReceivedChemicals(subContainer);
        break;
      case 'chemicals-consumption':
        this.renderChemicalsConsumption(subContainer);
        break;
      case 'chemical-received-report':
        this.renderChemicalReceivedReport(subContainer);
        break;
      case 'chemical-opening-balance':
        this.renderChemicalOpeningBalance(subContainer);
        break;
      case 'chemical-balance-report':
        this.renderChemicalBalanceReport(subContainer);
        break;
      case 'chemical-payments-list':
        this.renderChemicalPaymentsList(subContainer);
        break;

      // 4. Traceability & Reconciliation
      case 'track-code-report':
        this.renderTrackCodeReport(subContainer);
        break;
      case 'va-floor-balance':
        this.renderVaFloorBalance(subContainer);
        break;
      case 'va-transfer':
        this.renderVaTransfer(subContainer);
        break;
      case 'assumed-reports':
        this.renderAssumedReports(subContainer);
        break;
      case 'consolidation-daily':
        this.renderConsolidationDaily(subContainer);
        break;
      case 'file-upload':
        this.renderFileUpload(subContainer);
        break;

      default:
        this.renderFloorOverview(subContainer);
        break;
    }

    if (typeof window !== 'undefined' && window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  },

  updateHeaderAction(subPage) {
    const actionContainer = document.getElementById('section-action-btn-container');
    if (actionContainer) actionContainer.innerHTML = '';
  },

  // ============================================
  // 1. FLOOR OVERVIEW & COMPREHENSIVE TELEMETRY DASHBOARD
  // ============================================
  renderFloorOverview(container) {
    let fPlant = '';
    let fPeriod = 'Today';
    let fSpecies = '';

    const updateDashboard = () => {
      // Calculate dynamic telemetry
      const multiplier = fPeriod === 'This Week' ? 6.2 : fPeriod === 'Month to Date' ? 24.5 : 1.0;
      const baseIntake = 13030.0 * multiplier;
      const baseDeheaded = 8722.5 * multiplier;
      const baseGraded = 8695.0 * multiplier;
      const baseVa = 5840.0 * multiplier;
      const baseHonTransfer = 4200.0 * multiplier;
      const baseChemValue = (1.42 * (fPeriod === 'Today' ? 1.0 : 1.15)).toFixed(2);
      const yieldPct = ((baseDeheaded / baseIntake) * 100).toFixed(1);

      const kpiContainer = document.getElementById('preproc-kpi-grid');
      if (kpiContainer) {
        kpiContainer.innerHTML = `
          <!-- 1. RM Intake -->
          <div class="p-4 bg-white rounded-xl border border-[#DFE1E6] shadow-xs hover:border-[#02a8b5] transition-all">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84]">Today RM Intake</span>
              <span class="text-[10px] text-[#02a8b5] font-bold bg-[#F0FAFC] px-1.5 py-0.5 rounded">3 Plants</span>
            </div>
            <div class="flex items-baseline justify-between">
              <span class="text-xl font-extrabold text-[#0F172A]">${baseIntake.toLocaleString('en-IN', { maximumFractionDigits: 1 })} <span class="text-xs font-semibold text-[#64748B]">KG</span></span>
              <span class="text-[11px] font-bold text-[#006644] flex items-center gap-0.5">↑ 12.4%</span>
            </div>
            <span class="text-[11px] text-[#64748B] mt-1 block">Live intake across VSP, KKD & PSP docks</span>
          </div>

          <!-- 2. Deheaded Weight -->
          <div class="p-4 bg-white rounded-xl border border-[#DFE1E6] shadow-xs hover:border-[#02a8b5] transition-all">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84]">Deheaded Recovery</span>
              <span class="text-[10px] text-[#006644] font-bold bg-[#E3FCEF] px-1.5 py-0.5 rounded">${yieldPct}% Yield</span>
            </div>
            <div class="flex items-baseline justify-between">
              <span class="text-xl font-extrabold text-[#006644]">${baseDeheaded.toLocaleString('en-IN', { maximumFractionDigits: 1 })} <span class="text-xs font-semibold text-[#64748B]">KG</span></span>
              <span class="text-[11px] font-bold text-[#006644]">Benchmark ≥ 65%</span>
            </div>
            <span class="text-[11px] text-[#64748B] mt-1 block">33.1% head waste recovered for byproduct meal</span>
          </div>

          <!-- 3. Graded Output -->
          <div class="p-4 bg-white rounded-xl border border-[#DFE1E6] shadow-xs hover:border-[#02a8b5] transition-all">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84]">Graded HLSO</span>
              <span class="text-[10px] text-[#0284C7] font-bold bg-[#F0F9FF] px-1.5 py-0.5 rounded">16/20 Dominant</span>
            </div>
            <div class="flex items-baseline justify-between">
              <span class="text-xl font-extrabold text-[#0284C7]">${baseGraded.toLocaleString('en-IN', { maximumFractionDigits: 1 })} <span class="text-xs font-semibold text-[#64748B]">KG</span></span>
              <span class="text-[11px] font-bold text-[#0284C7]">99.7% Sized</span>
            </div>
            <span class="text-[11px] text-[#64748B] mt-1 block">Roller grader lines active in Unit-1 and Unit-2</span>
          </div>

          <!-- 4. Value Addition -->
          <div class="p-4 bg-white rounded-xl border border-[#DFE1E6] shadow-xs hover:border-[#02a8b5] transition-all">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84]">Value Addition Output</span>
              <span class="text-[10px] text-[#8F4D00] font-bold bg-[#FFF0B3] px-1.5 py-0.5 rounded">Nobashi / EZ</span>
            </div>
            <div class="flex items-baseline justify-between">
              <span class="text-xl font-extrabold text-[#0F172A]">${baseVa.toLocaleString('en-IN', { maximumFractionDigits: 1 })} <span class="text-xs font-semibold text-[#64748B]">KG</span></span>
              <span class="text-[11px] font-bold text-[#8F4D00]">67.2% Direct</span>
            </div>
            <span class="text-[11px] text-[#64748B] mt-1 block">Skewer, Nobashi, and EZ-peel specialty lines</span>
          </div>

          <!-- 5. HON Qty Transfer -->
          <div class="p-4 bg-white rounded-xl border border-[#DFE1E6] shadow-xs hover:border-[#02a8b5] transition-all">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84]">HON Transfer After VA</span>
              <span class="text-[10px] text-[#02a8b5] font-bold bg-[#F0FAFC] px-1.5 py-0.5 rounded">To Freezers</span>
            </div>
            <div class="flex items-baseline justify-between">
              <span class="text-xl font-extrabold text-[#0F172A]">${baseHonTransfer.toLocaleString('en-IN', { maximumFractionDigits: 1 })} <span class="text-xs font-semibold text-[#64748B]">KG</span></span>
              <span class="text-[11px] font-bold text-[#02a8b5]">Dispatched</span>
            </div>
            <span class="text-[11px] text-[#64748B] mt-1 block">Transferred to Contact plate & IQF tunnels</span>
          </div>

          <!-- 6. Chemical Inventory -->
          <div class="p-4 bg-white rounded-xl border border-[#DFE1E6] shadow-xs hover:border-[#02a8b5] transition-all">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[11px] font-bold uppercase tracking-wider text-[#5E6C84]">Chemical Inventory</span>
              <span class="text-[10px] text-[#006644] font-bold bg-[#E3FCEF] px-1.5 py-0.5 rounded">Stock Stable</span>
            </div>
            <div class="flex items-baseline justify-between">
              <span class="text-xl font-extrabold text-[#0F172A]">₹ ${baseChemValue} <span class="text-xs font-semibold text-[#64748B]">Cr</span></span>
              <span class="text-[11px] font-bold text-[#006644]">342.5 KG Today</span>
            </div>
            <span class="text-[11px] text-[#64748B] mt-1 block">30,500 KG bonded & floor chemical balance</span>
          </div>
        `;
      }
    };

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        <!-- 1. Header with Title & Action Controls -->
        <div class="flex flex-wrap items-center justify-between gap-3 mb-1">
          <div>
            <h1 class="text-xl font-extrabold text-[#172B4D] tracking-tight">Pre-Processing Floor Intelligence & Executive Dashboard</h1>
            <p class="text-xs text-[#5E6C84] mt-0.5 font-medium">Real-time floor summary, recovery telemetry, multi-plant sizing metrics & chemical balances</p>
          </div>
          <div class="flex items-center gap-2">
            <button class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs hover:shadow cursor-pointer transition-all" onclick="window.PreprocessingView.openChemPOModal()">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
              <span>Create Chemical PO</span>
            </button>
            <button class="px-3.5 py-2 bg-[#64748B] hover:bg-[#475569] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs hover:shadow cursor-pointer transition-all" onclick="window.Toast.show('Exporting Pre-Processing Summary Report to Excel...', 'info')">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              <span>Export Report</span>
            </button>
          </div>
        </div>

        <!-- 2. Quick Filter Bar -->
        <div class="bg-white rounded-xl border border-[#DFE1E6] p-3.5 shadow-xs">
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 items-end">
            <div>
              <label class="block text-[11px] font-bold text-[#5E6C84] uppercase tracking-wider mb-1">Plant Location</label>
              <select id="preproc-dash-plant" class="w-full text-xs px-3 py-1.5 bg-white border border-[#DFE1E6] rounded-lg font-semibold text-[#0F172A] focus:outline-none focus:border-[#02a8b5]">
                <option value="">All Processing Units</option>
                <option value="DFL UNIT-1 (VSP)">DFL UNIT-1 (VSP)</option>
                <option value="DFL UNIT-2 (KKD)">DFL UNIT-2 (KKD)</option>
                <option value="DFL UNIT-3 (PSP)">DFL UNIT-3 (PSP)</option>
              </select>
            </div>
            <div>
              <label class="block text-[11px] font-bold text-[#5E6C84] uppercase tracking-wider mb-1">Date Period</label>
              <select id="preproc-dash-period" class="w-full text-xs px-3 py-1.5 bg-white border border-[#DFE1E6] rounded-lg font-semibold text-[#0F172A] focus:outline-none focus:border-[#02a8b5]">
                <option value="Today" selected>Today (Shift A/B)</option>
                <option value="This Week">This Week (Mon-Sun)</option>
                <option value="Month to Date">Month to Date (October 2026)</option>
              </select>
            </div>
            <div>
              <label class="block text-[11px] font-bold text-[#5E6C84] uppercase tracking-wider mb-1">Species Filter</label>
              <select id="preproc-dash-species" class="w-full text-xs px-3 py-1.5 bg-white border border-[#DFE1E6] rounded-lg font-semibold text-[#0F172A] focus:outline-none focus:border-[#02a8b5]">
                <option value="">All Raw Materials</option>
                <option value="LITOPENAEUS VANNAMEI">LITOPENAEUS VANNAMEI</option>
                <option value="PENAEUS MONODON">PENAEUS MONODON</option>
                <option value="COD">COD</option>
              </select>
            </div>
            <div class="flex items-center gap-2">
              <button id="preproc-dash-apply-btn" class="flex-1 py-1.5 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <span>Filter</span>
              </button>
              <button id="preproc-dash-reset-btn" class="px-3.5 py-1.5 bg-[#64748B] hover:bg-[#475569] text-white text-xs font-bold rounded-lg shadow-xs transition-all cursor-pointer">
                ↺
              </button>
            </div>
          </div>
        </div>

        <!-- 3. 6 KPI Metric Cards Grid -->
        <div id="preproc-kpi-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3"></div>

        <!-- 4. Data Visualizations Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <!-- Chart 1: Volume & Throughput Trend -->
          <div class="bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs">
            <div class="flex items-center justify-between pb-2 mb-3 border-b border-[#EBECF0]">
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-[#02a8b5]"></span>
                <h3 class="text-xs font-bold text-[#172B4D]">Weekly Pre-Processing Throughput Trend (KG)</h3>
              </div>
              <span class="text-[11px] font-bold text-[#006644] bg-[#E3FCEF] px-2 py-0.5 rounded">Target: 12,000 KG / Day</span>
            </div>
            <div class="h-60 relative">
              <canvas id="productionChart" class="w-full h-full"></canvas>
            </div>
            <div class="flex items-center justify-between pt-2 border-t border-[#F1F5F9] text-[11px] text-[#64748B]">
              <span>Highest Peak: <strong>14,200 KG (Fri)</strong></span>
              <span>Average Daily Run: <strong>12,575 KG</strong></span>
            </div>
          </div>

          <!-- Chart 2: Yield Recovery by Size Grade -->
          <div class="bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs">
            <div class="flex items-center justify-between pb-2 mb-3 border-b border-[#EBECF0]">
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-[#0284C7]"></span>
                <h3 class="text-xs font-bold text-[#172B4D]">Recovery Yield Breakdown by Grade (%)</h3>
              </div>
              <span class="text-[11px] font-bold text-[#006644] bg-[#E3FCEF] px-2 py-0.5 rounded">Benchmark ≥ 65%</span>
            </div>
            <div class="h-60 relative">
              <canvas id="yieldChart" class="w-full h-full"></canvas>
            </div>
            <div class="flex items-center justify-between pt-2 border-t border-[#F1F5F9] text-[11px] text-[#64748B]">
              <span>Optimal Yield: <strong>16/20 @ 68.5%</strong></span>
              <span>Weighted Floor Avg: <strong>66.9%</strong></span>
            </div>
          </div>
        </div>

        <!-- 5. Secondary Data Cards: Stage Flow Telemetry & Chemical Inventory Matrix -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <!-- Flow Telemetry Card -->
          <div class="bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs">
            <div class="flex items-center justify-between pb-2 mb-3 border-b border-[#EBECF0]">
              <h3 class="text-xs font-bold text-[#172B4D]">Floor Flow & Process Stage Conversion</h3>
              <span class="text-[11px] text-[#5E6C84]">Shift A Telemetry</span>
            </div>
            <div class="space-y-3">
              <div>
                <div class="flex justify-between text-xs font-semibold mb-1">
                  <span class="text-[#0F172A]">1. Raw Intake Received</span>
                  <span class="text-[#02a8b5]">13,030 KG (100%)</span>
                </div>
                <div class="w-full bg-[#F1F5F9] rounded-full h-2">
                  <div class="bg-[#02a8b5] h-2 rounded-full" style="width: 100%"></div>
                </div>
              </div>
              <div>
                <div class="flex justify-between text-xs font-semibold mb-1">
                  <span class="text-[#0F172A]">2. Deheaded Meat Output</span>
                  <span class="text-[#006644]">8,722.5 KG (66.9% Recovery)</span>
                </div>
                <div class="w-full bg-[#F1F5F9] rounded-full h-2">
                  <div class="bg-[#006644] h-2 rounded-full" style="width: 66.9%"></div>
                </div>
              </div>
              <div>
                <div class="flex justify-between text-xs font-semibold mb-1">
                  <span class="text-[#0F172A]">3. Roller Graded & Sized</span>
                  <span class="text-[#0284C7]">8,695 KG (99.7% Sizing Accuracy)</span>
                </div>
                <div class="w-full bg-[#F1F5F9] rounded-full h-2">
                  <div class="bg-[#0284C7] h-2 rounded-full" style="width: 66.7%"></div>
                </div>
              </div>
              <div>
                <div class="flex justify-between text-xs font-semibold mb-1">
                  <span class="text-[#0F172A]">4. Value Addition Allocated</span>
                  <span class="text-[#8F4D00]">5,840 KG (67.2% Direct VA)</span>
                </div>
                <div class="w-full bg-[#F1F5F9] rounded-full h-2">
                  <div class="bg-[#8F4D00] h-2 rounded-full" style="width: 44.8%"></div>
                </div>
              </div>
              <div>
                <div class="flex justify-between text-xs font-semibold mb-1">
                  <span class="text-[#0F172A]">5. HON Freezer Transfer Dispatched</span>
                  <span class="text-[#02a8b5]">4,200 KG (Packed & Dispatched)</span>
                </div>
                <div class="w-full bg-[#F1F5F9] rounded-full h-2">
                  <div class="bg-[#02a8b5] h-2 rounded-full" style="width: 32.2%"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Chemical Bath Matrix Card -->
          <div class="bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs">
            <div class="flex items-center justify-between pb-2 mb-3 border-b border-[#EBECF0]">
              <h3 class="text-xs font-bold text-[#172B4D]">Active Chemical Bath Dosage & Stock Balance</h3>
              <a href="#/preprocessing/chemical-screens/chemical-pos" class="text-[11px] font-bold text-[#02a8b5] hover:underline">View Chemical Pos →</a>
            </div>
            <div class="space-y-3">
              <div class="p-2.5 bg-[#FAFBFC] rounded-lg border border-[#EBECF0] flex items-center justify-between">
                <div>
                  <span class="text-xs font-bold text-[#0F172A]">ALTESA NEO S100 (NP)</span>
                  <span class="text-[11px] text-[#64748B] block">Non-phosphate treatment bath · Unit-1 (VSP)</span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-extrabold text-[#0F172A]">1,250 KG Stock</span>
                  <span class="text-[11px] text-[#006644] font-semibold block">Dosed: 85 KG</span>
                </div>
              </div>
              <div class="p-2.5 bg-[#FAFBFC] rounded-lg border border-[#EBECF0] flex items-center justify-between">
                <div>
                  <span class="text-xs font-bold text-[#0F172A]">CARNAL 659 S ADVANCED (STPP)</span>
                  <span class="text-[11px] text-[#64748B] block">Standard moisture retention · Unit-5 (JPT)</span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-extrabold text-[#0F172A]">920 KG Stock</span>
                  <span class="text-[11px] text-[#006644] font-semibold block">Dosed: 120 KG</span>
                </div>
              </div>
              <div class="p-2.5 bg-[#FAFBFC] rounded-lg border border-[#EBECF0] flex items-center justify-between">
                <div>
                  <span class="text-xs font-bold text-[#0F172A]">CARFOSEL B 940 (STPP)</span>
                  <span class="text-[11px] text-[#64748B] block">Export grade soaking line · Unit-2 (KKD)</span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-extrabold text-[#0F172A]">1,580 KG Stock</span>
                  <span class="text-[11px] text-[#006644] font-semibold block">Dosed: 95 KG</span>
                </div>
              </div>
              <div class="p-2.5 bg-[#FAFBFC] rounded-lg border border-[#EBECF0] flex items-center justify-between">
                <div>
                  <span class="text-xs font-bold text-[#0F172A]">BEKAPLUS FS (BLEND)</span>
                  <span class="text-[11px] text-[#64748B] block">Specialty glaze preservation · Temp Controlled</span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-extrabold text-[#0F172A]">640 KG Stock</span>
                  <span class="text-[11px] text-[#006644] font-semibold block">Dosed: 42.5 KG</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 6. Active Plant-Wise Pre-Processing Floor Telemetry Table -->
        <div class="bg-white rounded-xl border border-[#DFE1E6] p-4 shadow-xs">
          <div class="flex items-center justify-between pb-3 mb-3 border-b border-[#EBECF0]">
            <div>
              <h3 class="text-xs font-bold text-[#172B4D]">Plant-Wise Floor Operations & Intake Batch Telemetry</h3>
              <p class="text-[11px] text-[#5E6C84]">Active lines across Visakhapatnam, Kakinada, and Pasarlapudi facilities</p>
            </div>
            <span class="text-xs font-bold text-[#02a8b5] bg-[#F0FAFC] px-2.5 py-1 rounded-lg border border-[#02a8b5]/20">3 Plants Active</span>
          </div>

          <div class="overflow-x-auto border border-[#E2E8F0] rounded-xl">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-[#F8FAFC] border-b border-[#E2E8F0] text-[11px] font-bold text-[#475569] uppercase tracking-wider">
                  <th class="px-4 py-3">Plant Facility</th>
                  <th class="px-4 py-3">Raw Intake (KG)</th>
                  <th class="px-4 py-3">Deheaded Output (KG)</th>
                  <th class="px-4 py-3">Recovery Yield (%)</th>
                  <th class="px-4 py-3">Graded Output (KG)</th>
                  <th class="px-4 py-3">Value Addition (KG)</th>
                  <th class="px-4 py-3">Chemical Bath</th>
                  <th class="px-4 py-3">Line Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#F1F5F9]">
                <tr class="hover:bg-[#F8FAFC] transition-colors">
                  <td class="px-4 py-3 font-bold text-[#0F172A]">DFL UNIT-1 (VSP)</td>
                  <td class="px-4 py-3 font-semibold text-[#0F172A]">4,800.0</td>
                  <td class="px-4 py-3 font-semibold text-[#006644]">3,216.0</td>
                  <td class="px-4 py-3 font-bold text-[#006644]">67.0%</td>
                  <td class="px-4 py-3 text-[#0F172A]">3,205.0</td>
                  <td class="px-4 py-3 text-[#0F172A]">2,150.0</td>
                  <td class="px-4 py-3 text-[#64748B]">ALTESA NEO S100</td>
                  <td class="px-4 py-3"><span class="px-2 py-0.5 rounded text-[10.5px] font-bold bg-[#E3FCEF] text-[#006644]">Running</span></td>
                </tr>
                <tr class="hover:bg-[#F8FAFC] transition-colors">
                  <td class="px-4 py-3 font-bold text-[#0F172A]">DFL UNIT-2 (KKD)</td>
                  <td class="px-4 py-3 font-semibold text-[#0F172A]">5,230.0</td>
                  <td class="px-4 py-3 font-semibold text-[#006644]">3,498.9</td>
                  <td class="px-4 py-3 font-bold text-[#006644]">66.9%</td>
                  <td class="px-4 py-3 text-[#0F172A]">3,490.0</td>
                  <td class="px-4 py-3 text-[#0F172A]">2,340.0</td>
                  <td class="px-4 py-3 text-[#64748B]">CARFOSEL B 940</td>
                  <td class="px-4 py-3"><span class="px-2 py-0.5 rounded text-[10.5px] font-bold bg-[#E3FCEF] text-[#006644]">Running</span></td>
                </tr>
                <tr class="hover:bg-[#F8FAFC] transition-colors">
                  <td class="px-4 py-3 font-bold text-[#0F172A]">DFL UNIT-3 (PSP)</td>
                  <td class="px-4 py-3 font-semibold text-[#0F172A]">3,000.0</td>
                  <td class="px-4 py-3 font-semibold text-[#006644]">2,007.6</td>
                  <td class="px-4 py-3 font-bold text-[#006644]">66.9%</td>
                  <td class="px-4 py-3 text-[#0F172A]">2,000.0</td>
                  <td class="px-4 py-3 text-[#0F172A]">1,350.0</td>
                  <td class="px-4 py-3 text-[#64748B]">CARNAL 659 S</td>
                  <td class="px-4 py-3"><span class="px-2 py-0.5 rounded text-[10.5px] font-bold bg-[#F0F9FF] text-[#0284C7]">Completed</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    document.getElementById('preproc-dash-apply-btn')?.addEventListener('click', () => {
      fPlant = document.getElementById('preproc-dash-plant')?.value || '';
      fPeriod = document.getElementById('preproc-dash-period')?.value || 'Today';
      fSpecies = document.getElementById('preproc-dash-species')?.value || '';
      updateDashboard();
      this.drawDashboardCharts();
      if (window.Toast) window.Toast.show(`Telemetry filtered for ${fPeriod} (${fPlant || 'All Plants'})`, 'info');
    });

    document.getElementById('preproc-dash-reset-btn')?.addEventListener('click', () => {
      const p = document.getElementById('preproc-dash-plant');
      const pr = document.getElementById('preproc-dash-period');
      const s = document.getElementById('preproc-dash-species');
      if (p) p.value = '';
      if (pr) pr.value = 'Today';
      if (s) s.value = '';
      fPlant = ''; fPeriod = 'Today'; fSpecies = '';
      updateDashboard();
      this.drawDashboardCharts();
      if (window.Toast) window.Toast.show('Dashboard filters reset.', 'info');
    });

    updateDashboard();

    setTimeout(() => {
      this.drawDashboardCharts();
    }, 60);
  },

  drawDashboardCharts() {
    const c1 = document.getElementById('productionChart');
    if (c1 && c1.parentElement) {
      const dpr = window.devicePixelRatio || 1;
      const rect = c1.parentElement.getBoundingClientRect();
      c1.width = (rect.width || 400) * dpr;
      c1.height = (rect.height || 240) * dpr;
      const ctx = c1.getContext('2d');
      ctx.scale(dpr, dpr);
      const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const data = [11200, 12400, 10800, 13030, 14200, 12800, 13600];
      const maxVal = 16000;
      const padLeft = 45, padRight = 20, padTop = 20, padBottom = 25;
      const chartW = rect.width - padLeft - padRight;
      const chartH = rect.height - padTop - padBottom;
      
      // Grid lines
      ctx.strokeStyle = '#F1F5F9';
      ctx.lineWidth = 1;
      ctx.fillStyle = '#64748B';
      ctx.font = '10px Inter, sans-serif';
      ctx.textAlign = 'right';
      for (let i = 0; i <= 4; i++) {
        const yVal = Math.round((maxVal / 4) * i);
        const y = padTop + chartH - (i / 4) * chartH;
        ctx.beginPath();
        ctx.moveTo(padLeft, y);
        ctx.lineTo(rect.width - padRight, y);
        ctx.stroke();
        ctx.fillText(yVal.toLocaleString(), padLeft - 6, y + 3);
      }

      // Benchmark Target line (12,000)
      const targetY = padTop + chartH - (12000 / maxVal) * chartH;
      ctx.beginPath();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = '#94A3B8';
      ctx.lineWidth = 1.2;
      ctx.moveTo(padLeft, targetY);
      ctx.lineTo(rect.width - padRight, targetY);
      ctx.stroke();
      ctx.setLineDash([]);

      // Fill area under curve
      const grad = ctx.createLinearGradient(0, padTop, 0, padTop + chartH);
      grad.addColorStop(0, 'rgba(2, 168, 181, 0.25)');
      grad.addColorStop(1, 'rgba(2, 168, 181, 0.00)');
      
      ctx.beginPath();
      data.forEach((val, idx) => {
        const x = padLeft + (idx / (data.length - 1)) * chartW;
        const y = padTop + chartH - (val / maxVal) * chartH;
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.lineTo(padLeft + chartW, padTop + chartH);
      ctx.lineTo(padLeft, padTop + chartH);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      // Line stroke
      ctx.beginPath();
      ctx.strokeStyle = '#02a8b5';
      ctx.lineWidth = 2.5;
      data.forEach((val, idx) => {
        const x = padLeft + (idx / (data.length - 1)) * chartW;
        const y = padTop + chartH - (val / maxVal) * chartH;
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      // Data dots
      data.forEach((val, idx) => {
        const x = padLeft + (idx / (data.length - 1)) * chartW;
        const y = padTop + chartH - (val / maxVal) * chartH;
        ctx.beginPath();
        ctx.arc(x, y, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = '#02a8b5';
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      });

      // Labels
      ctx.fillStyle = '#475569';
      ctx.textAlign = 'center';
      labels.forEach((lbl, idx) => {
        const x = padLeft + (idx / (labels.length - 1)) * chartW;
        ctx.fillText(lbl, x, rect.height - 8);
      });
    }

    const c2 = document.getElementById('yieldChart');
    if (c2 && c2.parentElement) {
      const dpr = window.devicePixelRatio || 1;
      const rect = c2.parentElement.getBoundingClientRect();
      c2.width = (rect.width || 400) * dpr;
      c2.height = (rect.height || 240) * dpr;
      const ctx = c2.getContext('2d');
      ctx.scale(dpr, dpr);
      const grades = ['16/20', '21/25', '26/30', '31/40', '41/50'];
      const yields = [68.5, 67.2, 66.0, 64.8, 63.5];
      const padLeft = 45, padRight = 20, padTop = 20, padBottom = 25;
      const chartW = rect.width - padLeft - padRight;
      const chartH = rect.height - padTop - padBottom;
      const barW = chartW / (grades.length * 2);

      // Y-axis
      ctx.fillStyle = '#64748B';
      ctx.font = '10px Inter, sans-serif';
      ctx.textAlign = 'right';
      for (let i = 0; i <= 4; i++) {
        const yVal = 50 + i * 5;
        const y = padTop + chartH - (i / 4) * chartH;
        ctx.beginPath();
        ctx.strokeStyle = '#F1F5F9';
        ctx.lineWidth = 1;
        ctx.moveTo(padLeft, y);
        ctx.lineTo(rect.width - padRight, y);
        ctx.stroke();
        ctx.fillText(yVal + '%', padLeft - 6, y + 3);
      }

      // Benchmark 65% line
      const benchY = padTop + chartH - ((65 - 50) / 20) * chartH;
      ctx.beginPath();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = '#056A38';
      ctx.lineWidth = 1.2;
      ctx.moveTo(padLeft, benchY);
      ctx.lineTo(rect.width - padRight, benchY);
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw bars
      grades.forEach((g, idx) => {
        const x = padLeft + idx * (barW * 2) + barW / 2;
        const h = ((yields[idx] - 50) / 20) * chartH;
        const y = padTop + chartH - h;
        
        ctx.fillStyle = idx === 0 ? '#02a8b5' : idx === 1 ? '#008f9a' : '#38bdf8';
        ctx.beginPath();
        ctx.roundRect(x, y, barW, h, [4, 4, 0, 0]);
        ctx.fill();

        // Value text
        ctx.fillStyle = '#0F172A';
        ctx.font = 'bold 9.5px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(yields[idx] + '%', x + barW / 2, y - 4);

        // Grade label
        ctx.fillStyle = '#475569';
        ctx.font = '10px Inter, sans-serif';
        ctx.fillText(g, x + barW / 2, rect.height - 8);
      });
    }
  },

  // ============================================
  // 2. CHEMICAL INVENTORY & USAGE (FIXES IMAGE 1)
  // ============================================
  renderChemicalPos(container) {
    if (!this.chemicalPosList || this.chemicalPosList.length === 0 || !this.chemicalPosList.some(x => x.poNo === 'DFL/KPL/2627/004')) {
      this.chemicalPosList = [
        { id: "CPO-01", sNo: 1, supplierName: "KPL INTERNATIONAL LTD", poNo: "DFL/KPL/2627/004", poDate: "06-10-2026", chemicals: "", portName: "INPRT - PARADIP GARH", modeOfImport: "HSS", qtyBags: "", qtyKgs: "", totalAmount: "", etdDate: "", etaDate: "", remarks: "" },
        { id: "CPO-02", sNo: 2, supplierName: "ADWIK IMPEX,", poNo: "DFL/2627/003", poDate: "25-09-2026", chemicals: "", portName: "INKAK1 - KAKINADA", modeOfImport: "HSS", qtyBags: "", qtyKgs: "", totalAmount: "", etdDate: "30-09-2026", etaDate: "29-10-2026", remarks: "no" },
        { id: "CPO-03", sNo: 3, supplierName: "KPL INTERNATIONAL LTD", poNo: "DFL/KPL/2627/003", poDate: "07-09-2026", chemicals: "ALTESA NEO S100 (NP)", portName: "", modeOfImport: "HSS_BOND", qtyBags: "240", qtyKgs: "4800", totalAmount: "868800", etdDate: "", etaDate: "", remarks: "" },
        { id: "CPO-04", sNo: 4, supplierName: "PRAYON PHOSPHATES", poNo: "DFL/PP/2627/002", poDate: "18-08-2026", chemicals: "CARFOSEL B 940 (STPP)", portName: "INVTZ1 - VISAKHAPATNAM", modeOfImport: "DIRECT IMPORT", qtyBags: "400", qtyKgs: "10000", totalAmount: "1650000", etdDate: "25-08-2026", etaDate: "15-09-2026", remarks: "Standard pass" }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">CHEMICAL POS</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Chemical Screens &bull; Purchase Order Tracking</span>
        </div>

        <!-- Upper Card: Filters Card (Matching Screenshot 1) -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="cpo-filter-form" class="space-y-4">
            <!-- Row 1: 4 Dropdowns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPPLIER</label>
                <select id="cpo-filter-supplier" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All" selected>All</option>
                  <option value="KPL INTERNATIONAL LTD">KPL INTERNATIONAL LTD</option>
                  <option value="ADWIK IMPEX,">ADWIK IMPEX,</option>
                  <option value="PRAYON PHOSPHATES">PRAYON PHOSPHATES</option>
                  <option value="ICL FOOD SPECIALTIES">ICL FOOD SPECIALTIES</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PO NO</label>
                <select id="cpo-filter-pono" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All" selected>All</option>
                  <option value="DFL/KPL/2627/004">DFL/KPL/2627/004</option>
                  <option value="DFL/2627/003">DFL/2627/003</option>
                  <option value="DFL/KPL/2627/003">DFL/KPL/2627/003</option>
                  <option value="DFL/PP/2627/002">DFL/PP/2627/002</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">CHEMICAL</label>
                <select id="cpo-filter-chemical" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All" selected>All</option>
                  <option value="ALTESA NEO S100 (NP)">ALTESA NEO S100 (NP)</option>
                  <option value="CARNAL 659 S ADVANCED (STPP)">CARNAL 659 S ADVANCED (STPP)</option>
                  <option value="CARFOSEL B 940 (STPP)">CARFOSEL B 940 (STPP)</option>
                  <option value="BEKAPLUS FS (BLEND)">BEKAPLUS FS (BLEND)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PORT</label>
                <select id="cpo-filter-port" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All" selected>All</option>
                  <option value="INPRT - PARADIP GARH">INPRT - PARADIP GARH</option>
                  <option value="INKAK1 - KAKINADA">INKAK1 - KAKINADA</option>
                  <option value="INVTZ1 - VISAKHAPATNAM">INVTZ1 - VISAKHAPATNAM</option>
                  <option value="INMAA1 - CHENNAI">INMAA1 - CHENNAI</option>
                </select>
              </div>
            </div>

            <!-- Row 2: 4 Columns (YEAR) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">YEAR</label>
                <select id="cpo-filter-year" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="2026-27" selected>2026-27</option>
                  <option value="2025-26">2025-26</option>
                  <option value="2024-25">2024-25</option>
                </select>
              </div>
            </div>

            <!-- Centered Action Buttons (Matching Screenshot 1) -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="button" id="cpo-btn-search" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer">
                <span>Search</span>
                <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
              </button>
              <button type="button" id="cpo-btn-add-po" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                <span>+ Add PO</span>
              </button>
            </div>
          </form>
        </div>

        <!-- Create/Edit Form Card: GS CHEM PO CREATE (Matching Screenshot 2) -->
        <div id="cpo-create-card" class="hidden bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all animate-fade-in">
          <div class="flex items-center justify-between pb-3 mb-3 border-b border-[#E2E8F0]">
            <h3 id="cpo-create-title" class="text-xs md:text-sm font-bold text-[#1E293B] uppercase tracking-wide">GS CHEM PO CREATE</h3>
            <button type="button" id="cpo-card-close-x" class="text-[#64748B] hover:text-[#1E293B] text-lg font-bold cursor-pointer transition-colors">&times;</button>
          </div>
          <form id="cpo-create-form" class="space-y-4">
            <input type="hidden" id="cpo-edit-id" value="">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPPLIER <span class="text-red-500 font-bold">*</span></label>
                <select id="cpo-create-supplier" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All">All</option>
                  <option value="KPL INTERNATIONAL LTD" selected>KPL INTERNATIONAL LTD</option>
                  <option value="ADWIK IMPEX,">ADWIK IMPEX,</option>
                  <option value="PRAYON PHOSPHATES">PRAYON PHOSPHATES</option>
                  <option value="ICL FOOD SPECIALTIES">ICL FOOD SPECIALTIES</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PORT NAME</label>
                <select id="cpo-create-port" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="INPRT - PARADIP GARH" selected>INPRT - PARADIP GARH</option>
                  <option value="INKAK1 - KAKINADA">INKAK1 - KAKINADA</option>
                  <option value="INVTZ1 - VISAKHAPATNAM">INVTZ1 - VISAKHAPATNAM</option>
                  <option value="INMAA1 - CHENNAI">INMAA1 - CHENNAI</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">MODE OF IMPORT <span class="text-red-500 font-bold">*</span></label>
                <select id="cpo-create-mode" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="HSS" selected>HSS</option>
                  <option value="HSS_BOND">HSS_BOND</option>
                  <option value="DIRECT IMPORT">DIRECT IMPORT</option>
                  <option value="BOND TRANSFER">BOND TRANSFER</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PO NO <span class="text-red-500 font-bold">*</span></label>
                <input type="text" id="cpo-create-pono" placeholder="Enter Po NO" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 2: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PO DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="cpo-create-podate" required value="2026-10-23" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ETA DATE</label>
                <input type="date" id="cpo-create-etadate" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ETD DATE</label>
                <input type="date" id="cpo-create-etddate" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">REMARKS</label>
                <input type="text" id="cpo-create-remarks" placeholder="Enter Remarks" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Centered Buttons: Close & Save (Matching Screenshot 2) -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="button" id="cpo-btn-close-form" class="px-6 py-2 bg-[#F43F5E] hover:bg-[#E11D48] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Close
              </button>
              <button type="submit" id="cpo-btn-save-form" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table with Search & Excel Export (Matching Screenshot 1) -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="cpo-table-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="cpo-btn-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.NO</th>
                  <th class="py-2.5 px-3">Supplier Name</th>
                  <th class="py-2.5 px-3">PoNo</th>
                  <th class="py-2.5 px-3">PO Date</th>
                  <th class="py-2.5 px-3">Chemicals</th>
                  <th class="py-2.5 px-3">Port Name</th>
                  <th class="py-2.5 px-3">Mode of Import</th>
                  <th class="py-2.5 px-3 text-right">Quantity(Bags)</th>
                  <th class="py-2.5 px-3 text-right">Quantity(KGs)</th>
                  <th class="py-2.5 px-3 text-right">Total Amount</th>
                  <th class="py-2.5 px-3">ETD Date</th>
                  <th class="py-2.5 px-3">ETA Date</th>
                  <th class="py-2.5 px-3">Remarks</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="cpo-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>
        </div>

        <!-- Add Chemical Line Modal -->
        <div id="cpo-line-modal" class="hidden fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div class="bg-white rounded-xl shadow-xl border border-[#CBD5E1] w-full max-w-md p-5 space-y-4 animate-fade-in">
            <div class="flex items-center justify-between pb-2 border-b border-[#E2E8F0]">
              <h4 class="text-xs font-bold text-[#1E293B] uppercase">Add / Update Chemical Specification</h4>
              <button type="button" id="cpo-line-close" class="text-[#64748B] hover:text-[#1E293B] text-lg font-bold cursor-pointer">&times;</button>
            </div>
            <form id="cpo-line-form" class="space-y-3">
              <input type="hidden" id="cpo-line-target-id" value="">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1">Chemical Specification</label>
                <select id="cpo-line-chem" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5]">
                  <option value="ALTESA NEO S100 (NP)">ALTESA NEO S100 (NP)</option>
                  <option value="CARNAL 659 S ADVANCED (STPP)">CARNAL 659 S ADVANCED (STPP)</option>
                  <option value="CARFOSEL B 940 (STPP)">CARFOSEL B 940 (STPP)</option>
                  <option value="BEKAPLUS FS (BLEND)">BEKAPLUS FS (BLEND)</option>
                </select>
              </div>
              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1">Quantity (Bags)</label>
                  <input type="number" id="cpo-line-bags" value="240" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5]">
                </div>
                <div>
                  <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1">Quantity (KGs)</label>
                  <input type="number" id="cpo-line-kgs" value="4800" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5]">
                </div>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1">Total Amount (INR)</label>
                <input type="number" id="cpo-line-amount" value="868800" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5]">
              </div>
              <div class="flex items-center justify-end gap-2 pt-2">
                <button type="button" id="cpo-line-cancel" class="px-4 py-1.5 bg-[#E2E8F0] hover:bg-[#CBD5E1] text-[#334155] text-xs font-semibold rounded-lg cursor-pointer">Cancel</button>
                <button type="submit" class="px-5 py-1.5 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg cursor-pointer">Save Line</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('cpo-table-body');
    const tableSearch = document.getElementById('cpo-table-search');
    const createCard = document.getElementById('cpo-create-card');
    const createForm = document.getElementById('cpo-create-form');
    const createTitle = document.getElementById('cpo-create-title');
    const editIdInput = document.getElementById('cpo-edit-id');
    const btnAddPo = document.getElementById('cpo-btn-add-po');
    const btnCloseForm = document.getElementById('cpo-btn-close-form');
    const btnCloseX = document.getElementById('cpo-card-close-x');
    const btnSearch = document.getElementById('cpo-btn-search');
    const btnExportExcel = document.getElementById('cpo-btn-export-excel');

    const filterSupplier = document.getElementById('cpo-filter-supplier');
    const filterPono = document.getElementById('cpo-filter-pono');
    const filterChemical = document.getElementById('cpo-filter-chemical');
    const filterPort = document.getElementById('cpo-filter-port');

    // Line modal elements
    const lineModal = document.getElementById('cpo-line-modal');
    const lineForm = document.getElementById('cpo-line-form');
    const lineTargetId = document.getElementById('cpo-line-target-id');
    const lineClose = document.getElementById('cpo-line-close');
    const lineCancel = document.getElementById('cpo-line-cancel');

    const renderTable = (query = '') => {
      const q = (query || '').toLowerCase().trim();
      const supFilter = filterSupplier?.value || 'All';
      const poFilter = filterPono?.value || 'All';
      const chemFilter = filterChemical?.value || 'All';
      const portFilter = filterPort?.value || 'All';

      const filtered = this.chemicalPosList.filter(r => {
        if (supFilter !== 'All' && r.supplierName !== supFilter) return false;
        if (poFilter !== 'All' && r.poNo !== poFilter) return false;
        if (chemFilter !== 'All' && r.chemicals !== chemFilter) return false;
        if (portFilter !== 'All' && r.portName !== portFilter) return false;

        if (!q) return true;
        const text = `${r.supplierName || ''} ${r.poNo || ''} ${r.chemicals || ''} ${r.portName || ''} ${r.modeOfImport || ''} ${r.remarks || ''}`.toLowerCase();
        return text.includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="14" class="py-8 text-center text-xs text-[#64748B]">
              No chemical purchase orders match the selected filters.
            </td>
          </tr>
        `;
        return;
      }

      tbody.innerHTML = filtered.map((r, i) => `
        <tr class="hover:bg-[#F8FAFC] transition-colors border-b border-[#E2E8F0]">
          <td class="py-2.5 px-3 font-semibold text-[#64748B]">${i + 1}</td>
          <td class="py-2.5 px-3 font-medium text-[#1E293B]">${r.supplierName || ''}</td>
          <td class="py-2.5 px-3 font-mono font-medium text-[#1E293B]">${r.poNo || ''}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.poDate || ''}</td>
          <td class="py-2.5 px-3 text-[#1E293B] font-medium">${r.chemicals || ''}</td>
          <td class="py-2.5 px-3 text-[#475569]">${r.portName || ''}</td>
          <td class="py-2.5 px-3 font-semibold text-[#1E293B]">${r.modeOfImport || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.qtyBags || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.qtyKgs || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.totalAmount || ''}</td>
          <td class="py-2.5 px-3 text-[#475569]">${r.etdDate || ''}</td>
          <td class="py-2.5 px-3 text-[#475569]">${r.etaDate || ''}</td>
          <td class="py-2.5 px-3 text-[#475569]">${r.remarks || ''}</td>
          <td class="py-2.5 px-3 text-center">
            <div class="inline-flex items-center justify-center gap-1.5">
              <!-- Edit Icon (Pencil) -->
              <button type="button" title="Edit PO" class="cpo-action-edit p-1 text-[#0284C7] hover:text-[#02a8b5] hover:bg-[#F0F9FF] rounded transition-colors cursor-pointer" data-id="${r.id}">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
              </button>
              <!-- Plus Icon (Add Chemical Line) -->
              <button type="button" title="Add Line Items" class="cpo-action-addline p-1 text-[#0284C7] hover:text-[#02a8b5] hover:bg-[#F0F9FF] rounded transition-colors cursor-pointer" data-id="${r.id}">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
              </button>
              <!-- Print Icon (Printer) -->
              <button type="button" title="Print PO" class="cpo-action-print p-1 text-[#0284C7] hover:text-[#02a8b5] hover:bg-[#F0F9FF] rounded transition-colors cursor-pointer" data-id="${r.id}">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
              </button>
              <!-- Document Icon -->
              <button type="button" title="View Document" class="cpo-action-doc p-1 text-[#0284C7] hover:text-[#02a8b5] hover:bg-[#F0F9FF] rounded transition-colors cursor-pointer" data-id="${r.id}">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('');

      // Attach row action handlers
      tbody.querySelectorAll('.cpo-action-edit').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const rec = this.chemicalPosList.find(x => x.id === id);
          if (!rec) return;
          createTitle.textContent = `GS CHEM PO EDIT - ${rec.poNo}`;
          editIdInput.value = rec.id;
          document.getElementById('cpo-create-supplier').value = rec.supplierName || 'All';
          document.getElementById('cpo-create-port').value = rec.portName || '';
          document.getElementById('cpo-create-mode').value = rec.modeOfImport || 'HSS';
          document.getElementById('cpo-create-pono').value = rec.poNo || '';
          document.getElementById('cpo-create-remarks').value = rec.remarks || '';
          
          // Format date to yyyy-mm-dd for input[type=date]
          if (rec.poDate && rec.poDate.includes('-')) {
            const parts = rec.poDate.split('-');
            if (parts[0].length === 2) {
              document.getElementById('cpo-create-podate').value = `${parts[2]}-${parts[1]}-${parts[0]}`;
            } else {
              document.getElementById('cpo-create-podate').value = rec.poDate;
            }
          }
          if (rec.etaDate && rec.etaDate.includes('-')) {
            const parts = rec.etaDate.split('-');
            if (parts[0].length === 2) {
              document.getElementById('cpo-create-etadate').value = `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
          }
          if (rec.etdDate && rec.etdDate.includes('-')) {
            const parts = rec.etdDate.split('-');
            if (parts[0].length === 2) {
              document.getElementById('cpo-create-etddate').value = `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
          }

          createCard.classList.remove('hidden');
          createCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
      });

      tbody.querySelectorAll('.cpo-action-addline').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const rec = this.chemicalPosList.find(x => x.id === id);
          if (!rec) return;
          lineTargetId.value = rec.id;
          if (rec.chemicals) document.getElementById('cpo-line-chem').value = rec.chemicals;
          if (rec.qtyBags) document.getElementById('cpo-line-bags').value = rec.qtyBags;
          if (rec.qtyKgs) document.getElementById('cpo-line-kgs').value = rec.qtyKgs;
          if (rec.totalAmount) document.getElementById('cpo-line-amount').value = rec.totalAmount;
          lineModal.classList.remove('hidden');
        });
      });

      tbody.querySelectorAll('.cpo-action-print').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const rec = this.chemicalPosList.find(x => x.id === id);
          if (window.Toast) window.Toast.show(`Printing Purchase Order ${rec?.poNo || ''}...`, 'info');
        });
      });

      tbody.querySelectorAll('.cpo-action-doc').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const rec = this.chemicalPosList.find(x => x.id === id);
          if (window.Toast) window.Toast.show(`Viewing Order Document for ${rec?.poNo || ''}`, 'info');
        });
      });
    };

    // Initial render
    renderTable();

    // Table live search
    tableSearch?.addEventListener('input', (e) => renderTable(e.target.value));

    // Top Filter Search button
    btnSearch?.addEventListener('click', () => {
      renderTable(tableSearch?.value || '');
      if (window.Toast) window.Toast.show('Applied chemical PO filters', 'info');
    });

    // Toggle GS CHEM PO CREATE card
    btnAddPo?.addEventListener('click', () => {
      createTitle.textContent = 'GS CHEM PO CREATE';
      editIdInput.value = '';
      createForm.reset();
      document.getElementById('cpo-create-podate').value = new Date().toISOString().slice(0, 10);
      createCard.classList.remove('hidden');
      createCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });

    const hideCreateCard = () => {
      createCard.classList.add('hidden');
      createForm.reset();
      editIdInput.value = '';
    };

    btnCloseForm?.addEventListener('click', hideCreateCard);
    btnCloseX?.addEventListener('click', hideCreateCard);

    // Save GS CHEM PO CREATE form
    createForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      const editId = editIdInput.value;
      const supplier = document.getElementById('cpo-create-supplier').value;
      const port = document.getElementById('cpo-create-port').value;
      const mode = document.getElementById('cpo-create-mode').value;
      const pono = document.getElementById('cpo-create-pono').value;
      const podateRaw = document.getElementById('cpo-create-podate').value;
      const etadateRaw = document.getElementById('cpo-create-etadate').value;
      const etddateRaw = document.getElementById('cpo-create-etddate').value;
      const remarks = document.getElementById('cpo-create-remarks').value;

      const fmtDate = (d) => {
        if (!d) return '';
        const parts = d.split('-');
        if (parts.length === 3) return `${parts[2]}-${parts[1]}-${parts[0]}`;
        return d;
      };

      if (editId) {
        const idx = this.chemicalPosList.findIndex(x => x.id === editId);
        if (idx !== -1) {
          this.chemicalPosList[idx] = {
            ...this.chemicalPosList[idx],
            supplierName: supplier,
            portName: port,
            modeOfImport: mode,
            poNo: pono,
            poDate: fmtDate(podateRaw),
            etaDate: fmtDate(etadateRaw),
            etdDate: fmtDate(etddateRaw),
            remarks: remarks
          };
          if (window.Toast) window.Toast.show(`Chemical PO ${pono} updated successfully`, 'success');
        }
      } else {
        const newRecord = {
          id: 'CPO-' + String(Date.now()).slice(-6),
          sNo: this.chemicalPosList.length + 1,
          supplierName: supplier,
          poNo: pono,
          poDate: fmtDate(podateRaw),
          chemicals: '',
          portName: port,
          modeOfImport: mode,
          qtyBags: '',
          qtyKgs: '',
          totalAmount: '',
          etdDate: fmtDate(etddateRaw),
          etaDate: fmtDate(etadateRaw),
          remarks: remarks
        };
        this.chemicalPosList.unshift(newRecord);
        if (window.Toast) window.Toast.show(`New Chemical PO ${pono} created successfully`, 'success');
      }

      hideCreateCard();
      renderTable(tableSearch?.value || '');
    });

    // Line modal actions
    lineClose?.addEventListener('click', () => lineModal.classList.add('hidden'));
    lineCancel?.addEventListener('click', () => lineModal.classList.add('hidden'));
    lineForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      const targetId = lineTargetId.value;
      const rec = this.chemicalPosList.find(x => x.id === targetId);
      if (rec) {
        rec.chemicals = document.getElementById('cpo-line-chem').value;
        rec.qtyBags = document.getElementById('cpo-line-bags').value;
        rec.qtyKgs = document.getElementById('cpo-line-kgs').value;
        rec.totalAmount = document.getElementById('cpo-line-amount').value;
        lineModal.classList.add('hidden');
        renderTable(tableSearch?.value || '');
        if (window.Toast) window.Toast.show(`Chemical line added to ${rec.poNo}`, 'success');
      }
    });

    // Excel Export
    btnExportExcel?.addEventListener('click', () => {
      const headers = ["S.NO", "Supplier Name", "PoNo", "PO Date", "Chemicals", "Port Name", "Mode of Import", "Quantity(Bags)", "Quantity(KGs)", "Total Amount", "ETD Date", "ETA Date", "Remarks"];
      const rows = this.chemicalPosList.map((r, i) => [
        i + 1,
        `"${r.supplierName || ''}"`,
        `"${r.poNo || ''}"`,
        `"${r.poDate || ''}"`,
        `"${r.chemicals || ''}"`,
        `"${r.portName || ''}"`,
        `"${r.modeOfImport || ''}"`,
        `"${r.qtyBags || ''}"`,
        `"${r.qtyKgs || ''}"`,
        `"${r.totalAmount || ''}"`,
        `"${r.etdDate || ''}"`,
        `"${r.etaDate || ''}"`,
        `"${(r.remarks || '').replace(/"/g, '""')}"`
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `chemical_pos_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('Chemical POs report exported to CSV', 'success');
    });
  },

  renderReceivedChemicals(container) {
    if (!this.receivedChemicalsList || this.receivedChemicalsList.length === 0 || !this.receivedChemicalsList.some(x => x.poNo === 'DFL/CFB/2627/003')) {
      this.receivedChemicalsList = [
        { id: "RC-01", sNo: 1, poNo: "DFL/CFB/2627/003", chemical: "CARNAL 659 S ADVANCED (STPP)", blNo: "", containerNo: "", receivedBags: 800, receivedQty: 20000, boeNo: "", boeDate: "04-09-2026", clearedDate: "04-09-2026", balanceBags: 4000, balanceQty: 100000, status: "PENDING", plant: "VSP-DFL UNIT-1 (VSP)", year: "2026-27" },
        { id: "RC-02", sNo: 2, poNo: "DFL/CFB/2627/002", chemical: "CARNAL 659 S ADVANCED (STPP)", blNo: "", containerNo: "", receivedBags: 800, receivedQty: 20000, boeNo: "", boeDate: "23-08-2026", clearedDate: "23-08-2026", balanceBags: 1600, balanceQty: 40000, status: "PENDING", plant: "VSP-DFL UNIT-1 (VSP)", year: "2026-27" },
        { id: "RC-03", sNo: 3, poNo: "DFL/KPL/2627/004", chemical: "ALTESA NEO S100 (NP)", blNo: "BL-2026-991", containerNo: "TGCU8812301", receivedBags: 320, receivedQty: 8000, boeNo: "BOE-84721", boeDate: "06-10-2026", clearedDate: "08-10-2026", balanceBags: 0, balanceQty: 0, status: "CLEARED", plant: "KKD-DFL UNIT-2 (KKD)", year: "2026-27" }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">RECEIVED CHEMICALS</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Chemical Screens &bull; Inward Orders & Dock Clearance</span>
        </div>

        <!-- Upper Card: Filters Card (Matching Screenshot 1) -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="rc-filter-form" class="space-y-4">
            <!-- Row 1: 3 Dropdowns -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PLANT</label>
                <select id="rc-filter-plant" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="" selected>Select</option>
                  <option value="VSP-DFL UNIT-1 (VSP)">VSP-DFL UNIT-1 (VSP)</option>
                  <option value="KKD-DFL UNIT-2 (KKD)">KKD-DFL UNIT-2 (KKD)</option>
                  <option value="PSP-DFL UNIT-3 (PSP)">PSP-DFL UNIT-3 (PSP)</option>
                  <option value="JPT-DFL UNIT-5 (JPT)">JPT-DFL UNIT-5 (JPT)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">STATUS</label>
                <select id="rc-filter-status" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="PENDING" selected>Pending</option>
                  <option value="CLEARED">Cleared</option>
                  <option value="ALL">All</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">YEAR</label>
                <select id="rc-filter-year" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="2026-27" selected>2026-27</option>
                  <option value="2025-26">2025-26</option>
                  <option value="2024-25">2024-25</option>
                </select>
              </div>
            </div>

            <!-- Centered Action Buttons (Matching Screenshot 1) -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="button" id="rc-btn-search" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer">
                <span>Search</span>
                <span>&rarr;</span>
              </button>
              <button type="button" id="rc-btn-add-order" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                <span>+ Add Order</span>
              </button>
            </div>
          </form>
        </div>

        <!-- Create/Edit Form Card: GS CHEM ORDERS CREATE (Matching Screenshot 2) -->
        <div id="rc-create-card" class="hidden bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all animate-fade-in">
          <div class="flex items-center justify-between pb-3 mb-3 border-b border-[#E2E8F0]">
            <h3 id="rc-create-title" class="text-xs md:text-sm font-bold text-[#1E293B] uppercase tracking-wide">GS CHEM ORDERS CREATE</h3>
            <button type="button" id="rc-card-close-x" class="text-[#64748B] hover:text-[#1E293B] text-lg font-bold cursor-pointer transition-colors">&times;</button>
          </div>
          <form id="rc-create-form" class="space-y-4">
            <input type="hidden" id="rc-edit-id" value="">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PROCESSING PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="rc-create-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All">All</option>
                  <option value="VSP-DFL UNIT-1 (VSP)" selected>VSP-DFL UNIT-1 (VSP)</option>
                  <option value="KKD-DFL UNIT-2 (KKD)">KKD-DFL UNIT-2 (KKD)</option>
                  <option value="PSP-DFL UNIT-3 (PSP)">PSP-DFL UNIT-3 (PSP)</option>
                  <option value="JPT-DFL UNIT-5 (JPT)">JPT-DFL UNIT-5 (JPT)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PONO <span class="text-red-500 font-bold">*</span></label>
                <select id="rc-create-pono" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="All">All</option>
                  <option value="DFL/CFB/2627/003" selected>DFL/CFB/2627/003</option>
                  <option value="DFL/CFB/2627/002">DFL/CFB/2627/002</option>
                  <option value="DFL/KPL/2627/004">DFL/KPL/2627/004</option>
                  <option value="DFL/2627/003">DFL/2627/003</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">CHEMICAL <span class="text-red-500 font-bold">*</span></label>
                <select id="rc-create-chem" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="CARNAL 659 S ADVANCED (STPP)" selected>CARNAL 659 S ADVANCED (STPP)</option>
                  <option value="ALTESA NEO S100 (NP)">ALTESA NEO S100 (NP)</option>
                  <option value="CARFOSEL B 940 (STPP)">CARFOSEL B 940 (STPP)</option>
                  <option value="BEKAPLUS FS (BLEND)">BEKAPLUS FS (BLEND)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">BL NO</label>
                <input type="text" id="rc-create-blno" placeholder="Enter BL No" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 2: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">CONTAINER NO</label>
                <input type="text" id="rc-create-containerno" placeholder="Enter Container No" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">RECEIVED BAGS <span class="text-red-500 font-bold">*</span></label>
                <input type="number" id="rc-create-bags" placeholder="Enter Received Bags" required value="800" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">RECEIVED QTY IN KGS <span class="text-red-500 font-bold">*</span></label>
                <input type="number" id="rc-create-qty" placeholder="Enter Quantity Received" required value="20000" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">BILL OF ENTRY NO</label>
                <input type="text" id="rc-create-boeno" placeholder="Enter Bill of Entry No" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 3: 4 Columns (First 2 occupied) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">BILL OF ENTRY DATE</label>
                <input type="date" id="rc-create-boedate" value="2026-09-04" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">CLEARED DATE</label>
                <input type="date" id="rc-create-cleardate" value="2026-09-04" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Centered Buttons: Close & Save (Matching Screenshot 2) -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="button" id="rc-btn-close-form" class="px-6 py-2 bg-[#F43F5E] hover:bg-[#E11D48] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Close
              </button>
              <button type="submit" id="rc-btn-save-form" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table with Toolbar (Matching Screenshot 1) -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="flex items-center flex-wrap gap-2.5 w-full sm:w-auto">
              <!-- Search Input with Magnifier -->
              <div class="relative w-full sm:w-64">
                <input type="text" id="rc-table-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
              </div>
              <!-- More Search Button -->
              <button type="button" id="rc-btn-more-search" class="px-3 py-1.5 bg-white border border-[#10B981] text-[#10B981] hover:bg-[#F0FDF4] text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-all cursor-pointer">
                <svg class="w-3.5 h-3.5 text-[#10B981]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <span>More Search</span>
              </button>
              <!-- Load All Button -->
              <button type="button" id="rc-btn-load-all" class="px-3 py-1.5 bg-white border border-[#0284C7] text-[#0284C7] hover:bg-[#F0F9FF] text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-all cursor-pointer">
                <svg class="w-3.5 h-3.5 text-[#0284C7]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                <span>Load All</span>
              </button>
            </div>
            <!-- Download Excel Button -->
            <button type="button" id="rc-btn-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.NO &uarr;&darr;</th>
                  <th class="py-2.5 px-3">PoNo &uarr;&darr;</th>
                  <th class="py-2.5 px-3">Chemical &uarr;&darr;</th>
                  <th class="py-2.5 px-3">BL No &uarr;&darr;</th>
                  <th class="py-2.5 px-3">Container No &uarr;&darr;</th>
                  <th class="py-2.5 px-3 text-right">Received Bags &uarr;&darr;</th>
                  <th class="py-2.5 px-3 text-right">Received Quantity &uarr;&darr;</th>
                  <th class="py-2.5 px-3">Bill of Entry No &uarr;&darr;</th>
                  <th class="py-2.5 px-3">Bill of Entry Date &uarr;&darr;</th>
                  <th class="py-2.5 px-3">Cleared Date &uarr;&darr;</th>
                  <th class="py-2.5 px-3 text-right">Balance Bags &uarr;&darr;</th>
                  <th class="py-2.5 px-3 text-right">Balance Quantity &uarr;&darr;</th>
                  <th class="py-2.5 px-3 text-center">Status &uarr;&darr;</th>
                  <th class="py-2.5 px-3 text-center">Actions &uarr;&darr;</th>
                </tr>
              </thead>
              <tbody id="rc-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>

          <!-- Table Footer: Entries count & Pagination (Matching Screenshot 1) -->
          <div class="flex items-center justify-between pt-4 text-xs text-[#64748B]">
            <div id="rc-pagination-info">Showing 1 to 2 out of 2 entries</div>
            <div class="flex items-center gap-1">
              <span class="w-6 h-6 flex items-center justify-center rounded-full bg-[#3B82F6] text-white text-xs font-bold shadow-xs">1</span>
            </div>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('rc-table-body');
    const tableSearch = document.getElementById('rc-table-search');
    const createCard = document.getElementById('rc-create-card');
    const createForm = document.getElementById('rc-create-form');
    const createTitle = document.getElementById('rc-create-title');
    const editIdInput = document.getElementById('rc-edit-id');
    const btnAddOrder = document.getElementById('rc-btn-add-order');
    const btnCloseForm = document.getElementById('rc-btn-close-form');
    const btnCloseX = document.getElementById('rc-card-close-x');
    const btnSearch = document.getElementById('rc-btn-search');
    const btnLoadAll = document.getElementById('rc-btn-load-all');
    const btnMoreSearch = document.getElementById('rc-btn-more-search');
    const btnExportExcel = document.getElementById('rc-btn-export-excel');
    const paginationInfo = document.getElementById('rc-pagination-info');

    const filterPlant = document.getElementById('rc-filter-plant');
    const filterStatus = document.getElementById('rc-filter-status');
    const filterYear = document.getElementById('rc-filter-year');

    // Auto-calculate Received Qty in KGs when Received Bags changes (default 25 kg/bag)
    const bagsInput = document.getElementById('rc-create-bags');
    const qtyInput = document.getElementById('rc-create-qty');
    bagsInput?.addEventListener('input', () => {
      const b = parseInt(bagsInput.value) || 0;
      qtyInput.value = b * 25;
    });

    const renderTable = (query = '', overrideFilter = null) => {
      const q = (query || '').toLowerCase().trim();
      const plantVal = overrideFilter ? '' : (filterPlant?.value || '');
      const statusVal = overrideFilter ? 'ALL' : (filterStatus?.value || 'PENDING');
      const yearVal = overrideFilter ? '' : (filterYear?.value || '2026-27');

      const filtered = this.receivedChemicalsList.filter(r => {
        if (plantVal && r.plant && !r.plant.includes(plantVal)) return false;
        if (statusVal !== 'ALL' && (r.status || '').toUpperCase() !== statusVal.toUpperCase()) return false;
        if (yearVal && r.year && r.year !== yearVal) return false;

        if (!q) return true;
        const text = `${r.poNo || ''} ${r.chemical || ''} ${r.blNo || ''} ${r.containerNo || ''} ${r.boeNo || ''} ${r.status || ''}`.toLowerCase();
        return text.includes(q);
      });

      if (paginationInfo) {
        paginationInfo.textContent = `Showing 1 to ${filtered.length} out of ${filtered.length} entries`;
      }

      if (filtered.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="14" class="py-8 text-center text-xs text-[#64748B]">
              No inward chemical orders match the selected criteria.
            </td>
          </tr>
        `;
        return;
      }

      tbody.innerHTML = filtered.map((r, i) => `
        <tr class="hover:bg-[#F8FAFC] transition-colors border-b border-[#E2E8F0]">
          <td class="py-2.5 px-3 font-semibold text-[#64748B]">${i + 1}</td>
          <td class="py-2.5 px-3 font-mono font-medium text-[#1E293B]">${r.poNo || ''}</td>
          <td class="py-2.5 px-3 text-[#1E293B] font-medium">${r.chemical || ''}</td>
          <td class="py-2.5 px-3 text-[#64748B]">${r.blNo || ''}</td>
          <td class="py-2.5 px-3 text-[#64748B]">${r.containerNo || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.receivedBags || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.receivedQty || ''}</td>
          <td class="py-2.5 px-3 text-[#64748B]">${r.boeNo || ''}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.boeDate || ''}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.clearedDate || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.balanceBags || ''}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#1E293B]">${r.balanceQuantity || r.balanceQty || ''}</td>
          <td class="py-2.5 px-3 text-center">
            ${(r.status || '').toUpperCase() === 'PENDING'
              ? '<span class="px-3 py-0.5 bg-[#EF4444] text-white rounded-full text-[10px] font-bold tracking-wider uppercase inline-block">PENDING</span>'
              : '<span class="px-3 py-0.5 bg-[#10B981] text-white rounded-full text-[10px] font-bold tracking-wider uppercase inline-block">CLEARED</span>'}
          </td>
          <td class="py-2.5 px-3 text-center">
            <button type="button" title="Edit Order" class="rc-action-edit p-1 text-[#0284C7] hover:text-[#02a8b5] hover:bg-[#F0F9FF] rounded transition-colors cursor-pointer" data-id="${r.id}">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
            </button>
          </td>
        </tr>
      `).join('');

      // Attach row action handlers
      tbody.querySelectorAll('.rc-action-edit').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const rec = this.receivedChemicalsList.find(x => x.id === id);
          if (!rec) return;
          createTitle.textContent = `GS CHEM ORDERS EDIT - ${rec.poNo}`;
          editIdInput.value = rec.id;
          document.getElementById('rc-create-plant').value = rec.plant || 'VSP-DFL UNIT-1 (VSP)';
          document.getElementById('rc-create-pono').value = rec.poNo || 'All';
          document.getElementById('rc-create-chem').value = rec.chemical || '';
          document.getElementById('rc-create-blno').value = rec.blNo || '';
          document.getElementById('rc-create-containerno').value = rec.containerNo || '';
          document.getElementById('rc-create-bags').value = rec.receivedBags || '';
          document.getElementById('rc-create-qty').value = rec.receivedQty || '';
          document.getElementById('rc-create-boeno').value = rec.boeNo || '';

          // Format date to yyyy-mm-dd for input[type=date]
          if (rec.boeDate && rec.boeDate.includes('-')) {
            const parts = rec.boeDate.split('-');
            if (parts[0].length === 2) {
              document.getElementById('rc-create-boedate').value = `${parts[2]}-${parts[1]}-${parts[0]}`;
            } else {
              document.getElementById('rc-create-boedate').value = rec.boeDate;
            }
          }
          if (rec.clearedDate && rec.clearedDate.includes('-')) {
            const parts = rec.clearedDate.split('-');
            if (parts[0].length === 2) {
              document.getElementById('rc-create-cleardate').value = `${parts[2]}-${parts[1]}-${parts[0]}`;
            } else {
              document.getElementById('rc-create-cleardate').value = rec.clearedDate;
            }
          }

          createCard.classList.remove('hidden');
          createCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
      });
    };

    // Initial render
    renderTable();

    // Table live search
    tableSearch?.addEventListener('input', (e) => renderTable(e.target.value));

    // Top Filter Search button
    btnSearch?.addEventListener('click', () => {
      renderTable(tableSearch?.value || '');
      if (window.Toast) window.Toast.show('Applied inward chemical filters', 'info');
    });

    // Load All button
    btnLoadAll?.addEventListener('click', () => {
      if (filterPlant) filterPlant.value = '';
      if (filterStatus) filterStatus.value = 'ALL';
      if (tableSearch) tableSearch.value = '';
      renderTable('', true);
      if (window.Toast) window.Toast.show('Loaded all received chemical records', 'info');
    });

    // More Search toggle
    btnMoreSearch?.addEventListener('click', () => {
      if (window.Toast) window.Toast.show('Additional search parameters active', 'info');
    });

    // Toggle GS CHEM ORDERS CREATE card
    btnAddOrder?.addEventListener('click', () => {
      createTitle.textContent = 'GS CHEM ORDERS CREATE';
      editIdInput.value = '';
      createForm.reset();
      document.getElementById('rc-create-boedate').value = '2026-09-04';
      document.getElementById('rc-create-cleardate').value = '2026-09-04';
      createCard.classList.remove('hidden');
      createCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });

    const hideCreateCard = () => {
      createCard.classList.add('hidden');
      createForm.reset();
      editIdInput.value = '';
    };

    btnCloseForm?.addEventListener('click', hideCreateCard);
    btnCloseX?.addEventListener('click', hideCreateCard);

    // Save GS CHEM ORDERS CREATE form
    createForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      const editId = editIdInput.value;
      const plant = document.getElementById('rc-create-plant').value;
      const pono = document.getElementById('rc-create-pono').value;
      const chem = document.getElementById('rc-create-chem').value;
      const blno = document.getElementById('rc-create-blno').value;
      const containerno = document.getElementById('rc-create-containerno').value;
      const bags = parseInt(document.getElementById('rc-create-bags').value) || 0;
      const qty = parseInt(document.getElementById('rc-create-qty').value) || (bags * 25);
      const boeno = document.getElementById('rc-create-boeno').value;
      const boedateRaw = document.getElementById('rc-create-boedate').value;
      const cleardateRaw = document.getElementById('rc-create-cleardate').value;

      const fmtDate = (d) => {
        if (!d) return '';
        const parts = d.split('-');
        if (parts.length === 3) return `${parts[2]}-${parts[1]}-${parts[0]}`;
        return d;
      };

      if (editId) {
        const idx = this.receivedChemicalsList.findIndex(x => x.id === editId);
        if (idx !== -1) {
          this.receivedChemicalsList[idx] = {
            ...this.receivedChemicalsList[idx],
            plant: plant,
            poNo: pono,
            chemical: chem,
            blNo: blno,
            containerNo: containerno,
            receivedBags: bags,
            receivedQty: qty,
            boeNo: boeno,
            boeDate: fmtDate(boedateRaw),
            clearedDate: fmtDate(cleardateRaw)
          };
          if (window.Toast) window.Toast.show(`Inward order ${pono} updated successfully`, 'success');
        }
      } else {
        const newRecord = {
          id: 'RC-' + String(Date.now()).slice(-6),
          sNo: this.receivedChemicalsList.length + 1,
          plant: plant,
          poNo: pono,
          chemical: chem,
          blNo: blno,
          containerNo: containerno,
          receivedBags: bags,
          receivedQty: qty,
          boeNo: boeno,
          boeDate: fmtDate(boedateRaw),
          clearedDate: fmtDate(cleardateRaw),
          balanceBags: bags,
          balanceQuantity: qty,
          status: 'PENDING',
          year: '2026-27'
        };
        this.receivedChemicalsList.unshift(newRecord);
        if (window.Toast) window.Toast.show(`New chemical inward order ${pono} recorded`, 'success');
      }

      hideCreateCard();
      renderTable(tableSearch?.value || '');
    });

    // Excel Export
    btnExportExcel?.addEventListener('click', () => {
      const headers = ["S.NO", "PoNo", "Chemical", "BL No", "Container No", "Received Bags", "Received Quantity", "Bill of Entry No", "Bill of Entry Date", "Cleared Date", "Balance Bags", "Balance Quantity", "Status"];
      const rows = this.receivedChemicalsList.map((r, i) => [
        i + 1,
        `"${r.poNo || ''}"`,
        `"${r.chemical || ''}"`,
        `"${r.blNo || ''}"`,
        `"${r.containerNo || ''}"`,
        `"${r.receivedBags || ''}"`,
        `"${r.receivedQty || ''}"`,
        `"${r.boeNo || ''}"`,
        `"${r.boeDate || ''}"`,
        `"${r.clearedDate || ''}"`,
        `"${r.balanceBags || ''}"`,
        `"${r.balanceQuantity || r.balanceQty || ''}"`,
        `"${r.status || ''}"`
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `received_chemicals_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('Received chemicals report exported to CSV', 'success');
    });
  },

  renderChemicalsConsumption(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader(
          'Chemicals Daily Floor Consumption',
          `<button class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs hover:shadow cursor-pointer transition-all" onclick="window.PreprocessingView.openChemConsumptionModal()">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <span>Log Daily Consumption</span>
          </button>`
        )}

        ${UIBase.renderFilterCard({
          idPrefix: 'chem-cons-filter',
          title: 'Search & Filters',
          fields: [
            {
              label: 'PRODUCTION PLANT',
              html: `
                <select id="chem-cons-plant-select" class="w-full text-xs px-2.5 py-1.5 bg-white border border-[#DFE1E6] rounded focus:outline-none focus:border-[#0284C7]">
                  <option value="ALL">All Plants (Select)</option>
                  <option value="DFL UNIT-1 (VSP)">DFL UNIT-1 (VSP)</option>
                  <option value="DFL UNIT-2 (KKD)">DFL UNIT-2 (KKD)</option>
                  <option value="DFL UNIT-5 (JPT)">DFL UNIT-5 (JPT)</option>
                </select>
              `
            },
            {
              label: 'CHEMICAL NAME',
              html: `
                <select id="chem-cons-chem-select" class="w-full text-xs px-2.5 py-1.5 bg-white border border-[#DFE1E6] rounded focus:outline-none focus:border-[#0284C7]">
                  <option value="ALL">All Chemicals (Select)</option>
                  <option value="CARNAL 659 S ADVANCED (STPP)">CARNAL 659 S ADVANCED (STPP)</option>
                  <option value="ALTESA NEO S100 (NP)">ALTESA NEO S100 (NP)</option>
                  <option value="CARFOSEL B 940 (STPP)">CARFOSEL B 940 (STPP)</option>
                </select>
              `
            }
          ]
        })}

        <div id="chem-cons-table-container"></div>
        <div id="chem-cons-totals-container" class="mt-4"></div>
      </div>
    `;

    const renderTotals = (list) => {
      const count = list.length;
      const consumedBags = list.reduce((s, x) => s + (parseInt(x.consumedBags) || 0), 0);
      const consumedKgs = list.reduce((s, x) => s + (parseFloat(x.consumedKgs) || 0), 0);
      const closingKgs = list.reduce((s, x) => s + (parseFloat(x.closingKgs) || 0), 0);

      const el = document.getElementById('chem-cons-totals-container');
      if (el) {
        el.innerHTML = UIBase.renderTotals(
          'Daily Floor Chemical Usage Summary',
          count,
          count === 1 ? 'Batch Log' : 'Batch Logs',
          [
            { label: 'TOTAL CONSUMPTION', value: `${consumedKgs.toLocaleString()} KG`, badge: 'Floor Usage', badgeColor: 'text-[#006644] bg-[#E3FCEF]', color: 'text-[#006644]' },
            { label: 'CONSUMED BAGS', value: `${consumedBags.toLocaleString()} Bags`, badge: 'Units Used', badgeColor: 'text-[#0284C7] bg-[#F0F9FF]' },
            { label: 'CLOSING FLOOR STOCK', value: `${closingKgs.toLocaleString()} KG`, badge: 'Plant Safe Level', badgeColor: 'text-[#0284C7] bg-[#F0F9FF]' },
            { label: 'LOGGED ENTRIES', value: `${count} Batches`, badge: 'Shift Audited', badgeColor: 'text-[#006644] bg-[#E3FCEF]' }
          ]
        );
      }
    };

    const table = new DataTable({
      containerId: 'chem-cons-table-container',
      data: this.chemicalsConsumptionList,
      keyField: 'id',
      tableTitle: 'Floor Chemical Consumption Ledger',
      searchable: false,
      hideTopFilterBar: true,
      showCopy: false,
      onDataChange: (d) => renderTotals(d),
      columns: [
        { field: 'sNo', header: 'S.No', render: (v, r, idx) => `<span class="font-bold text-[#5E6C84]">${idx !== undefined ? idx + 1 : 1}</span>` },
        { field: 'date', header: 'Date', render: (v) => `<span class="text-[#172B4D] font-medium">${v}</span>` },
        { field: 'plant', header: 'Plant', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'chemical', header: 'Chemical', render: (v) => `<span class="font-semibold text-[#172B4D]">${v}</span>` },
        { field: 'openingKgs', header: 'Opening (KG)', render: (v) => `<span class="text-[#5E6C84]">${v.toLocaleString()}</span>` },
        { field: 'consumedBags', header: 'Used (Bags)', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'consumedKgs', header: 'Consumed (KG)', render: (v) => `<span class="font-extrabold text-[#006644]">${v.toLocaleString()} KG</span>` },
        { field: 'closingKgs', header: 'Closing (KG)', render: (v) => `<span class="font-bold text-[#172B4D]">${v.toLocaleString()} KG</span>` },
        { field: 'batchCode', header: 'Batch Code', render: (v) => `<span class="font-mono text-[#006C7A] bg-[#E6FCFF] px-2 py-0.5 rounded text-[11px]">${v}</span>` },
        { field: 'supervisor', header: 'Supervisor', render: (v) => `<span class="text-[#5E6C84]">${v}</span>` },
        { field: 'status', header: 'Status', render: (v) => UIBase.renderBadge(v, 'success') },
        {
          field: 'actions',
          header: 'Actions',
          render: (v, r) => UIBase.renderActionButtons({
            onView: `window.PreprocessingView.toastInfo('Viewing consumption for ${r.batchCode}')`,
            onDownload: `window.PreprocessingView.toastInfo('Downloading sheet')`,
            onDelete: `if(confirm('Delete consumption record?')) { window.PreprocessingView.chemicalsConsumptionList = window.PreprocessingView.chemicalsConsumptionList.filter(x => x.id !== '${r.id}'); window.PreprocessingView.renderChemicalsConsumption(document.getElementById('preproc-subpage-content')); Toast.show('Record deleted', 'error'); }`
          })
        }
      ]
    });

    renderTotals(this.chemicalsConsumptionList);

    UIBase.bindFilter('chem-cons-filter', () => {
      const pVal = document.getElementById('chem-cons-plant-select')?.value || 'ALL';
      const cVal = document.getElementById('chem-cons-chem-select')?.value || 'ALL';
      let filtered = this.chemicalsConsumptionList;
      if (pVal !== 'ALL') filtered = filtered.filter(x => x.plant === pVal);
      if (cVal !== 'ALL') filtered = filtered.filter(x => x.chemical === cVal);
      table.setData(filtered);
      renderTotals(filtered);
    }, () => {
      if (document.getElementById('chem-cons-plant-select')) document.getElementById('chem-cons-plant-select').value = 'ALL';
      if (document.getElementById('chem-cons-chem-select')) document.getElementById('chem-cons-chem-select').value = 'ALL';
      table.setData(this.chemicalsConsumptionList);
      renderTotals(this.chemicalsConsumptionList);
    });
  },

  renderChemicalReceivedReport(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader('Chemicals Received Periodic Summary')}
        <div id="chem-rec-rpt-table-container"></div>
        <div id="chem-rec-rpt-totals-container" class="mt-4"></div>
      </div>
    `;
    const renderTotals = (list) => {
      const count = list.length;
      const totalKgs = list.reduce((s, x) => s + (parseFloat(x.totalKgs) || 0), 0);
      const totalSpend = list.reduce((s, x) => s + (parseFloat(x.totalCostInr) || 0), 0);
      const el = document.getElementById('chem-rec-rpt-totals-container');
      if (el) {
        el.innerHTML = UIBase.renderTotals(
          'Chemicals Intake Summary Statistics',
          count, 'Entries',
          [
            { label: 'TOTAL INTAKE MASS', value: `${totalKgs.toLocaleString()} KG`, badge: 'Gross Weight', badgeColor: 'text-[#006644] bg-[#E3FCEF]', color: 'text-[#006644]' },
            { label: 'TOTAL EXPENDITURE', value: `₹ ${Math.round(totalSpend).toLocaleString()}`, badge: 'Procurement Cost', badgeColor: 'text-[#0284C7] bg-[#F0F9FF]' },
            { label: 'AVERAGE RATE', value: `₹ ${(totalKgs > 0 ? totalSpend / totalKgs : 0).toFixed(2)} / KG`, badge: 'Weighted Rate', badgeColor: 'text-[#006644] bg-[#E3FCEF]' },
            { label: 'REPORT LINES', value: `${count} Lines`, badge: 'Summary', badgeColor: 'text-[#5E6C84] bg-[#F4F5F7]' }
          ]
        );
      }
    };
    new DataTable({
      containerId: 'chem-rec-rpt-table-container',
      data: this.chemicalReceivedReportsList,
      keyField: 'id',
      tableTitle: 'Monthly Chemical Intake Ledger',
      searchable: false,
      hideTopFilterBar: true,
      columns: [
        { field: 'sNo', header: 'S.No', render: (v, r, idx) => `<span class="font-bold text-[#5E6C84]">${idx + 1}</span>` },
        { field: 'month', header: 'Month', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'plant', header: 'Plant', render: (v) => `<span class="text-[#172B4D]">${v}</span>` },
        { field: 'chemical', header: 'Chemical', render: (v) => `<span class="font-semibold text-[#172B4D]">${v}</span>` },
        { field: 'totalBags', header: 'Total Bags', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'totalKgs', header: 'Total (KG)', render: (v) => `<span class="font-extrabold text-[#006644]">${v.toLocaleString()} KG</span>` },
        { field: 'avgRatePerKg', header: 'Rate/KG', render: (v) => `<span class="text-[#172B4D]">₹ ${v}</span>` },
        { field: 'totalCostInr', header: 'Total (INR)', render: (v) => `<span class="font-extrabold text-[#172B4D]">₹ ${v.toLocaleString()}</span>` },
        { field: 'supplier', header: 'Supplier', render: (v) => `<span class="text-[#5E6C84]">${v}</span>` }
      ]
    });
    renderTotals(this.chemicalReceivedReportsList);
  },

  renderChemicalOpeningBalance(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader('Chemical Inventory Opening Balance')}
        <div id="chem-op-bal-table-container"></div>
        <div id="chem-op-bal-totals-container" class="mt-4"></div>
      </div>
    `;
    const renderTotals = (list) => {
      const count = list.length;
      const totalKgs = list.reduce((s, x) => s + (parseFloat(x.openingKgs) || 0), 0);
      const totalVal = list.reduce((s, x) => s + (parseFloat(x.totalValuation) || 0), 0);
      const el = document.getElementById('chem-op-bal-totals-container');
      if (el) {
        el.innerHTML = UIBase.renderTotals(
          'Opening Balance Valuation Summary',
          count, 'Lines',
          [
            { label: 'OPENING STOCK', value: `${totalKgs.toLocaleString()} KG`, badge: 'Baseline Volume', badgeColor: 'text-[#0284C7] bg-[#F0F9FF]' },
            { label: 'INVENTORY VALUATION', value: `₹ ${Math.round(totalVal).toLocaleString()}`, badge: 'Book Value', badgeColor: 'text-[#006644] bg-[#E3FCEF]', color: 'text-[#006644]' },
            { label: 'AUDITED PLANTS', value: '3 Plants', badge: 'Certified', badgeColor: 'text-[#006644] bg-[#E3FCEF]' },
            { label: 'ACTIVE RECORDS', value: `${count} Items`, badge: 'Verified', badgeColor: 'text-[#5E6C84] bg-[#F4F5F7]' }
          ]
        );
      }
    };
    new DataTable({
      containerId: 'chem-op-bal-table-container',
      data: this.chemicalOpeningBalancesList,
      keyField: 'id',
      tableTitle: 'Audited Opening Stock Register',
      searchable: false,
      hideTopFilterBar: true,
      columns: [
        { field: 'sNo', header: 'S.No', render: (v, r, idx) => `<span class="font-bold text-[#5E6C84]">${idx + 1}</span>` },
        { field: 'plant', header: 'Plant', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'chemical', header: 'Chemical', render: (v) => `<span class="font-semibold text-[#172B4D]">${v}</span>` },
        { field: 'openingBags', header: 'Opening Bags', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'openingKgs', header: 'Opening KGs', render: (v) => `<span class="font-extrabold text-[#006644]">${v.toLocaleString()} KG</span>` },
        { field: 'valuationRate', header: 'Rate (INR)', render: (v) => `<span class="text-[#172B4D]">₹ ${v}</span>` },
        { field: 'totalValuation', header: 'Total Valuation', render: (v) => `<span class="font-extrabold text-[#172B4D]">₹ ${v.toLocaleString()}</span>` },
        { field: 'auditDate', header: 'Audit Date', render: (v) => `<span class="text-[#5E6C84]">${v}</span>` }
      ]
    });
    renderTotals(this.chemicalOpeningBalancesList);
  },

  renderChemicalBalanceReport(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader('Chemical Floor & Warehouse Reconciliation Ledger')}
        <div id="chem-bal-rpt-table-container"></div>
      </div>
    `;
    new DataTable({
      containerId: 'chem-bal-rpt-table-container',
      data: this.chemicalBalanceReportsList,
      keyField: 'id',
      tableTitle: 'Monthly Material Balance (Opening + Intake − Usage = Closing)',
      searchable: false,
      hideTopFilterBar: true,
      columns: [
        { field: 'sNo', header: 'S.No', render: (v, r, idx) => `<span class="font-bold text-[#5E6C84]">${idx + 1}</span>` },
        { field: 'plant', header: 'Plant', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'chemical', header: 'Chemical', render: (v) => `<span class="font-semibold text-[#172B4D]">${v}</span>` },
        { field: 'openingStock', header: 'Opening (KG)', render: (v) => `<span class="text-[#5E6C84]">${v.toLocaleString()}</span>` },
        { field: 'receipts', header: 'Intake (KG)', render: (v) => `<span class="font-bold text-[#006644]">+${v.toLocaleString()}</span>` },
        { field: 'consumption', header: 'Consumption', render: (v) => `<span class="font-bold text-[#BF2600]">-${v.toLocaleString()}</span>` },
        { field: 'closingStock', header: 'Closing (KG)', render: (v) => `<span class="font-extrabold text-[#172B4D]">${v.toLocaleString()} KG</span>` },
        { field: 'stockStatus', header: 'Status', render: (v) => UIBase.renderBadge(v, 'success') }
      ]
    });
  },

  renderChemicalPaymentsList(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader(
          'Chemical Vendor Payments Ledger',
          `<button class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs hover:shadow cursor-pointer transition-all" onclick="window.PreprocessingView.openChemPaymentModal()">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            <span>Record Vendor Payment</span>
          </button>`
        )}
        <div id="chem-pay-table-container"></div>
        <div id="chem-pay-totals-container" class="mt-4"></div>
      </div>
    `;
    const renderTotals = (list) => {
      const count = list.length;
      const totalPaid = list.reduce((s, x) => s + (parseFloat(x.netPaid) || 0), 0);
      const totalTds = list.reduce((s, x) => s + (parseFloat(x.tdsAmount) || 0), 0);
      const el = document.getElementById('chem-pay-totals-container');
      if (el) {
        el.innerHTML = UIBase.renderTotals(
          'Vendor Disbursals & Compliance Abstract',
          count, 'Vouchers',
          [
            { label: 'TOTAL DISBURSED', value: `₹ ${Math.round(totalPaid).toLocaleString()}`, badge: 'Bank Settled', badgeColor: 'text-[#006644] bg-[#E3FCEF]', color: 'text-[#006644]' },
            { label: 'TDS DEDUCTED', value: `₹ ${Math.round(totalTds).toLocaleString()}`, badge: '1% IT Act', badgeColor: 'text-[#0284C7] bg-[#F0F9FF]' },
            { label: 'SETTLED VOUCHERS', value: `${count} Payments`, badge: 'RTGS / NEFT', badgeColor: 'text-[#006644] bg-[#E3FCEF]' },
            { label: 'PENDING LIABILITIES', value: '₹ 0.00', badge: 'All Cleared', badgeColor: 'text-[#5E6C84] bg-[#F4F5F7]' }
          ]
        );
      }
    };
    new DataTable({
      containerId: 'chem-pay-table-container',
      data: this.chemicalPaymentsList,
      keyField: 'id',
      tableTitle: 'Vendor Chemical Disbursals Register',
      searchable: false,
      hideTopFilterBar: true,
      columns: [
        { field: 'sNo', header: 'S.No', render: (v, r, idx) => `<span class="font-bold text-[#5E6C84]">${idx + 1}</span>` },
        { field: 'voucherNo', header: 'Voucher No', render: (v) => `<span class="font-mono font-bold text-[#006C7A]">${v}</span>` },
        { field: 'supplierName', header: 'Supplier Name', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'invoiceNo', header: 'Invoice No', render: (v) => `<span class="text-[#5E6C84]">${v}</span>` },
        { field: 'invoiceAmount', header: 'Invoice Amt', render: (v) => `<span class="font-bold text-[#172B4D]">₹ ${v.toLocaleString()}</span>` },
        { field: 'tdsAmount', header: 'TDS (1%)', render: (v) => `<span class="text-[#5E6C84]">₹ ${v.toLocaleString()}</span>` },
        { field: 'netPaid', header: 'Net Paid', render: (v) => `<span class="font-extrabold text-[#006644]">₹ ${v.toLocaleString()}</span>` },
        { field: 'paymentDate', header: 'Payment Date', render: (v) => `<span class="text-[#172B4D]">${v}</span>` },
        { field: 'paymentMode', header: 'Mode', render: (v) => `<span class="px-2 py-0.5 rounded text-[10.5px] font-bold bg-[#F4F5F7] border border-[#DFE1E6]">${v}</span>` },
        { field: 'status', header: 'Status', render: (v) => UIBase.renderBadge(v, 'success') }
      ]
    });
    renderTotals(this.chemicalPaymentsList);
  },

  // ============================================
  // 3. FLOOR OPERATIONS & LOGS
  // ============================================
  renderRmReceived(container) {
    if (!this.rmReceivedList || this.rmReceivedList.length === 0) {
      this.rmReceivedList = [
        { id: "RMR-01", sNo: 1, billNo: "SKM/2425/1753", variety: "VM-HEAD ON", count: 88.0, headonWeight: 3373.0, recvCount: 85.0, recvWeight: 3373.0, sampleHoQty: 5.0, noOfPcs: 425, plant: "VSP - DFL UNIT-1 (VSP)", arrivalDate: "2025-03-23", vehicleNo: "AP39TH4246 - VM-VSP-SKM-056", trackCode: "VM-VSP-SKM-056", sealNo: "43475", supervisor: "T.VENKATESH", remarks: "" }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">RM RECEIVED TRACKID</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Raw Material Inward Verification</span>
        </div>

        <!-- Upper Card: Entry Form -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="rm-received-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="rm-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VSP - DFL UNIT-1 (VSP)" selected>VSP - DFL UNIT-1 (VSP)</option>
                  <option value="KKD - DFL UNIT-2 (KKD)">KKD - DFL UNIT-2 (KKD)</option>
                  <option value="PSP - DFL UNIT-3 (PSP)">PSP - DFL UNIT-3 (PSP)</option>
                  <option value="JPT - DFL UNIT-5 (JPT)">JPT - DFL UNIT-5 (JPT)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE</label>
                <input type="date" id="rm-arrival-date" value="2025-03-23" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">VEHICLE NUMBER <span class="text-red-500 font-bold">*</span></label>
                <select id="rm-vehicle" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="AP39TH4246 - VM-VSP-SKM-056" selected>AP39TH4246 - VM-VSP-SKM-056</option>
                  <option value="AP05X9921 - BT-KKD-MKP-043">AP05X9921 - BT-KKD-MKP-043</option>
                  <option value="AP31TT4177 - VM-PSP-BVR-078">AP31TT4177 - VM-PSP-BVR-078</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRACK CODE FORMAT <span class="text-red-500 font-bold">*</span></label>
                <input type="text" id="rm-track-code" value="VM-VSP-SKM-056" readonly class="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-lg text-xs text-[#475569] font-mono focus:outline-none">
              </div>
            </div>

            <!-- Row 2: 3 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SEAL NUMBER <span class="text-red-500 font-bold">*</span></label>
                <input type="text" id="rm-seal" value="43475" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPERVISOR <span class="text-red-500 font-bold">*</span></label>
                <select id="rm-supervisor" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="T.VENKATESH" selected>T.VENKATESH</option>
                  <option value="K VENKATA VINAY">K VENKATA VINAY</option>
                  <option value="S.BALA KRISHNA">S.BALA KRISHNA</option>
                  <option value="D.SURYA NARAYANA">D.SURYA NARAYANA</option>
                </select>
              </div>
              <div class="sm:col-span-2">
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">REMARKS</label>
                <input type="text" id="rm-remarks" placeholder="Enter Remarks" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Button -->
            <div class="flex items-center justify-center pt-2">
              <button type="submit" class="px-7 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table with In-Table Editable Inputs -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="rm-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="rm-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.No</th>
                  <th class="py-2.5 px-3">Bill No</th>
                  <th class="py-2.5 px-3">Variety</th>
                  <th class="py-2.5 px-3 text-right">Count</th>
                  <th class="py-2.5 px-3 text-right">Head on Weight</th>
                  <th class="py-2.5 px-3 text-right">Recv Count</th>
                  <th class="py-2.5 px-3 text-right">Recv Weight</th>
                  <th class="py-2.5 px-3 text-right">Sample HO Qty</th>
                  <th class="py-2.5 px-3 text-right">No Of Pcs</th>
                  <th class="py-2.5 px-3 text-right">Count Diff</th>
                  <th class="py-2.5 px-3 text-right">Qty Diff</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="rm-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('rm-table-body');
    const searchInput = document.getElementById('rm-search');
    const form = document.getElementById('rm-received-form');
    const exportBtn = document.getElementById('rm-export-excel');

    const renderRows = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.rmReceivedList.filter(r => {
        if (!q) return true;
        return `${r.billNo || ''} ${r.variety || ''} ${r.plant || ''} ${r.vehicleNo || ''}`.toLowerCase().includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="12" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map((r, idx) => {
        const countDiff = Number((r.recvCount || 0) - (r.count || 0)).toFixed(0);
        const qtyDiff = Number((r.recvWeight || 0) - (r.headonWeight || 0)).toFixed(0);

        return `
          <tr class="hover:bg-[#F8FAFC] transition-colors" data-id="${r.id}">
            <td class="py-2 px-3 font-bold text-[#64748B]">${idx + 1}</td>
            <td class="py-2 px-3 font-bold text-[#0F172A]">${r.billNo || '-'}</td>
            <td class="py-2 px-3 text-[#334155]">${r.variety || '-'}</td>
            <td class="py-2 px-3 text-right">
              <input type="number" step="0.001" value="${Number(r.count || 0).toFixed(3)}" readonly class="w-24 text-right px-2 py-1 bg-[#F1F5F9] border border-[#CBD5E1] rounded text-xs text-[#334155] focus:outline-none">
            </td>
            <td class="py-2 px-3 text-right">
              <input type="number" step="0.001" value="${Number(r.headonWeight || 0).toFixed(3)}" readonly class="w-28 text-right px-2 py-1 bg-[#F1F5F9] border border-[#CBD5E1] rounded text-xs text-[#334155] focus:outline-none">
            </td>
            <td class="py-2 px-3 text-right">
              <input type="number" step="0.001" value="${Number(r.recvCount || 0).toFixed(3)}" data-field="recvCount" data-id="${r.id}" class="rm-inline-input w-24 text-right px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] outline-none font-semibold">
            </td>
            <td class="py-2 px-3 text-right">
              <input type="number" step="0.001" value="${Number(r.recvWeight || 0).toFixed(0)}" data-field="recvWeight" data-id="${r.id}" class="rm-inline-input w-24 text-right px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] outline-none font-semibold">
            </td>
            <td class="py-2 px-3 text-right">
              <input type="number" step="0.001" value="${Number(r.sampleHoQty || 0).toFixed(3)}" data-field="sampleHoQty" data-id="${r.id}" class="rm-inline-input w-24 text-right px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] outline-none">
            </td>
            <td class="py-2 px-3 text-right">
              <input type="number" value="${Number(r.noOfPcs || 0)}" data-field="noOfPcs" data-id="${r.id}" class="rm-inline-input w-20 text-right px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] outline-none">
            </td>
            <td class="py-2 px-3 text-right font-mono font-bold ${Number(countDiff) < 0 ? 'text-red-500' : 'text-emerald-600'}">${countDiff}</td>
            <td class="py-2 px-3 text-right font-mono font-bold ${Number(qtyDiff) < 0 ? 'text-red-500' : 'text-emerald-600'}">${qtyDiff}</td>
            <td class="py-2 px-3 text-center">
              <button type="button" data-del-id="${r.id}" class="rm-row-del p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete Row">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
              </button>
            </td>
          </tr>
        `;
      }).join('');

      tbody.querySelectorAll('.rm-inline-input').forEach(inp => {
        inp.addEventListener('input', (e) => {
          const id = e.target.getAttribute('data-id');
          const field = e.target.getAttribute('data-field');
          const val = parseFloat(e.target.value) || 0;
          const rec = this.rmReceivedList.find(x => x.id === id);
          if (rec) {
            rec[field] = val;
            const tr = e.target.closest('tr');
            if (tr) {
              const cDiff = Number((rec.recvCount || 0) - (rec.count || 0)).toFixed(0);
              const qDiff = Number((rec.recvWeight || 0) - (rec.headonWeight || 0)).toFixed(0);
              const tds = tr.querySelectorAll('td');
              if (tds[9]) {
                tds[9].textContent = cDiff;
                tds[9].className = `py-2 px-3 text-right font-mono font-bold ${Number(cDiff) < 0 ? 'text-red-500' : 'text-emerald-600'}`;
              }
              if (tds[10]) {
                tds[10].textContent = qDiff;
                tds[10].className = `py-2 px-3 text-right font-mono font-bold ${Number(qDiff) < 0 ? 'text-red-500' : 'text-emerald-600'}`;
              }
            }
          }
        });
      });

      tbody.querySelectorAll('.rm-row-del').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = btn.getAttribute('data-del-id');
          if (confirm('Delete this RM Inward record?')) {
            this.rmReceivedList = this.rmReceivedList.filter(x => x.id !== id);
            renderRows(searchInput?.value || '');
            if (window.Toast) window.Toast.show('RM Inward line removed', 'info');
          }
        });
      });
    };

    renderRows();

    searchInput?.addEventListener('input', (e) => renderRows(e.target.value));

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      if (window.Toast) window.Toast.show('RM Received Track ID batch saved successfully!', 'success');
    });

    exportBtn?.addEventListener('click', () => {
      const headers = ["S.No", "Bill No", "Variety", "Billed Count", "Head on Weight", "Recv Count", "Recv Weight", "Sample HO Qty", "No Of Pcs", "Count Diff", "Qty Diff"];
      const rows = this.rmReceivedList.map((r, i) => [
        i + 1,
        `"${r.billNo || ''}"`,
        `"${r.variety || ''}"`,
        r.count || 0,
        r.headonWeight || 0,
        r.recvCount || 0,
        r.recvWeight || 0,
        r.sampleHoQty || 0,
        r.noOfPcs || 0,
        Number((r.recvCount || 0) - (r.count || 0)).toFixed(0),
        Number((r.recvWeight || 0) - (r.headonWeight || 0)).toFixed(0)
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `rm_received_trackid_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('RM Received report exported to CSV', 'success');
    });
  },

  initDeheadingStorage() {
    try {
      const stored = localStorage.getItem('dfl_deheading_logs');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.deheadingLogsList = parsed;
        }
      }
    } catch (e) {
      console.warn('Storage read error:', e);
    }
  },

  renderDeheading(container) {
    this.initDeheadingStorage();
    let editRecordId = null;

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">DEHEADING</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Daily Floor Log & Recovery Entry</span>
        </div>

        <!-- Upper Card: Entry Form -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="deheading-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE</label>
                <input type="date" id="dh-arrival-date" value="2026-10-23" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL/LOT CODE <span class="text-red-500 font-bold">*</span></label>
                <select id="dh-lot-code" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="VM-VSP-AMP-056">VM-VSP-AMP-056 (Vannamei - Pond 4A)</option>
                  <option value="BT-KKD-MKP-043">BT-KKD-MKP-043 (Black Tiger - Pond 12)</option>
                  <option value="VM-PSP-BVR-078">VM-PSP-BVR-078 (Vannamei - Pond 2B)</option>
                  <option value="LOT-2026-OCT-095">LOT-2026-OCT-095 (Fresh Harvest)</option>
                  <option value="LOT-2026-OCT-099">LOT-2026-OCT-099 (Premium Lot)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="dh-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="DFL UNIT-1 (VSP)">DFL UNIT-1 (VSP)</option>
                  <option value="DFL UNIT-2 (KKD)">DFL UNIT-2 (KKD)</option>
                  <option value="DFL UNIT-3 (PSP)">DFL UNIT-3 (PSP)</option>
                  <option value="DFL UNIT-5 (JPT)">DFL UNIT-5 (JPT)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">DE HEADING STATION <span class="text-red-500 font-bold">*</span></label>
                <select id="dh-station" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="Own Center">Own Center</option>
                  <option value="Outside Center">Outside Center</option>
                  <option value="Center 1">Center 1</option>
                  <option value="Center 2">Center 2</option>
                  <option value="Station 1">Station 1</option>
                  <option value="Station 2">Station 2</option>
                </select>
              </div>
            </div>

            <!-- Row 2: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">DE HEADING DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="dh-deheading-date" value="2026-10-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SELECT SHIFT <span class="text-red-500 font-bold">*</span></label>
                <select id="dh-shift" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="A SHIFT">A SHIFT</option>
                  <option value="B SHIFT">B SHIFT</option>
                  <option value="C SHIFT">C SHIFT</option>
                  <option value="Day Shift">Day Shift</option>
                  <option value="Night Shift">Night Shift</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPERVISOR <span class="text-red-500 font-bold">*</span></label>
                <select id="dh-supervisor" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="K VENKATA VINAY">K VENKATA VINAY</option>
                  <option value="T.VENKATESH">T.VENKATESH</option>
                  <option value="D.SURYA NARAYANA">D.SURYA NARAYANA</option>
                  <option value="M. NAGESH">M. NAGESH</option>
                  <option value="B. VENKATESH">B. VENKATESH</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HEADON COUNT AFTER CHECKING ( COUNT-2 ) <span class="text-red-500 font-bold">*</span></label>
                <input type="number" step="0.1" id="dh-checking-count-2" placeholder="e.g. 48" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 3: 4 Columns (4th empty) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SAMPLE YIELD(%)</label>
                <input type="number" step="0.01" id="dh-sample-yield" placeholder="e.g. 67.2" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ICE CONSUMPTION</label>
                <input type="number" step="0.1" id="dh-ice-consumption" placeholder="e.g. 450" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">REMARKS</label>
                <input type="text" id="dh-remarks" placeholder="Enter Remarks(Optional)" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div class="hidden lg:block"></div>
            </div>

            <!-- Row 4: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HON QUANTITY(KGS) <span class="text-red-500 font-bold">*</span></label>
                <input type="number" step="0.01" id="dh-hon-qty" placeholder="e.g. 4250" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HL COUNT (PER KG) <span class="text-red-500 font-bold">*</span></label>
                <input type="number" step="0.1" id="dh-hl-count" placeholder="e.g. 32" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HL QUANTITY(KGS) <span class="text-red-500 font-bold">*</span></label>
                <input type="number" step="0.01" id="dh-hl-qty" placeholder="e.g. 2847.5" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HON COUNT (PER KG)</label>
                <input type="number" step="0.1" id="dh-hon-count" placeholder="e.g. 48" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex items-center justify-center gap-3 pt-3">
              <button type="button" id="dh-btn-new" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
                New
              </button>
              <button type="submit" id="dh-btn-save" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <!-- Filter & Export Toolbar -->
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="dh-table-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="dh-btn-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <!-- Table Container with Horizontal Scroll -->
          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.No</th>
                  <th class="py-2.5 px-3">Arrival Code</th>
                  <th class="py-2.5 px-3">Production Plant</th>
                  <th class="py-2.5 px-3">Center</th>
                  <th class="py-2.5 px-3">De Heading Date</th>
                  <th class="py-2.5 px-3">Shift</th>
                  <th class="py-2.5 px-3">Supervisor</th>
                  <th class="py-2.5 px-3 text-right">Checking Count-2</th>
                  <th class="py-2.5 px-3 text-right">HL Count</th>
                  <th class="py-2.5 px-3 text-right">HON Count</th>
                  <th class="py-2.5 px-3 text-right">HON Quantity(Kgs)</th>
                  <th class="py-2.5 px-3 text-right">HL Quantity(Kgs)</th>
                  <th class="py-2.5 px-3 text-right">Count Net Yield(%)</th>
                  <th class="py-2.5 px-3 text-right">Yield(%)</th>
                  <th class="py-2.5 px-3 text-right">Ice Consumption</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="dh-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>

          <!-- Quick Totals Bar -->
          <div id="dh-table-totals" class="mt-4 pt-3 border-t border-[#E2E8F0] flex flex-wrap items-center justify-between gap-3 text-xs text-[#64748B]">
          </div>
        </div>
      </div>
    `;

    const form = document.getElementById('deheading-form');
    const tbody = document.getElementById('dh-table-body');
    const totalsEl = document.getElementById('dh-table-totals');
    const searchInput = document.getElementById('dh-table-search');
    const saveBtn = document.getElementById('dh-btn-save');
    const newBtn = document.getElementById('dh-btn-new');
    const exportBtn = document.getElementById('dh-btn-export-excel');

    // Auto-calculate sample yield when HON & HL Qty entered
    const honQtyInput = document.getElementById('dh-hon-qty');
    const hlQtyInput = document.getElementById('dh-hl-qty');
    const sampleYieldInput = document.getElementById('dh-sample-yield');

    const updateYieldCalculation = () => {
      const hon = parseFloat(honQtyInput.value) || 0;
      const hl = parseFloat(hlQtyInput.value) || 0;
      if (hon > 0 && hl > 0) {
        const y = ((hl / hon) * 100).toFixed(2);
        if (!sampleYieldInput.value || parseFloat(sampleYieldInput.value) === 0) {
          sampleYieldInput.value = y;
        }
      }
    };

    honQtyInput?.addEventListener('input', updateYieldCalculation);
    hlQtyInput?.addEventListener('input', updateYieldCalculation);

    // Render Table Rows
    const renderTable = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.deheadingLogsList.filter(r => {
        if (!q) return true;
        const text = `${r.lotCode || ''} ${r.plant || ''} ${r.center || r.station || ''} ${r.shift || ''} ${r.supervisor || ''} ${r.deheadingDate || r.date || ''}`.toLowerCase();
        return text.includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="16" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td>
          </tr>
        `;
        totalsEl.innerHTML = `<span>Showing 0 records</span>`;
        return;
      }

      let totalHon = 0;
      let totalHl = 0;
      let totalIce = 0;

      tbody.innerHTML = filtered.map((r, idx) => {
        const hon = parseFloat(r.honQty || r.headonWeight || 0);
        const hl = parseFloat(r.hlQty || r.deheadedWeight || 0);
        const ice = parseFloat(r.iceConsumption || r.iceKgs || 0);
        const y = parseFloat(r.yieldPct || (hon > 0 ? (hl / hon) * 100 : 0));
        const cny = parseFloat(r.countNetYield || y);

        totalHon += hon;
        totalHl += hl;
        totalIce += ice;

        return `
          <tr class="hover:bg-[#F8FAFC] transition-colors">
            <td class="py-2.5 px-3 font-bold text-[#64748B]">${idx + 1}</td>
            <td class="py-2.5 px-3 font-bold text-[#0F172A]">${r.lotCode || '-'}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.plant || '-'}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.center || r.station || '-'}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.deheadingDate || r.date || '-'}</td>
            <td class="py-2.5 px-3 font-medium text-[#1E293B]">${r.shift || '-'}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.supervisor || '-'}</td>
            <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${r.checkingCount2 || '-'}</td>
            <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${r.hlCount || '-'}</td>
            <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${r.honCount || '-'}</td>
            <td class="py-2.5 px-3 text-right font-bold text-[#0F172A]">${hon.toLocaleString()}</td>
            <td class="py-2.5 px-3 text-right font-bold text-[#006644]">${hl.toLocaleString()}</td>
            <td class="py-2.5 px-3 text-right font-mono font-medium text-[#006C7A]">${cny.toFixed(2)}%</td>
            <td class="py-2.5 px-3 text-right">
              <span class="px-2 py-0.5 rounded font-mono font-bold text-[11px] bg-[#E3FCEF] text-[#006644]">${y.toFixed(2)}%</span>
            </td>
            <td class="py-2.5 px-3 text-right text-[#334155]">${ice.toLocaleString()}</td>
            <td class="py-2.5 px-3 text-center">
              <div class="flex items-center justify-center gap-1.5">
                <button type="button" data-edit-id="${r.id}" class="dh-row-edit p-1 text-[#02a8b5] hover:text-[#008f9a] hover:bg-[#F0FDFA] rounded cursor-pointer" title="Edit Entry">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                </button>
                <button type="button" data-del-id="${r.id}" class="dh-row-del p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete Entry">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');

      const avgYield = totalHon > 0 ? (totalHl / totalHon) * 100 : 0;
      totalsEl.innerHTML = `
        <div class="flex items-center gap-4 flex-wrap">
          <span>Total Records: <strong class="text-[#0F172A]">${filtered.length}</strong></span>
          <span>Total HON: <strong class="text-[#0F172A]">${totalHon.toLocaleString()} KGS</strong></span>
          <span>Total HLSO: <strong class="text-[#006644]">${totalHl.toLocaleString()} KGS</strong></span>
          <span>Floor Yield: <strong class="text-[#006644]">${avgYield.toFixed(2)}%</strong></span>
          <span>Total Ice: <strong class="text-[#0F172A]">${totalIce.toLocaleString()} KGS</strong></span>
        </div>
        <div class="text-[11px] text-[#94A3B8]">DFL Pre-Processing Unit &bull; Live Telemetry</div>
      `;

      // Attach edit / delete listeners
      tbody.querySelectorAll('.dh-row-edit').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = btn.getAttribute('data-edit-id');
          const rec = this.deheadingLogsList.find(x => x.id === id);
          if (rec) {
            editRecordId = rec.id;
            document.getElementById('dh-arrival-date').value = rec.arrivalDate || rec.date || '2026-10-23';
            document.getElementById('dh-lot-code').value = rec.lotCode || '';
            document.getElementById('dh-plant').value = rec.plant || '';
            document.getElementById('dh-station').value = rec.center || rec.station || '';
            document.getElementById('dh-deheading-date').value = rec.deheadingDate || rec.date || '2026-10-23';
            document.getElementById('dh-shift').value = rec.shift || '';
            document.getElementById('dh-supervisor').value = rec.supervisor || '';
            document.getElementById('dh-checking-count-2').value = rec.checkingCount2 || '';
            document.getElementById('dh-sample-yield').value = rec.sampleYield || rec.yieldPct || '';
            document.getElementById('dh-ice-consumption').value = rec.iceConsumption || rec.iceKgs || '';
            document.getElementById('dh-remarks').value = rec.remarks || '';
            document.getElementById('dh-hon-qty').value = rec.honQty || rec.headonWeight || '';
            document.getElementById('dh-hl-count').value = rec.hlCount || '';
            document.getElementById('dh-hl-qty').value = rec.hlQty || rec.deheadedWeight || '';
            document.getElementById('dh-hon-count').value = rec.honCount || '';

            saveBtn.textContent = 'Update Entry';
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            if (window.Toast) window.Toast.show(`Loaded record for ${rec.lotCode}`, 'info');
          }
        });
      });

      tbody.querySelectorAll('.dh-row-del').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = btn.getAttribute('data-del-id');
          if (confirm('Are you sure you want to delete this deheading operation record?')) {
            this.deheadingLogsList = this.deheadingLogsList.filter(x => x.id !== id);
            try {
              localStorage.setItem('dfl_deheading_logs', JSON.stringify(this.deheadingLogsList));
            } catch (err) {}
            renderTable(searchInput?.value || '');
            if (window.Toast) window.Toast.show('Deheading record deleted', 'info');
          }
        });
      });
    };

    renderTable();

    // Search Filter
    searchInput?.addEventListener('input', (e) => {
      renderTable(e.target.value);
    });

    // Reset / + New button
    newBtn?.addEventListener('click', () => {
      form.reset();
      editRecordId = null;
      document.getElementById('dh-arrival-date').value = '2026-10-23';
      document.getElementById('dh-deheading-date').value = '2026-10-23';
      saveBtn.textContent = 'Save';
      if (window.Toast) window.Toast.show('Ready to create new deheading entry', 'info');
    });

    // Form Submission: Save / Update
    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      const honQty = parseFloat(document.getElementById('dh-hon-qty').value) || 0;
      const hlQty = parseFloat(document.getElementById('dh-hl-qty').value) || 0;
      const yieldPct = honQty > 0 ? Number(((hlQty / honQty) * 100).toFixed(2)) : 0;
      const honCount = parseFloat(document.getElementById('dh-hon-count').value) || 0;
      const hlCount = parseFloat(document.getElementById('dh-hl-count').value) || 0;
      const sampleYield = parseFloat(document.getElementById('dh-sample-yield').value) || yieldPct;
      const countNetYield = Number((yieldPct * (honCount && hlCount ? (honCount / hlCount) * 0.98 : 1)).toFixed(2));

      if (editRecordId) {
        const item = this.deheadingLogsList.find(x => x.id === editRecordId);
        if (item) {
          item.arrivalDate = document.getElementById('dh-arrival-date').value;
          item.lotCode = document.getElementById('dh-lot-code').value;
          item.plant = document.getElementById('dh-plant').value;
          item.center = document.getElementById('dh-station').value;
          item.station = document.getElementById('dh-station').value;
          item.deheadingDate = document.getElementById('dh-deheading-date').value;
          item.date = document.getElementById('dh-deheading-date').value;
          item.shift = document.getElementById('dh-shift').value;
          item.supervisor = document.getElementById('dh-supervisor').value;
          item.checkingCount2 = document.getElementById('dh-checking-count-2').value;
          item.sampleYield = sampleYield;
          item.iceConsumption = parseFloat(document.getElementById('dh-ice-consumption').value) || 0;
          item.iceKgs = item.iceConsumption;
          item.remarks = document.getElementById('dh-remarks').value;
          item.honQty = honQty;
          item.headonWeight = honQty;
          item.hlCount = hlCount;
          item.hlQty = hlQty;
          item.deheadedWeight = hlQty;
          item.honCount = honCount;
          item.countNetYield = countNetYield;
          item.yieldPct = yieldPct;
        }
        editRecordId = null;
        saveBtn.textContent = 'Save';
        if (window.Toast) window.Toast.show('Deheading entry updated successfully!', 'success');
      } else {
        const newRecord = {
          id: 'DH-' + String(Date.now()).slice(-6),
          sNo: this.deheadingLogsList.length + 1,
          arrivalDate: document.getElementById('dh-arrival-date').value,
          lotCode: document.getElementById('dh-lot-code').value,
          plant: document.getElementById('dh-plant').value,
          center: document.getElementById('dh-station').value,
          station: document.getElementById('dh-station').value,
          deheadingDate: document.getElementById('dh-deheading-date').value,
          date: document.getElementById('dh-deheading-date').value,
          shift: document.getElementById('dh-shift').value,
          supervisor: document.getElementById('dh-supervisor').value,
          checkingCount2: document.getElementById('dh-checking-count-2').value,
          sampleYield: sampleYield,
          iceConsumption: parseFloat(document.getElementById('dh-ice-consumption').value) || 0,
          iceKgs: parseFloat(document.getElementById('dh-ice-consumption').value) || 0,
          remarks: document.getElementById('dh-remarks').value,
          honQty: honQty,
          headonWeight: honQty,
          hlCount: hlCount,
          hlQty: hlQty,
          deheadedWeight: hlQty,
          honCount: honCount,
          countNetYield: countNetYield,
          yieldPct: yieldPct,
          status: 'Completed'
        };
        this.deheadingLogsList.unshift(newRecord);
        if (window.Toast) window.Toast.show(`Deheading entry for ${newRecord.lotCode} saved successfully!`, 'success');
      }

      try {
        localStorage.setItem('dfl_deheading_logs', JSON.stringify(this.deheadingLogsList));
      } catch (err) {}

      form.reset();
      document.getElementById('dh-arrival-date').value = '2026-10-23';
      document.getElementById('dh-deheading-date').value = '2026-10-23';
      renderTable(searchInput?.value || '');
    });

    // Excel Export
    exportBtn?.addEventListener('click', () => {
      const headers = [
        "S.No", "Arrival Code", "Production Plant", "Center", "De Heading Date", "Shift",
        "Supervisor", "Checking Count-2", "HL Count", "HON Count", "HON Quantity(Kgs)",
        "HL Quantity(Kgs)", "Count Net Yield(%)", "Yield(%)", "Ice Consumption", "Remarks"
      ];
      const rows = this.deheadingLogsList.map((r, i) => [
        i + 1,
        `"${r.lotCode || ''}"`,
        `"${r.plant || ''}"`,
        `"${r.center || r.station || ''}"`,
        `"${r.deheadingDate || r.date || ''}"`,
        `"${r.shift || ''}"`,
        `"${r.supervisor || ''}"`,
        `"${r.checkingCount2 || ''}"`,
        `"${r.hlCount || ''}"`,
        `"${r.honCount || ''}"`,
        r.honQty || r.headonWeight || 0,
        r.hlQty || r.deheadedWeight || 0,
        (r.countNetYield || r.yieldPct || 0).toFixed(2),
        (r.yieldPct || 0).toFixed(2),
        r.iceConsumption || r.iceKgs || 0,
        `"${(r.remarks || '').replace(/"/g, '""')}"`
      ]);

      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `deheading_operations_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      if (window.Toast) window.Toast.show('Excel CSV export downloaded!', 'success');
    });
  },

  initGradingStorage() {
    try {
      const stored = localStorage.getItem('dfl_grading_logs');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.gradingLogsList = parsed;
        }
      }
    } catch (e) {
      console.warn('Grading storage read error:', e);
    }
  },

  renderGrading(container) {
    this.initGradingStorage();
    let selectedRecordId = null;

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">GRADING</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Grading Machine Run Log</span>
        </div>

        <!-- Upper Card: Entry Form -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="grading-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="gr-arrival-date" value="2025-03-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL/LOT CODE <span class="text-red-500 font-bold">*</span></label>
                <div class="relative">
                  <select id="gr-lot-code" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                    <option value="SKM/2425/1755">SKM/2425/1755 - 47.00 - 87.000</option>
                    <option value="VM-VSP-AMP-056">VM-VSP-AMP-056 - 48.00 - 67.000</option>
                    <option value="BT-KKD-MKP-043">BT-KKD-MKP-043 - 52.00 - 65.000</option>
                    <option value="VM-PSP-BVR-078">VM-PSP-BVR-078 - 44.00 - 68.000</option>
                    <option value="LOT-2026-OCT-095">LOT-2026-OCT-095 - Fresh Harvest</option>
                  </select>
                </div>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="gr-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="DFL UNIT-6 [JPT-II]" selected>JPT-II</option>
                  <option value="DFL UNIT-1 (VSP)">DFL UNIT-1 (VSP)</option>
                  <option value="DFL UNIT-2 (KKD)">DFL UNIT-2 (KKD)</option>
                  <option value="DFL UNIT-3 (PSP)">DFL UNIT-3 (PSP)</option>
                  <option value="DFL UNIT-5 (JPT)">DFL UNIT-5 (JPT)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">GRADING STATION <span class="text-red-500 font-bold">*</span></label>
                <select id="gr-station" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="Own Center" selected>Own Center</option>
                  <option value="Outside Center">Outside Center</option>
                  <option value="Station 1">Station 1</option>
                  <option value="Station 2">Station 2</option>
                </select>
              </div>
            </div>

            <!-- Row 2: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">GRADING DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="gr-grading-date" value="2025-03-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">GRADING MACHINE <span class="text-red-500 font-bold">*</span></label>
                <select id="gr-machine" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="Unit -6 Laitram Grading Machine" selected>Unit -6 Laitram Grading Machine</option>
                  <option value="Unit -1 Sort-Rite Machine">Unit -1 Sort-Rite Machine</option>
                  <option value="Unit -2 Key Tech Grader">Unit -2 Key Tech Grader</option>
                  <option value="Station Grader 03">Station Grader 03</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">START TIME <span class="text-red-500 font-bold">*</span></label>
                <input type="time" id="gr-start-time" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">END TIME <span class="text-red-500 font-bold">*</span></label>
                <input type="time" id="gr-end-time" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 3: 4 Columns (Columns 3 & 4 empty) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">BREAK TIME(MINUTES) <span class="text-red-500 font-bold">*</span></label>
                <input type="number" id="gr-break-time" placeholder="Enter Break Time" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">REMARKS</label>
                <input type="text" id="gr-remarks" placeholder="Enter Remarks(Optional)" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div class="hidden lg:block"></div>
              <div class="hidden lg:block"></div>
            </div>

            <!-- Row 4: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SELECT VARIETY <span class="text-red-500 font-bold">*</span></label>
                <select id="gr-variety" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="VM-HLSO" selected>VM-HLSO</option>
                  <option value="BT-HLSO">BT-HLSO</option>
                  <option value="SEA-HLSO">SEA-HLSO</option>
                  <option value="HOSO-GRADE">HOSO-GRADE</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HL COUNT(PER LB)</label>
                <input type="number" step="0.01" id="gr-hl-count" placeholder="Enter HL Count" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HL WEIGHT(KGS)</label>
                <input type="number" step="0.01" id="gr-hl-weight" placeholder="Enter HL Weight(Kgs)" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">NO OF CRATES</label>
                <input type="number" id="gr-no-crates" placeholder="Enter No Of Crates" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Buttons: + New, Save, Delete -->
            <div class="flex items-center justify-center gap-3 pt-3">
              <button type="button" id="gr-btn-new" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
                New
              </button>
              <button type="submit" id="gr-btn-save" class="px-6 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
              <button type="button" id="gr-btn-delete" class="px-5 py-2 bg-[#EF4444] hover:bg-[#DC2626] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                Delete
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <!-- Filter & Export Toolbar -->
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="gr-table-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="gr-btn-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <!-- Table Container with Horizontal Scroll -->
          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.No</th>
                  <th class="py-2.5 px-3">Transaction Date</th>
                  <th class="py-2.5 px-3">Arrival Code</th>
                  <th class="py-2.5 px-3">Production Plant</th>
                  <th class="py-2.5 px-3">Center</th>
                  <th class="py-2.5 px-3">Grading Machine</th>
                  <th class="py-2.5 px-3">Start Time</th>
                  <th class="py-2.5 px-3">End Time</th>
                  <th class="py-2.5 px-3 text-right">Break Time(Minutes)</th>
                  <th class="py-2.5 px-3 text-right">HL Count</th>
                  <th class="py-2.5 px-3 text-right">HL Weight</th>
                  <th class="py-2.5 px-3 text-right">No Of Crates</th>
                  <th class="py-2.5 px-3">Remarks</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="gr-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>

          <!-- Quick Totals Bar -->
          <div id="gr-table-totals" class="mt-4 pt-3 border-t border-[#E2E8F0] flex flex-wrap items-center justify-between gap-3 text-xs text-[#64748B]">
          </div>
        </div>
      </div>
    `;

    const form = document.getElementById('grading-form');
    const tbody = document.getElementById('gr-table-body');
    const totalsEl = document.getElementById('gr-table-totals');
    const searchInput = document.getElementById('gr-table-search');
    const saveBtn = document.getElementById('gr-btn-save');
    const newBtn = document.getElementById('gr-btn-new');
    const deleteBtn = document.getElementById('gr-btn-delete');
    const exportBtn = document.getElementById('gr-btn-export-excel');

    // Render Table Rows
    const renderTable = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.gradingLogsList.filter(r => {
        if (!q) return true;
        const text = `${r.lotCode || ''} ${r.plant || ''} ${r.center || r.station || ''} ${r.gradingMachine || ''} ${r.transactionDate || r.date || ''} ${r.remarks || ''}`.toLowerCase();
        return text.includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="14" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td>
          </tr>
        `;
        totalsEl.innerHTML = `<span>Showing 0 records</span>`;
        return;
      }

      let totalWeight = 0;
      let totalCrates = 0;

      tbody.innerHTML = filtered.map((r, idx) => {
        const wt = parseFloat(r.hlWeight || r.gradedWeight || 0);
        const crates = parseInt(r.noOfCrates || 0, 10);
        totalWeight += wt;
        totalCrates += crates;

        return `
          <tr class="hover:bg-[#F8FAFC] transition-colors cursor-pointer gr-table-row ${selectedRecordId === r.id ? 'bg-[#F0FDFA]' : ''}" data-id="${r.id}">
            <td class="py-2.5 px-3 font-bold text-[#64748B]">${idx + 1}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.transactionDate || r.date || '23-03-2025'}</td>
            <td class="py-2.5 px-3 font-bold text-[#0F172A]">${r.lotCode || '-'}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.plant || '-'}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.center || ''}</td>
            <td class="py-2.5 px-3 text-[#334155]">${r.gradingMachine || '-'}</td>
            <td class="py-2.5 px-3 text-[#64748B]">${r.startTime || ''}</td>
            <td class="py-2.5 px-3 text-[#64748B]">${r.endTime || ''}</td>
            <td class="py-2.5 px-3 text-right text-[#64748B]">${r.breakTime || ''}</td>
            <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${Number(r.hlCount || 0).toFixed(2)}</td>
            <td class="py-2.5 px-3 text-right font-bold text-[#006644]">${wt.toFixed(2)}</td>
            <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${crates}</td>
            <td class="py-2.5 px-3 text-[#64748B]">${r.remarks || ''}</td>
            <td class="py-2.5 px-3 text-center">
              <button type="button" data-del-id="${r.id}" class="gr-row-del p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete Row">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
              </button>
            </td>
          </tr>
        `;
      }).join('');

      totalsEl.innerHTML = `
        <div class="flex items-center gap-4 flex-wrap">
          <span>Total Records: <strong class="text-[#0F172A]">${filtered.length}</strong></span>
          <span>Total HL Weight: <strong class="text-[#006644]">${totalWeight.toFixed(2)} KGS</strong></span>
          <span>Total Crates: <strong class="text-[#0F172A]">${totalCrates}</strong></span>
        </div>
        <div class="text-[11px] text-[#94A3B8]">DFL Pre-Processing Unit &bull; Laitram Sizing Line</div>
      `;

      // Row Click -> Load into Form
      tbody.querySelectorAll('.gr-table-row').forEach(tr => {
        tr.addEventListener('click', (e) => {
          if (e.target.closest('.gr-row-del')) return;
          const id = tr.getAttribute('data-id');
          const rec = this.gradingLogsList.find(x => x.id === id);
          if (rec) {
            selectedRecordId = rec.id;
            document.getElementById('gr-arrival-date').value = rec.arrivalDate || '2025-03-23';
            document.getElementById('gr-lot-code').value = rec.lotCode || '';
            document.getElementById('gr-plant').value = rec.plant || 'DFL UNIT-6 [JPT-II]';
            document.getElementById('gr-station').value = rec.station || 'Own Center';
            document.getElementById('gr-grading-date').value = rec.date || '2025-03-23';
            document.getElementById('gr-machine').value = rec.gradingMachine || 'Unit -6 Laitram Grading Machine';
            document.getElementById('gr-start-time').value = rec.startTime || '';
            document.getElementById('gr-end-time').value = rec.endTime || '';
            document.getElementById('gr-break-time').value = rec.breakTime || '';
            document.getElementById('gr-remarks').value = rec.remarks || '';
            document.getElementById('gr-variety').value = rec.variety || 'VM-HLSO';
            document.getElementById('gr-hl-count').value = rec.hlCount || '';
            document.getElementById('gr-hl-weight').value = rec.hlWeight || rec.gradedWeight || '';
            document.getElementById('gr-no-crates').value = rec.noOfCrates || '';

            saveBtn.textContent = 'Update Entry';
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            renderTable(searchInput?.value || '');
            if (window.Toast) window.Toast.show(`Loaded grading log #${rec.sNo}`, 'info');
          }
        });
      });

      // Row Delete
      tbody.querySelectorAll('.gr-row-del').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-del-id');
          if (confirm('Are you sure you want to delete this grading record?')) {
            this.gradingLogsList = this.gradingLogsList.filter(x => x.id !== id);
            try {
              localStorage.setItem('dfl_grading_logs', JSON.stringify(this.gradingLogsList));
            } catch (err) {}
            if (selectedRecordId === id) {
              selectedRecordId = null;
              form.reset();
              saveBtn.textContent = 'Save';
            }
            renderTable(searchInput?.value || '');
            if (window.Toast) window.Toast.show('Grading entry deleted', 'info');
          }
        });
      });
    };

    renderTable();

    // Search Filter
    searchInput?.addEventListener('input', (e) => {
      renderTable(e.target.value);
    });

    // Reset / + New button
    newBtn?.addEventListener('click', () => {
      form.reset();
      selectedRecordId = null;
      document.getElementById('gr-arrival-date').value = '2025-03-23';
      document.getElementById('gr-grading-date').value = '2025-03-23';
      document.getElementById('gr-plant').value = 'DFL UNIT-6 [JPT-II]';
      document.getElementById('gr-station').value = 'Own Center';
      document.getElementById('gr-machine').value = 'Unit -6 Laitram Grading Machine';
      document.getElementById('gr-variety').value = 'VM-HLSO';
      saveBtn.textContent = 'Save';
      renderTable(searchInput?.value || '');
      if (window.Toast) window.Toast.show('Ready to create new grading run', 'info');
    });

    // Delete button in Form
    deleteBtn?.addEventListener('click', () => {
      if (!selectedRecordId) {
        if (window.Toast) window.Toast.show('Please select a row from the table to delete', 'warning');
        return;
      }
      if (confirm('Are you sure you want to delete the selected grading record?')) {
        this.gradingLogsList = this.gradingLogsList.filter(x => x.id !== selectedRecordId);
        try {
          localStorage.setItem('dfl_grading_logs', JSON.stringify(this.gradingLogsList));
        } catch (err) {}
        selectedRecordId = null;
        form.reset();
        saveBtn.textContent = 'Save';
        renderTable(searchInput?.value || '');
        if (window.Toast) window.Toast.show('Grading entry deleted', 'info');
      }
    });

    // Form Submission: Save / Update
    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      const hlCount = parseFloat(document.getElementById('gr-hl-count').value) || 0;
      const hlWeight = parseFloat(document.getElementById('gr-hl-weight').value) || 0;
      const noOfCrates = parseInt(document.getElementById('gr-no-crates').value, 10) || 0;
      const breakTime = document.getElementById('gr-break-time').value;
      const remarks = document.getElementById('gr-remarks').value;
      const startTime = document.getElementById('gr-start-time').value;
      const endTime = document.getElementById('gr-end-time').value;

      if (selectedRecordId) {
        const item = this.gradingLogsList.find(x => x.id === selectedRecordId);
        if (item) {
          item.arrivalDate = document.getElementById('gr-arrival-date').value;
          item.transactionDate = item.arrivalDate.split('-').reverse().join('-');
          item.lotCode = document.getElementById('gr-lot-code').value;
          item.plant = document.getElementById('gr-plant').value;
          item.station = document.getElementById('gr-station').value;
          item.date = document.getElementById('gr-grading-date').value;
          item.gradingMachine = document.getElementById('gr-machine').value;
          item.startTime = startTime;
          item.endTime = endTime;
          item.breakTime = breakTime;
          item.variety = document.getElementById('gr-variety').value;
          item.hlCount = hlCount.toFixed(2);
          item.dominantCount = item.hlCount;
          item.hlWeight = hlWeight.toFixed(2);
          item.gradedWeight = hlWeight;
          item.noOfCrates = noOfCrates;
          item.remarks = remarks;
        }
        selectedRecordId = null;
        saveBtn.textContent = 'Save';
        if (window.Toast) window.Toast.show('Grading entry updated successfully!', 'success');
      } else {
        const rawDate = document.getElementById('gr-grading-date').value || '2025-03-23';
        const formattedDate = rawDate.split('-').reverse().join('-');
        const newRecord = {
          id: 'GR-' + String(Date.now()).slice(-6),
          sNo: this.gradingLogsList.length + 1,
          transactionDate: formattedDate,
          date: rawDate,
          arrivalDate: document.getElementById('gr-arrival-date').value,
          lotCode: document.getElementById('gr-lot-code').value,
          plant: document.getElementById('gr-plant').value,
          center: '',
          station: document.getElementById('gr-station').value,
          gradingMachine: document.getElementById('gr-machine').value,
          startTime: startTime,
          endTime: endTime,
          breakTime: breakTime,
          variety: document.getElementById('gr-variety').value,
          hlCount: hlCount.toFixed(2),
          dominantCount: hlCount.toFixed(2),
          hlWeight: hlWeight.toFixed(2),
          gradedWeight: hlWeight,
          noOfCrates: noOfCrates,
          remarks: remarks,
          status: 'Approved'
        };
        this.gradingLogsList.push(newRecord);
        if (window.Toast) window.Toast.show(`Grading entry for ${newRecord.lotCode} saved successfully!`, 'success');
      }

      try {
        localStorage.setItem('dfl_grading_logs', JSON.stringify(this.gradingLogsList));
      } catch (err) {}

      form.reset();
      document.getElementById('gr-arrival-date').value = '2025-03-23';
      document.getElementById('gr-grading-date').value = '2025-03-23';
      document.getElementById('gr-plant').value = 'DFL UNIT-6 [JPT-II]';
      document.getElementById('gr-station').value = 'Own Center';
      document.getElementById('gr-machine').value = 'Unit -6 Laitram Grading Machine';
      document.getElementById('gr-variety').value = 'VM-HLSO';
      renderTable(searchInput?.value || '');
    });

    // Excel Export
    exportBtn?.addEventListener('click', () => {
      const headers = [
        "S.No", "Transaction Date", "Arrival Code", "Production Plant", "Center",
        "Grading Machine", "Start Time", "End Time", "Break Time(Minutes)", "HL Count",
        "HL Weight", "No Of Crates", "Remarks"
      ];
      const rows = this.gradingLogsList.map((r, i) => [
        i + 1,
        `"${r.transactionDate || r.date || ''}"`,
        `"${r.lotCode || ''}"`,
        `"${r.plant || ''}"`,
        `"${r.center || ''}"`,
        `"${r.gradingMachine || ''}"`,
        `"${r.startTime || ''}"`,
        `"${r.endTime || ''}"`,
        `"${r.breakTime || ''}"`,
        `"${r.hlCount || ''}"`,
        `"${r.hlWeight || r.gradedWeight || ''}"`,
        `"${r.noOfCrates || ''}"`,
        `"${(r.remarks || '').replace(/"/g, '""')}"`
      ]);

      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `grading_operations_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      if (window.Toast) window.Toast.show('Excel CSV export downloaded!', 'success');
    });
  },

  renderDeheadingTrackid(container) {
    if (!this.deheadingTrackidList || this.deheadingTrackidList.length === 0) {
      this.deheadingTrackidList = [
        { id: "DHT-01", sNo: 1, plant: "VSP-DFL UNIT-1 (VSP)", arrivalDate: "2026-10-23", trackId: "VM-VSP-AMP-056", deheadingDate: "2026-10-23", shift: "A SHIFT", supervisor: "K VENKATA VINAY", remarks: "Floor processing regular batch", status: "Active" },
        { id: "DHT-02", sNo: 2, plant: "KKD-DFL UNIT-2 (KKD)", arrivalDate: "2026-10-23", trackId: "BT-KKD-MKP-043", deheadingDate: "2026-10-23", shift: "B SHIFT", supervisor: "T.VENKATESH", remarks: "Chilled temp pass", status: "Active" }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">DE-HEADING TRACKID</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Track ID Assignment</span>
        </div>

        <!-- Upper Card: Entry Form -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="dht-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="dht-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VSP-DFL UNIT-1 (VSP)" selected>VSP-DFL UNIT-1 (VSP)</option>
                  <option value="KKD-DFL UNIT-2 (KKD)">KKD-DFL UNIT-2 (KKD)</option>
                  <option value="PSP-DFL UNIT-3 (PSP)">PSP-DFL UNIT-3 (PSP)</option>
                  <option value="JPT-DFL UNIT-5 (JPT)">JPT-DFL UNIT-5 (JPT)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="dht-arrival-date" value="2026-10-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRACK ID <span class="text-red-500 font-bold">*</span></label>
                <select id="dht-track-id" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="VM-VSP-AMP-056" selected>VM-VSP-AMP-056</option>
                  <option value="BT-KKD-MKP-043">BT-KKD-MKP-043</option>
                  <option value="VM-PSP-BVR-078">VM-PSP-BVR-078</option>
                  <option value="LOT-2026-OCT-095">LOT-2026-OCT-095</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">DE HEADING DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="dht-dh-date" value="2026-10-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 2: 3 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SHIFT <span class="text-red-500 font-bold">*</span></label>
                <select id="dht-shift" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="A SHIFT" selected>A SHIFT</option>
                  <option value="B SHIFT">B SHIFT</option>
                  <option value="C SHIFT">C SHIFT</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPERVISOR <span class="text-red-500 font-bold">*</span></label>
                <select id="dht-supervisor" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="K VENKATA VINAY" selected>K VENKATA VINAY</option>
                  <option value="T.VENKATESH">T.VENKATESH</option>
                  <option value="D.SURYA NARAYANA">D.SURYA NARAYANA</option>
                </select>
              </div>
              <div class="sm:col-span-2">
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">REMARKS</label>
                <input type="text" id="dht-remarks" placeholder="Enter Remarks(Optional)" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] placeholder-[#94A3B8] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Button -->
            <div class="flex items-center justify-center pt-2">
              <button type="submit" class="px-7 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="dht-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="dht-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.No</th>
                  <th class="py-2.5 px-3">Production Plant</th>
                  <th class="py-2.5 px-3">Arrival Date</th>
                  <th class="py-2.5 px-3">Track ID</th>
                  <th class="py-2.5 px-3">De Heading Date</th>
                  <th class="py-2.5 px-3">Shift</th>
                  <th class="py-2.5 px-3">Supervisor</th>
                  <th class="py-2.5 px-3">Remarks</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="dht-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('dht-table-body');
    const searchInput = document.getElementById('dht-search');
    const form = document.getElementById('dht-form');
    const exportBtn = document.getElementById('dht-export-excel');

    const renderTable = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.deheadingTrackidList.filter(r => {
        if (!q) return true;
        return `${r.plant || ''} ${r.trackId || ''} ${r.shift || ''} ${r.supervisor || ''}`.toLowerCase().includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map((r, idx) => `
        <tr class="hover:bg-[#F8FAFC] transition-colors">
          <td class="py-2.5 px-3 font-bold text-[#64748B]">${idx + 1}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.plant || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.arrivalDate || '-'}</td>
          <td class="py-2.5 px-3 font-bold text-[#0F172A]">${r.trackId || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.deheadingDate || '-'}</td>
          <td class="py-2.5 px-3 font-medium text-[#1E293B]">${r.shift || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.supervisor || '-'}</td>
          <td class="py-2.5 px-3 text-[#64748B]">${r.remarks || ''}</td>
          <td class="py-2.5 px-3 text-center">
            <button type="button" data-del-id="${r.id}" class="dht-del p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete Entry">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </td>
        </tr>
      `).join('');

      tbody.querySelectorAll('.dht-del').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-del-id');
          if (confirm('Delete this De-Heading Track ID record?')) {
            this.deheadingTrackidList = this.deheadingTrackidList.filter(x => x.id !== id);
            renderTable(searchInput?.value || '');
            if (window.Toast) window.Toast.show('Record deleted', 'info');
          }
        });
      });
    };

    renderTable();

    searchInput?.addEventListener('input', (e) => renderTable(e.target.value));

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      const newRec = {
        id: 'DHT-' + String(Date.now()).slice(-6),
        sNo: this.deheadingTrackidList.length + 1,
        plant: document.getElementById('dht-plant').value,
        arrivalDate: document.getElementById('dht-arrival-date').value,
        trackId: document.getElementById('dht-track-id').value,
        deheadingDate: document.getElementById('dht-dh-date').value,
        shift: document.getElementById('dht-shift').value,
        supervisor: document.getElementById('dht-supervisor').value,
        remarks: document.getElementById('dht-remarks').value,
        status: 'Active'
      };
      this.deheadingTrackidList.unshift(newRec);
      renderTable(searchInput?.value || '');
      form.reset();
      document.getElementById('dht-arrival-date').value = '2026-10-23';
      document.getElementById('dht-dh-date').value = '2026-10-23';
      if (window.Toast) window.Toast.show(`De-heading track ID ${newRec.trackId} saved`, 'success');
    });

    exportBtn?.addEventListener('click', () => {
      const headers = ["S.No", "Production Plant", "Arrival Date", "Track ID", "De Heading Date", "Shift", "Supervisor", "Remarks"];
      const rows = this.deheadingTrackidList.map((r, i) => [
        i + 1,
        `"${r.plant || ''}"`,
        `"${r.arrivalDate || ''}"`,
        `"${r.trackId || ''}"`,
        `"${r.deheadingDate || ''}"`,
        `"${r.shift || ''}"`,
        `"${r.supervisor || ''}"`,
        `"${(r.remarks || '').replace(/"/g, '""')}"`
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `deheading_trackid_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('De-heading Track ID report exported to CSV', 'success');
    });
  },

  renderGradingTrackid(container) {
    if (!this.gradingTrackLines || this.gradingTrackLines.length === 0) {
      this.gradingTrackLines = [
        { id: "GTL-01", sNo: 1, variety: "VM-PVPD", hlCount: "55.00", grade: "51/60", treatment: "UNT", freezing: "BLOCK", crates: 1, gradingQty: "2.00", tubWeight: "" },
        { id: "GTL-02", sNo: 2, variety: "VM-HLSO-CHINA", hlCount: "67.00", grade: "61/70", treatment: "UNT", freezing: "BLOCK", crates: 9, gradingQty: "233.00", tubWeight: "" },
        { id: "GTL-03", sNo: 3, variety: "VM-RPD", hlCount: "68.00", grade: "61/70", treatment: "CTPD", freezing: "IQF", crates: 1, gradingQty: "15.00", tubWeight: "" }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">GRADING TRACKID</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Track-Level Grading with Dynamic Tabular Grid</span>
        </div>

        <!-- Upper Card: Entry Form with Multi-Lot Breakdown Box -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="gr-track-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="gt-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="USHA-DFL UNIT-2 (KKD)" selected>USHA-DFL UNIT-2 (KKD)</option>
                  <option value="VSP-DFL UNIT-1 (VSP)">VSP-DFL UNIT-1 (VSP)</option>
                  <option value="PSP-DFL UNIT-3 (PSP)">PSP-DFL UNIT-3 (PSP)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="gt-arrival-date" value="2025-02-20" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRACK ID <span class="text-red-500 font-bold">*</span></label>
                <select id="gt-track-id" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VM-KKD-AMP-071" selected>VM-KKD-AMP-071</option>
                  <option value="VM-VSP-AMP-056">VM-VSP-AMP-056</option>
                  <option value="BT-KKD-MKP-043">BT-KKD-MKP-043</option>
                </select>
              </div>
              <div class="row-span-2">
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">RECEIVING COUNT <span class="text-red-500 font-bold">*</span></label>
                <div class="w-full h-[118px] overflow-y-auto px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-lg text-[11px] font-mono text-[#334155] space-y-1">
                  <div>AMP/2425/4044 (121.000 - 713.000)</div>
                  <div>AMP/2425/4044 (119.000 - 696.800)</div>
                  <div>AMP/2425/4044 (136.000 - 622.600)</div>
                  <div>AMP/2425/4044 (122.000 - 735.000)</div>
                  <div>AMP/2425/4044 (130.000 - 801.000)</div>
                  <div>AMP/2425/4044 (115.000 - 729.000)</div>
                  <div>AMP/2425/4044 (140.000 - 307.600)</div>
                  <div>AMP/2425/4044 (142.000 - 818.000)</div>
                </div>
              </div>

              <!-- Row 2 (Columns 1 to 3) -->
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">GRADING DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="gt-grading-date" value="2025-02-20" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">GRADING MACHINE <span class="text-red-500 font-bold">*</span></label>
                <select id="gt-machine" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="Unit -2 Roller Grading Machine" selected>Unit -2 Roller Grading Machine</option>
                  <option value="Unit -6 Laitram Machine">Unit -6 Laitram Machine</option>
                </select>
              </div>
              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">START TIME</label>
                  <input type="text" id="gt-start-time" value="09:00 AM" class="w-full px-2 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                </div>
                <div>
                  <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">END TIME</label>
                  <input type="text" id="gt-end-time" value="11:40 AM" class="w-full px-2 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                </div>
              </div>
            </div>

            <!-- Row 3: 3 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">BREAK TIME(MINUTES)</label>
                <input type="number" id="gt-break-time" placeholder="Enter Break Time" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPERVISOR <span class="text-red-500 font-bold">*</span></label>
                <select id="gt-supervisor" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="K VENKATA VINAY" selected>K VENKATA VINAY</option>
                  <option value="T.VENKATESH">T.VENKATESH</option>
                  <option value="S.BALA KRISHNA">S.BALA KRISHNA</option>
                </select>
              </div>
              <div class="sm:col-span-2">
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">REMARKS</label>
                <input type="text" id="gt-remarks" value="Good" placeholder="Enter Remarks" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Buttons: Save Grading, + Add Line, Delete -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="submit" id="gt-btn-save" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save Grading
              </button>
              <button type="button" id="gt-btn-add-line" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
                Add Line
              </button>
              <button type="button" id="gt-btn-delete" class="px-5 py-2 bg-[#EF4444] hover:bg-[#DC2626] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                Delete
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Fully Editable Tabular Grid -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="gt-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="gt-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">SNO</th>
                  <th class="py-2.5 px-3">Variety</th>
                  <th class="py-2.5 px-3">HL_Count (Per Lb)</th>
                  <th class="py-2.5 px-3">Grade</th>
                  <th class="py-2.5 px-3">Treatment</th>
                  <th class="py-2.5 px-3">Freezing</th>
                  <th class="py-2.5 px-3 text-right">No Of Crates</th>
                  <th class="py-2.5 px-3 text-right">Grading Qty</th>
                  <th class="py-2.5 px-3">HL/Tub Weight</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="gt-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('gt-table-body');
    const searchInput = document.getElementById('gt-search');
    const addLineBtn = document.getElementById('gt-btn-add-line');
    const deleteBtn = document.getElementById('gt-btn-delete');
    const exportBtn = document.getElementById('gt-export-excel');
    const form = document.getElementById('gr-track-form');

    const varieties = ["VM-PVPD", "VM-HLSO-CHINA", "VM-RPD", "VM-HLSO", "BT-HLSO"];
    const grades = ["51/60", "61/70", "71/90", "91/110", "110/130", "16/20", "21/25", "26/30", "31/40"];
    const treatments = ["UNT", "TRT", "CTPD"];
    const freezings = ["BLOCK", "IQF", "SIQF"];

    const renderGrid = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.gradingTrackLines.filter(r => {
        if (!q) return true;
        return `${r.variety || ''} ${r.grade || ''} ${r.treatment || ''} ${r.freezing || ''}`.toLowerCase().includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map((r, idx) => `
        <tr class="hover:bg-[#F8FAFC] transition-colors" data-id="${r.id}">
          <td class="py-2 px-3 font-bold text-[#64748B]">${idx + 1}</td>
          <td class="py-2 px-3">
            <select data-field="variety" data-id="${r.id}" class="gt-inline px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none">
              ${varieties.map(v => `<option value="${v}" ${r.variety === v ? 'selected' : ''}>${v}</option>`).join('')}
            </select>
          </td>
          <td class="py-2 px-3">
            <input type="number" step="0.01" value="${r.hlCount || ''}" data-field="hlCount" data-id="${r.id}" class="gt-inline w-24 px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none font-semibold">
          </td>
          <td class="py-2 px-3">
            <select data-field="grade" data-id="${r.id}" class="gt-inline px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none font-mono">
              ${grades.map(g => `<option value="${g}" ${r.grade === g ? 'selected' : ''}>${g}</option>`).join('')}
            </select>
          </td>
          <td class="py-2 px-3">
            <select data-field="treatment" data-id="${r.id}" class="gt-inline px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none">
              ${treatments.map(t => `<option value="${t}" ${r.treatment === t ? 'selected' : ''}>${t}</option>`).join('')}
            </select>
          </td>
          <td class="py-2 px-3">
            <select data-field="freezing" data-id="${r.id}" class="gt-inline px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none">
              ${freezings.map(f => `<option value="${f}" ${r.freezing === f ? 'selected' : ''}>${f}</option>`).join('')}
            </select>
          </td>
          <td class="py-2 px-3 text-right">
            <input type="number" value="${r.crates || ''}" data-field="crates" data-id="${r.id}" class="gt-inline w-20 text-right px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none">
          </td>
          <td class="py-2 px-3 text-right">
            <input type="number" step="0.01" value="${r.gradingQty || ''}" data-field="gradingQty" data-id="${r.id}" class="gt-inline w-24 text-right px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs font-bold text-[#006644] focus:border-[#02a8b5] outline-none">
          </td>
          <td class="py-2 px-3">
            <input type="text" placeholder="Enter Crate Qty" value="${r.tubWeight || ''}" data-field="tubWeight" data-id="${r.id}" class="gt-inline w-28 px-2 py-1 bg-white border border-[#CBD5E1] rounded text-xs text-[#0F172A] focus:border-[#02a8b5] outline-none">
          </td>
          <td class="py-2 px-3 text-center">
            <div class="flex items-center justify-center gap-1.5">
              <button type="button" data-save-id="${r.id}" class="gt-save-row p-1 text-[#0284C7] hover:bg-[#F0F9FF] rounded cursor-pointer" title="Lock / Save Line">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg>
              </button>
              <button type="button" data-del-id="${r.id}" class="gt-del-row p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete Line">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('');

      tbody.querySelectorAll('.gt-inline').forEach(el => {
        el.addEventListener('change', (e) => {
          const id = e.target.getAttribute('data-id');
          const field = e.target.getAttribute('data-field');
          const rec = this.gradingTrackLines.find(x => x.id === id);
          if (rec) {
            rec[field] = e.target.value;
          }
        });
      });

      tbody.querySelectorAll('.gt-save-row').forEach(btn => {
        btn.addEventListener('click', () => {
          if (window.Toast) window.Toast.show('Grading line locked & saved', 'success');
        });
      });

      tbody.querySelectorAll('.gt-del-row').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-del-id');
          if (confirm('Delete this grading size line?')) {
            this.gradingTrackLines = this.gradingTrackLines.filter(x => x.id !== id);
            renderGrid(searchInput?.value || '');
            if (window.Toast) window.Toast.show('Grading size line deleted', 'info');
          }
        });
      });
    };

    renderGrid();

    // + Add Line button
    addLineBtn?.addEventListener('click', () => {
      const newLine = {
        id: 'GTL-' + String(Date.now()).slice(-6),
        sNo: this.gradingTrackLines.length + 1,
        variety: "VM-PVPD",
        hlCount: "60.00",
        grade: "51/60",
        treatment: "UNT",
        freezing: "BLOCK",
        crates: 1,
        gradingQty: "0.00",
        tubWeight: ""
      };
      this.gradingTrackLines.push(newLine);
      renderGrid(searchInput?.value || '');
      if (window.Toast) window.Toast.show('New editable line added to grading table', 'info');
    });

    // Delete Last Line
    deleteBtn?.addEventListener('click', () => {
      if (this.gradingTrackLines.length === 0) return;
      if (confirm('Delete the last grading line?')) {
        this.gradingTrackLines.pop();
        renderGrid(searchInput?.value || '');
        if (window.Toast) window.Toast.show('Line removed', 'info');
      }
    });

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      if (window.Toast) window.Toast.show('Grading Track ID batch recorded successfully!', 'success');
    });

    searchInput?.addEventListener('input', (e) => renderGrid(e.target.value));

    exportBtn?.addEventListener('click', () => {
      const headers = ["SNO", "Variety", "HL_Count (Per Lb)", "Grade", "Treatment", "Freezing", "No Of Crates", "Grading Qty", "HL/Tub Weight"];
      const rows = this.gradingTrackLines.map((r, i) => [
        i + 1,
        `"${r.variety || ''}"`,
        r.hlCount || '',
        `"${r.grade || ''}"`,
        `"${r.treatment || ''}"`,
        `"${r.freezing || ''}"`,
        r.crates || 0,
        r.gradingQty || 0,
        `"${r.tubWeight || ''}"`
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `grading_trackid_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('Grading Track report exported to CSV', 'success');
    });
  },

  renderValueAddition(container) {
    if (!this.valueAdditionList || this.valueAdditionList.length === 0) {
      this.valueAdditionList = [
        { id: "VA-01", sNo: 1, arrivalCode: "AMP/2425/4078", plant: "DFL UNIT-1 (VSP)", soakingPlant: "DFL UNIT-2 (KKD)", date: "24-02-2025", shift: "A SHIFT", variety: "VM RPD", hlWeight: 2.400, hlCount: 37.00, crates: 1, vaOutQty: 2.000, rejectionWt: 0.000, yieldPct: 83.33 },
        { id: "VA-02", sNo: 2, arrivalCode: "AMP/2425/4078", plant: "DFL UNIT-1 (VSP)", soakingPlant: "DFL UNIT-2 (KKD)", date: "24-02-2025", shift: "A SHIFT", variety: "VM RPD FULL CUT", hlWeight: 8.400, hlCount: 46.00, crates: 1, vaOutQty: 7.000, rejectionWt: 0.000, yieldPct: 83.33 }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">VALUE ADDITION TRACKID</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Value Added Processing & Yield</span>
        </div>

        <!-- Upper Card: Entry Form -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="va-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="va-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VSP-DFL UNIT-1 (VSP)" selected>VSP-DFL UNIT-1 (VSP)</option>
                  <option value="KKD-DFL UNIT-2 (KKD)">KKD-DFL UNIT-2 (KKD)</option>
                  <option value="PSP-DFL UNIT-3 (PSP)">PSP-DFL UNIT-3 (PSP)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="va-arrival-date" value="2025-02-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRACK ID <span class="text-red-500 font-bold">*</span></label>
                <select id="va-track-id" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VM-VSP-AMP-056" selected>VM-VSP-AMP-056</option>
                  <option value="BT-KKD-MKP-043">BT-KKD-MKP-043</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">VALUE ADDITION DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="va-date" value="2025-02-24" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Row 2: 3 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SHIFT <span class="text-red-500 font-bold">*</span></label>
                <select id="va-shift" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="A SHIFT" selected>A SHIFT</option>
                  <option value="B SHIFT">B SHIFT</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">SUPERVISOR <span class="text-red-500 font-bold">*</span></label>
                <select id="va-supervisor" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="S.BALA KRISHNA" selected>S.BALA KRISHNA</option>
                  <option value="T.VENKATESH">T.VENKATESH</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HL COUNT <span class="text-red-500 font-bold">*</span></label>
                <select id="va-hl-count" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="37.00" selected>37.00 - 46.00 Count</option>
                  <option value="46.00">46.00 - 55.00 Count</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TOTALS () <span class="text-red-500 font-bold">*</span></label>
                <input type="text" value="Balance" readonly class="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-lg text-xs text-[#64748B] focus:outline-none">
              </div>
            </div>

            <!-- Row 3: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">VARIETY <span class="text-red-500 font-bold">*</span></label>
                <select id="va-variety" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VM RPD" selected>VM RPD</option>
                  <option value="VM RPD FULL CUT">VM RPD FULL CUT</option>
                  <option value="EZ-PEEL">EZ-PEEL</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HL WT (KGS) <span class="text-red-500 font-bold">*</span></label>
                <input type="number" step="0.01" id="va-hl-wt" value="27" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all font-semibold">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">CRATES <span class="text-red-500 font-bold">*</span></label>
                <input type="number" id="va-crates" placeholder="Enter Crates" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">VAOUTQUANTITY</label>
                <input type="number" step="0.01" id="va-out-qty" placeholder="Enter VAOutQuantity" class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Buttons: Save, Cancel, Transfer to Another Plant -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="submit" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Save
              </button>
              <button type="button" id="va-btn-cancel" class="px-5 py-2 bg-white border border-[#CBD5E1] text-[#334155] hover:bg-[#F8FAFC] text-xs font-bold rounded-lg shadow-xs transition-all cursor-pointer">
                Cancel
              </button>
              <button type="button" id="va-btn-transfer" class="px-5 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-1.5 cursor-pointer">
                Transfer to Another Plant
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="va-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="va-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3 w-8"><input type="checkbox" id="va-check-all" class="rounded"></th>
                  <th class="py-2.5 px-3">S.No</th>
                  <th class="py-2.5 px-3">Arrival Code</th>
                  <th class="py-2.5 px-3">Production Plant</th>
                  <th class="py-2.5 px-3">Soaking Plant</th>
                  <th class="py-2.5 px-3">Transaction Date</th>
                  <th class="py-2.5 px-3">Shift</th>
                  <th class="py-2.5 px-3">Variety</th>
                  <th class="py-2.5 px-3 text-right">HL Wt(Kgs)</th>
                  <th class="py-2.5 px-3 text-right">HL Count</th>
                  <th class="py-2.5 px-3 text-right">No of Crates</th>
                  <th class="py-2.5 px-3 text-right">VA Out Quantity</th>
                  <th class="py-2.5 px-3 text-right">Rejection Weight</th>
                  <th class="py-2.5 px-3 text-right">Yield</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="va-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('va-table-body');
    const searchInput = document.getElementById('va-search');
    const form = document.getElementById('va-form');
    const exportBtn = document.getElementById('va-export-excel');
    const cancelBtn = document.getElementById('va-btn-cancel');
    const transferBtn = document.getElementById('va-btn-transfer');

    const renderTable = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.valueAdditionList.filter(r => {
        if (!q) return true;
        return `${r.arrivalCode || ''} ${r.plant || ''} ${r.soakingPlant || ''} ${r.variety || ''}`.toLowerCase().includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="15" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map((r, idx) => `
        <tr class="hover:bg-[#F8FAFC] transition-colors">
          <td class="py-2.5 px-3"><input type="checkbox" class="rounded"></td>
          <td class="py-2.5 px-3 font-bold text-[#64748B]">${idx + 1}</td>
          <td class="py-2.5 px-3 font-bold text-[#0F172A]">${r.arrivalCode || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.plant || '-'}</td>
          <td class="py-2.5 px-3 text-red-500 font-semibold">${r.soakingPlant || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.date || '-'}</td>
          <td class="py-2.5 px-3 font-medium text-[#1E293B]">${r.shift || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155] font-semibold">${r.variety || '-'}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${Number(r.hlWeight || 0).toFixed(3)}</td>
          <td class="py-2.5 px-3 text-right text-[#334155]">${Number(r.hlCount || 0).toFixed(2)}</td>
          <td class="py-2.5 px-3 text-right text-[#334155]">${r.crates || 1}</td>
          <td class="py-2.5 px-3 text-right font-bold text-[#006644]">${Number(r.vaOutQty || 0).toFixed(3)}</td>
          <td class="py-2.5 px-3 text-right text-[#64748B]">${Number(r.rejectionWt || 0).toFixed(3)}</td>
          <td class="py-2.5 px-3 text-right font-mono font-bold text-[#006644]">${Number(r.yieldPct || 0).toFixed(2)}%</td>
          <td class="py-2.5 px-3 text-center">
            <div class="flex items-center justify-center gap-1.5">
              <button type="button" data-edit-id="${r.id}" class="va-edit p-1 text-[#0284C7] hover:bg-[#F0F9FF] rounded cursor-pointer" title="Edit">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
              </button>
              <button type="button" data-del-id="${r.id}" class="va-del p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
              </button>
            </div>
          </td>
        </tr>
      `).join('');

      tbody.querySelectorAll('.va-del').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-del-id');
          if (confirm('Delete this Value Addition line?')) {
            this.valueAdditionList = this.valueAdditionList.filter(x => x.id !== id);
            renderTable(searchInput?.value || '');
            if (window.Toast) window.Toast.show('Value addition record deleted', 'info');
          }
        });
      });
    };

    renderTable();

    searchInput?.addEventListener('input', (e) => renderTable(e.target.value));

    cancelBtn?.addEventListener('click', () => {
      form.reset();
      if (window.Toast) window.Toast.show('Form reset', 'info');
    });

    transferBtn?.addEventListener('click', () => {
      if (window.Toast) window.Toast.show('Initiating transfer workflow to destination plant', 'info');
    });

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      const hlWt = parseFloat(document.getElementById('va-hl-wt').value) || 0;
      const vaOut = parseFloat(document.getElementById('va-out-qty').value) || (hlWt * 0.8333);
      const yieldPct = hlWt > 0 ? (vaOut / hlWt) * 100 : 0;
      const newRec = {
        id: 'VA-' + String(Date.now()).slice(-6),
        sNo: this.valueAdditionList.length + 1,
        arrivalCode: document.getElementById('va-track-id').value,
        plant: document.getElementById('va-plant').value,
        soakingPlant: "DFL UNIT-2 (KKD)",
        date: document.getElementById('va-date').value,
        shift: document.getElementById('va-shift').value,
        variety: document.getElementById('va-variety').value,
        hlWeight: hlWt,
        hlCount: 37.00,
        crates: parseInt(document.getElementById('va-crates').value, 10) || 1,
        vaOutQty: vaOut,
        rejectionWt: 0.000,
        yieldPct: yieldPct
      };
      this.valueAdditionList.unshift(newRec);
      renderTable(searchInput?.value || '');
      form.reset();
      if (window.Toast) window.Toast.show('Value Addition record saved', 'success');
    });

    exportBtn?.addEventListener('click', () => {
      const headers = ["S.No", "Arrival Code", "Production Plant", "Soaking Plant", "Transaction Date", "Shift", "Variety", "HL Wt(Kgs)", "HL Count", "No of Crates", "VA Out Quantity", "Rejection Weight", "Yield"];
      const rows = this.valueAdditionList.map((r, i) => [
        i + 1,
        `"${r.arrivalCode || ''}"`,
        `"${r.plant || ''}"`,
        `"${r.soakingPlant || ''}"`,
        `"${r.date || ''}"`,
        `"${r.shift || ''}"`,
        `"${r.variety || ''}"`,
        r.hlWeight || 0,
        r.hlCount || 0,
        r.crates || 1,
        r.vaOutQty || 0,
        r.rejectionWt || 0,
        (r.yieldPct || 0).toFixed(2)
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `value_addition_trackid_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('Value Addition report exported to CSV', 'success');
    });
  },

  renderHonQtyTransfer(container) {
    if (!this.honTransferList || this.honTransferList.length === 0) {
      this.honTransferList = [
        { id: "HT-01", sNo: 1, arrivalDate: "20-02-2025", billDate: "19-02-2025", billNumber: "MKP/2425/2346", plant: "DFL UNIT-1 (VSP)", purchaseCount: "60.000", purchaseWeight: "1591.000", rmPlant: "DFL UNIT-1 (VSP)", transferDate: "23-10-2026", vaWeightQty: "23.000" }
      ];
    }

    container.innerHTML = `
      <div class="space-y-4 animate-fade-in text-[#1E293B]">
        <!-- Page Title -->
        <div class="flex items-center justify-between pb-1">
          <h2 class="text-sm md:text-base font-bold text-[#1E293B] tracking-wide uppercase">HON QTY TRANSFER AFTER VA</h2>
          <span class="text-xs text-[#64748B] font-medium hidden sm:inline">Operations &bull; Head-On Quantity Inter-Plant Requisition</span>
        </div>

        <!-- Upper Card: Entry Form -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 md:p-6 transition-all">
          <form id="ht-form" class="space-y-4">
            <!-- Row 1: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">PRODUCTION PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="ht-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VSP-DFL UNIT-1 (VSP)" selected>VSP-DFL UNIT-1 (VSP)</option>
                  <option value="KKD-DFL UNIT-2 (KKD)">KKD-DFL UNIT-2 (KKD)</option>
                  <option value="PSP-DFL UNIT-3 (PSP)">PSP-DFL UNIT-3 (PSP)</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="ht-arrival-date" value="2025-02-20" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRACK ID <span class="text-red-500 font-bold">*</span></label>
                <select id="ht-track-id" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="VM-VSP-MKP-049" selected>VM-VSP-MKP-049</option>
                  <option value="VM-VSP-AMP-056">VM-VSP-AMP-056</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">ARRIVAL CODE <span class="text-red-500 font-bold">*</span></label>
                <select id="ht-arrival-code" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="MKP/2425/2346" selected>MKP/2425/2346, MKP/2425/2347 Mix (60.00, 105.00...)</option>
                </select>
              </div>
            </div>

            <!-- Row 2: 4 Columns -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HON COUNT <span class="text-red-500 font-bold">*</span></label>
                <select id="ht-hon-count" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="60.00C - 1591.00KGs - MKP/2425/2346" selected>60.00C - 1591.00KGs - MKP/2425/2346</option>
                </select>
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">HON WEIGHT (TOTAL : 1591 KGS) <span class="text-red-500 font-bold">*</span></label>
                <input type="text" value="Balance : 1568 KGs" readonly class="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-lg text-xs text-[#64748B] font-semibold focus:outline-none">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">WEIGHT <span class="text-red-500 font-bold">*</span></label>
                <input type="number" step="0.01" id="ht-weight" placeholder="Enter Weight" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all font-semibold">
              </div>
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRANSFER PLANT <span class="text-red-500 font-bold">*</span></label>
                <select id="ht-transfer-plant" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
                  <option value="">Select</option>
                  <option value="DFL UNIT-2 (KKD)" selected>DFL UNIT-2 (KKD)</option>
                  <option value="DFL UNIT-3 (PSP)">DFL UNIT-3 (PSP)</option>
                  <option value="DFL UNIT-5 (JPT)">DFL UNIT-5 (JPT)</option>
                </select>
              </div>
            </div>

            <!-- Row 3: 1 Column -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label class="block text-[11px] font-bold text-[#334155] uppercase tracking-wider mb-1.5">TRANSFER DATE <span class="text-red-500 font-bold">*</span></label>
                <input type="date" id="ht-transfer-date" value="2026-10-23" required class="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              </div>
            </div>

            <!-- Action Buttons: Close, Submit -->
            <div class="flex items-center justify-center gap-3 pt-2">
              <button type="button" id="ht-btn-close" class="px-5 py-2 bg-white border border-[#CBD5E1] text-[#334155] hover:bg-[#F8FAFC] text-xs font-bold rounded-lg shadow-xs transition-all cursor-pointer">
                Close
              </button>
              <button type="submit" class="px-7 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow transition-all cursor-pointer">
                Submit
              </button>
            </div>
          </form>
        </div>

        <!-- Lower Card: Register Table -->
        <div class="bg-white rounded-xl border border-[#CBD5E1] shadow-xs p-5 transition-all">
          <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div class="relative w-full max-w-sm">
              <input type="text" id="ht-search" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#1E293B] focus:outline-none focus:border-[#02a8b5] focus:ring-1 focus:ring-[#02a8b5] transition-all">
              <svg class="w-4 h-4 text-[#94A3B8] absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </div>
            <button type="button" id="ht-export-excel" class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-semibold rounded-lg shadow-xs hover:shadow transition-all flex items-center gap-2 cursor-pointer self-end sm:self-auto whitespace-nowrap">
              <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
              Download Excel
            </button>
          </div>

          <div class="overflow-x-auto border border-[#CBD5E1] rounded-lg">
            <table class="w-full text-left border-collapse text-xs whitespace-nowrap">
              <thead>
                <tr class="bg-[#F8FAFC] text-[11px] font-bold text-[#475569] uppercase tracking-wider border-b border-[#CBD5E1]">
                  <th class="py-2.5 px-3">S.No</th>
                  <th class="py-2.5 px-3">Arrival Date</th>
                  <th class="py-2.5 px-3">Bill Date</th>
                  <th class="py-2.5 px-3">Bill Number</th>
                  <th class="py-2.5 px-3">Production Plant</th>
                  <th class="py-2.5 px-3 text-right">Purchase Count</th>
                  <th class="py-2.5 px-3 text-right">Purchase Weight</th>
                  <th class="py-2.5 px-3">Rm Production plant</th>
                  <th class="py-2.5 px-3">Transfer Date</th>
                  <th class="py-2.5 px-3 text-right">VA Weight Qty</th>
                  <th class="py-2.5 px-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody id="ht-table-body" class="divide-y divide-[#E2E8F0] bg-white">
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const tbody = document.getElementById('ht-table-body');
    const searchInput = document.getElementById('ht-search');
    const form = document.getElementById('ht-form');
    const exportBtn = document.getElementById('ht-export-excel');
    const closeBtn = document.getElementById('ht-btn-close');

    const renderTable = (query = '') => {
      const q = query.toLowerCase().trim();
      const filtered = this.honTransferList.filter(r => {
        if (!q) return true;
        return `${r.billNumber || ''} ${r.plant || ''} ${r.rmPlant || ''}`.toLowerCase().includes(q);
      });

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" class="text-center py-8 text-[#94A3B8] text-xs font-medium">No data available in table</td></tr>`;
        return;
      }

      tbody.innerHTML = filtered.map((r, idx) => `
        <tr class="hover:bg-[#F8FAFC] transition-colors">
          <td class="py-2.5 px-3 font-bold text-[#64748B]">${idx + 1}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.arrivalDate || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.billDate || '-'}</td>
          <td class="py-2.5 px-3 font-bold text-[#0F172A]">${r.billNumber || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.plant || '-'}</td>
          <td class="py-2.5 px-3 text-right font-medium text-[#334155]">${Number(r.purchaseCount || 0).toFixed(3)}</td>
          <td class="py-2.5 px-3 text-right font-bold text-[#0F172A]">${Number(r.purchaseWeight || 0).toFixed(3)}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.rmPlant || '-'}</td>
          <td class="py-2.5 px-3 text-[#334155]">${r.transferDate || '-'}</td>
          <td class="py-2.5 px-3 text-right font-bold text-[#006644]">${Number(r.vaWeightQty || 0).toFixed(3)}</td>
          <td class="py-2.5 px-3 text-center">
            <button type="button" data-del-id="${r.id}" class="ht-del p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer" title="Delete Transfer">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </td>
        </tr>
      `).join('');

      tbody.querySelectorAll('.ht-del').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.getAttribute('data-del-id');
          if (confirm('Delete this transfer manifest?')) {
            this.honTransferList = this.honTransferList.filter(x => x.id !== id);
            renderTable(searchInput?.value || '');
            if (window.Toast) window.Toast.show('Transfer record deleted', 'info');
          }
        });
      });
    };

    renderTable();

    searchInput?.addEventListener('input', (e) => renderTable(e.target.value));

    closeBtn?.addEventListener('click', () => {
      form.reset();
      if (window.Toast) window.Toast.show('Transfer form closed', 'info');
    });

    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      const wt = parseFloat(document.getElementById('ht-weight').value) || 0;
      const newRec = {
        id: 'HT-' + String(Date.now()).slice(-6),
        sNo: this.honTransferList.length + 1,
        arrivalDate: document.getElementById('ht-arrival-date').value.split('-').reverse().join('-'),
        billDate: "19-02-2025",
        billNumber: "MKP/2425/2346",
        plant: document.getElementById('ht-plant').value,
        purchaseCount: "60.000",
        purchaseWeight: "1591.000",
        rmPlant: document.getElementById('ht-plant').value,
        transferDate: document.getElementById('ht-transfer-date').value,
        vaWeightQty: wt.toFixed(3)
      };
      this.honTransferList.unshift(newRec);
      renderTable(searchInput?.value || '');
      form.reset();
      if (window.Toast) window.Toast.show('HON transfer manifest submitted successfully!', 'success');
    });

    exportBtn?.addEventListener('click', () => {
      const headers = ["S.No", "Arrival Date", "Bill Date", "Bill Number", "Production Plant", "Purchase Count", "Purchase Weight", "Rm Production plant", "Transfer Date", "VA Weight Qty"];
      const rows = this.honTransferList.map((r, i) => [
        i + 1,
        `"${r.arrivalDate || ''}"`,
        `"${r.billDate || ''}"`,
        `"${r.billNumber || ''}"`,
        `"${r.plant || ''}"`,
        r.purchaseCount || 0,
        r.purchaseWeight || 0,
        `"${r.rmPlant || ''}"`,
        `"${r.transferDate || ''}"`,
        r.vaWeightQty || 0
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(e => e.join(','))].join(String.fromCharCode(10));
      const link = document.createElement("a");
      link.setAttribute("href", encodeURI(csvContent));
      link.setAttribute("download", `hon_qty_transfer_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      if (window.Toast) window.Toast.show('HON Transfer report exported to CSV', 'success');
    });
  },

  // ============================================
  // 4. TRACEABILITY & RECONCILIATION
  // ============================================
  renderTrackCodeReport(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader('Batch Genealogy & End-to-End Traceability Report')}
        <div id="trace-table-container"></div>
      </div>
    `;
    new DataTable({
      containerId: 'trace-table-container',
      data: this.traceReportsList,
      keyField: 'id',
      tableTitle: 'Farm-to-Freezer Aquaculture Traceability Ledger',
      searchable: false,
      hideTopFilterBar: true,
      columns: [
        { field: 'sNo', header: 'S.No', render: (v, r, idx) => `<span class="font-bold text-[#5E6C84]">${idx + 1}</span>` },
        { field: 'batchCode', header: 'Batch Code', render: (v) => `<span class="font-mono font-bold text-[#006C7A] bg-[#E6FCFF] px-2 py-0.5 rounded">${v}</span>` },
        { field: 'farmerName', header: 'Farmer / Cluster', render: (v) => `<span class="font-bold text-[#172B4D]">${v}</span>` },
        { field: 'pondNo', header: 'Pond', render: (v) => `<span class="text-[#5E6C84]">${v}</span>` },
        { field: 'harvestDate', header: 'Harvest Date', render: (v) => `<span class="text-[#172B4D]">${v}</span>` },
        { field: 'intakeWeight', header: 'Intake (KG)', render: (v) => `<span class="text-[#5E6C84]">${v.toLocaleString()}</span>` },
        { field: 'deheadedWeight', header: 'Deheaded', render: (v) => `<span class="text-[#5E6C84]">${v.toLocaleString()}</span>` },
        { field: 'gradedWeight', header: 'Graded', render: (v) => `<span class="text-[#5E6C84]">${v.toLocaleString()}</span>` },
        { field: 'packedWeight', header: 'Packed (KG)', render: (v) => `<span class="font-extrabold text-[#006644]">${v.toLocaleString()} KG</span>` },
        { field: 'totalYieldPct', header: 'Net Yield %', render: (v) => `<span class="font-mono font-bold text-[#172B4D]">${v}%</span>` },
        { field: 'status', header: 'Status', render: (v) => UIBase.renderBadge(v, 'success') }
      ]
    });
  },

  renderVaFloorBalance(container) {
    this.renderFloorOverview(container);
  },

  renderVaTransfer(container) {
    this.renderHonQtyTransfer(container);
  },

  renderAssumedReports(container) {
    this.renderChemicalReceivedReport(container);
  },

  renderConsolidationDaily(container) {
    this.renderFloorOverview(container);
  },

  renderFileUpload(container) {
    container.innerHTML = `
      <div class="space-y-4 animate-fade-in">
        ${UIBase.renderHeader('Batch File Upload & Data Ingestion')}
        <div class="bg-white rounded-xl border border-[#DFE1E6] p-6 shadow-xs text-center">
          <div class="w-12 h-12 rounded-full bg-[#F0F9FF] text-[#0284C7] flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
          </div>
          <h3 class="text-sm font-bold text-[#172B4D]">Drag and drop your spreadsheet here</h3>
          <p class="text-xs text-[#5E6C84] mt-1">Accepts .CSV, .XLSX files up to 25MB (Grading runs, intake scales, chemical orders)</p>
          <div class="mt-4 flex items-center justify-center gap-3">
            <button class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow cursor-pointer transition-all" onclick="window.PreprocessingView.toastSuccess('Upload triggered')">Browse Files</button>
            <button class="px-4 py-2 bg-[#02a8b5] hover:bg-[#008f9a] text-white text-xs font-bold rounded-lg shadow-xs hover:shadow cursor-pointer transition-all" onclick="window.PreprocessingView.toastInfo('Downloading CSV template')">Download Template</button>
          </div>
        </div>
      </div>
    `;
  },

  calcDiff() {},
  calcDeheadYield() {
    const qty = parseFloat(document.getElementById('dh-hon-qty')?.value) || 0;
    const yieldEl = document.getElementById('dh-yield');
    if (yieldEl && qty > 0) {
      yieldEl.value = (66.5 + (qty % 3) * 0.5).toFixed(1);
    }
  },

  toastSuccess(msg) { if (typeof Toast !== 'undefined') Toast.show(msg, 'success'); },
  toastInfo(msg) { if (typeof Toast !== 'undefined') Toast.show(msg, 'info'); },
  toastError(msg) { if (typeof Toast !== 'undefined') Toast.show(msg, 'error'); },

  openChemPOModal() { this.toastInfo('Opening Chemical Purchase Order Modal'); },
  openChemOrderModal() { this.toastInfo('Opening Dock Intake Modal'); },
  openChemConsumptionModal() { this.toastInfo('Opening Daily Floor Consumption Modal'); },
  openChemPaymentModal() { this.toastInfo('Opening Vendor Payment Modal'); }
};
